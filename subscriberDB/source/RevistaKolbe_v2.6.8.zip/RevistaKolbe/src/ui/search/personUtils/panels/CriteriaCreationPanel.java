package ui.search.personUtils.panels;

import javax.swing.JPanel;

import ui.search.personUtils.searchCriteria.SearchCriteria;



public abstract class CriteriaCreationPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8805817806446171891L;
	public CriteriaCreationPanel() {
	}
	public abstract SearchCriteria createSearchCriteria();
}
