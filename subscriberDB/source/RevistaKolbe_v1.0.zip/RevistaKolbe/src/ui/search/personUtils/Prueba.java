package ui.search.personUtils;

public class Prueba {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String a="26/12/2012";
		String[] algo=a.split("/");
		System.out.println(algo);

	}

}
