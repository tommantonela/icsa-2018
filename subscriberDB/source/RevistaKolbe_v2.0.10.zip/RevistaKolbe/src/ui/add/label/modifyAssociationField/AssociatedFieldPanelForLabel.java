package ui.add.label.modifyAssociationField;

import javax.swing.JPanel;

public abstract class AssociatedFieldPanelForLabel extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5702441885318199358L;

	public abstract String getValue();
}
