package ui.mailing;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.prefs.Preferences;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingWorker;
import javax.swing.border.EmptyBorder;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.converter.pdf.PdfConverter;
import org.apache.poi.xwpf.converter.pdf.PdfOptions;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

import bd.pojos.Donation;
import bd.pojos.Person;

public class CreateLetterDialog extends JDialog implements  
PropertyChangeListener {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JPasswordField passwordField;
	public static String MAIL_ADDRESS="mailAddress";
    public static String MAIL_PASSWORD="mailPassword";
    public static String MAIL_SMTP="mailSMTP";
    public static String MAIL_SMTP_PORT="mailSMTPPort";
	private JRadioButton rdbtnImprimir;
	private JLabel lblEmail;
	private JRadioButton rdbtnEnviarPorEmail;
	private JLabel lblContrasea;
	private File file;
	private JLabel lblArchivo;
	private JButton okButton;
	private List<Person> results;
	private Hashtable<Person, Donation> donationsOfLastSearch;
	private JProgressBar progressBar;
	private JTextField textField_1;
	private JTextField textField_2;
	private JLabel lblServidorSmtp;
	private JLabel lblPuertoSmtp;
	private JLabel lblAsunto;
	private JTextField textField_3;
	/**
	 * Create the dialog.
	 * @param results 
	 * @param donationsOfLastSearch 
	 */
	public CreateLetterDialog(List<Person> results, Hashtable<Person, Donation> donationsOfLastSearch) {
		this.results=results;
		this.donationsOfLastSearch=donationsOfLastSearch;
		setBounds(100, 100, 450, 416);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		JButton btnCargarArchivo = new JButton("Cargar archivo");
		btnCargarArchivo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				loadFileClicked();
			}
		});
		
		lblArchivo = new JLabel("Archivo:");
		
		rdbtnImprimir = new JRadioButton("Imprimir");
		rdbtnImprimir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				radioButtonCliked();
			}
		});
		rdbtnImprimir.setSelected(true);
		rdbtnEnviarPorEmail = new JRadioButton("Enviar por email");
		rdbtnEnviarPorEmail.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				radioButtonCliked();
			}
		});
		
		ButtonGroup buttonGroupDataSource = new ButtonGroup();
		buttonGroupDataSource.add(rdbtnImprimir);
		buttonGroupDataSource.add(rdbtnEnviarPorEmail);
		
		lblEmail = new JLabel("Email");
		lblEmail.setEnabled(false);
		
		textField = new JTextField();
		textField.setEnabled(false);
		textField.setColumns(10);
		textField.setText(Preferences.userNodeForPackage(CreateLetterDialog.class)
				.get(MAIL_ADDRESS, "direccion@gmail.com"));
		
		lblContrasea = new JLabel("Contrase\u00F1a");
		lblContrasea.setEnabled(false);
		
		passwordField = new JPasswordField();
		passwordField.setEnabled(false);
		passwordField.setText(Preferences.userNodeForPackage(CreateLetterDialog.class)
				.get(MAIL_PASSWORD, ""));
		
		progressBar = new JProgressBar();
		progressBar.setVisible(false);
		
		lblServidorSmtp = new JLabel("Servidor SMTP");
		lblServidorSmtp.setEnabled(false);
		
		textField_1 = new JTextField();
		textField_1.setEnabled(false);
		textField_1.setColumns(10);
		textField_1.setText(Preferences.userNodeForPackage(CreateLetterDialog.class)
				.get(MAIL_SMTP, "smtp.gmail.com"));
		
		lblPuertoSmtp = new JLabel("Puerto SMTP");
		lblPuertoSmtp.setEnabled(false);
		
		textField_2 = new JTextField();
		textField_2.setEnabled(false);
		textField_2.setColumns(10);
		textField_2.setText(Preferences.userNodeForPackage(CreateLetterDialog.class)
				.get(MAIL_SMTP_PORT, "587"));
		
		lblAsunto = new JLabel("Asunto");
		lblAsunto.setEnabled(false);
		
		textField_3 = new JTextField();
		textField_3.setEnabled(false);
		textField_3.setColumns(10);
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addGap(6)
									.addComponent(lblArchivo, GroupLayout.DEFAULT_SIZE, 422, Short.MAX_VALUE))
								.addComponent(btnCargarArchivo)
								.addComponent(rdbtnImprimir)
								.addComponent(rdbtnEnviarPorEmail)
								.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING, false)
									.addGroup(gl_contentPanel.createSequentialGroup()
										.addComponent(lblContrasea)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(passwordField))
									.addGroup(gl_contentPanel.createSequentialGroup()
										.addComponent(lblEmail)
										.addGap(16)
										.addComponent(textField, GroupLayout.PREFERRED_SIZE, 368, GroupLayout.PREFERRED_SIZE))))
							.addContainerGap())
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addComponent(lblPuertoSmtp)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addContainerGap(217, Short.MAX_VALUE))
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addComponent(lblServidorSmtp)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 328, Short.MAX_VALUE)
							.addGap(12))
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addComponent(progressBar, GroupLayout.DEFAULT_SIZE, 422, Short.MAX_VALUE)
							.addGap(12))
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addComponent(lblAsunto)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 360, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())))
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(btnCargarArchivo)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblArchivo)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(rdbtnImprimir)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(rdbtnEnviarPorEmail)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblEmail))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblContrasea)
						.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblServidorSmtp)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPuertoSmtp)
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAsunto)
						.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
					.addComponent(progressBar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(17))
		);
		contentPanel.setLayout(gl_contentPanel);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				okButton = new JButton("Aceptar");
				okButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						okButtonClicked();
					}
				});
				okButton.setEnabled(false);
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancelar");
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						cancelCliked();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}



	private void okButtonClicked() {
		starProgessBar();
		if(rdbtnImprimir.isSelected()){
			//Imprimir
			printLetter();
		}else{
						
			//Guardo los valores
			Preferences.userNodeForPackage(CreateLetterDialog.class)
			.put(MAIL_ADDRESS, textField.getText());
			Preferences.userNodeForPackage(CreateLetterDialog.class)
			.put(MAIL_PASSWORD, passwordField.getText());
			Preferences.userNodeForPackage(CreateLetterDialog.class)
			.put(MAIL_SMTP, textField_1.getText());
			Preferences.userNodeForPackage(CreateLetterDialog.class)
			.put(MAIL_SMTP_PORT, textField_2.getText());
			
			//Enviar por email
			sendByEmail();
		}
		//progressBar.setVisible(false);
	}



	private void sendByEmail() {
		SendByEmailTask task = new SendByEmailTask();
        task.addPropertyChangeListener(this);
        task.execute();
	}



	private void printLetter() {
		 PrintLetterTask task = new PrintLetterTask();
	        task.addPropertyChangeListener(this);
	        task.execute();
	}
	private void starProgessBar(){
		progressBar.setMinimum(0);
		progressBar.setMaximum(results.size());
		progressBar.setValue(0);
		progressBar.setStringPainted(true);
		progressBar.setVisible(true);
	}


	private File getModifiedPdfFiles(Person person) {
		try {
			//POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream("screenshoots/modeloagradabril.doc"));
			XWPFDocument document = new XWPFDocument(OPCPackage.openOrCreate(file));
			
			
			
			List<XWPFParagraph> paragraphs=document.getParagraphs();
			for (Iterator<XWPFParagraph> iterator = paragraphs.iterator(); iterator.hasNext();) {
				XWPFParagraph xwpfParagraph = (XWPFParagraph) iterator.next();
				//System.out.println(xwpfParagraph.getParagraphText());
				if(xwpfParagraph.getParagraphText().contains("�genero�")){
					String genero="a";
					if(person.getGender().equals("Masculino"))
						genero="o";
					if(!person.getNumberOfPersons().equals("Singular"))
						genero=genero+"s";
					
					replaceTextInParagraph(xwpfParagraph,"�genero�",genero);
				}
				if(xwpfParagraph.getParagraphText().contains("�nombre�")){
					replaceTextInParagraph(xwpfParagraph,"�nombre�",person.getName());
				}
				if(xwpfParagraph.getParagraphText().contains("�apellido�")){
					replaceTextInParagraph(xwpfParagraph,"�apellido�",person.getFamilyName());
				}
				if(xwpfParagraph.getParagraphText().contains("�donadot�")){
					
					Donation donation=donationsOfLastSearch.get(person);
					if(donation!=null)
						replaceTextInParagraph(xwpfParagraph,"�donadot�",donation.getAmount().toString());
					else
						replaceTextInParagraph(xwpfParagraph,"�donadot�","-");
				}
			}
			
			
		
			// document.write(new FileOutputStream(new File("Modificado.docx")));
			//SAVE AS PDF
			// 2) Prepare Pdf options
			PdfOptions options = PdfOptions.create();
			 // 3) Convert XWPFDocument to Pdf
			File pdfFile=File.createTempFile(file.getName(), ".pdf");
	        OutputStream out= new FileOutputStream(pdfFile);
			PdfConverter.getInstance().convert(document, out, options);
	        return pdfFile;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	private void sendByEmailFile(File pdfFile, String emailTo) {
		try
        {
			String mailAdress=Preferences.userNodeForPackage(CreateLetterDialog.class)
			.get(MAIL_ADDRESS, textField.getText());
			String password=Preferences.userNodeForPackage(CreateLetterDialog.class)
			.get(MAIL_PASSWORD, passwordField.getText());
			String smtp=Preferences.userNodeForPackage(CreateLetterDialog.class)
			.get(MAIL_SMTP, textField_1.getText());
			String smtpPort=Preferences.userNodeForPackage(CreateLetterDialog.class)
			.get(MAIL_SMTP_PORT, textField_2.getText());
            // Propiedades de la conexi�n
            Properties props = new Properties();
            props.setProperty("mail.smtp.host", smtp);
            props.setProperty("mail.smtp.starttls.enable", "true");
            props.setProperty("mail.smtp.port", smtpPort);
            props.setProperty("mail.smtp.user", mailAdress);
            props.setProperty("mail.smtp.auth", "true");
            
            // Preparamos la sesion
            Session session = Session.getDefaultInstance(props);
            
            MimeMultipart multiParte = createMessage(pdfFile);
            
            // Construimos el mensaje
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(mailAdress));
            message.addRecipient(
                Message.RecipientType.TO,
                new InternetAddress(emailTo));
            message.setSubject(textField_3.getText());
            message.setContent(multiParte);

            // Lo enviamos.
            Transport t = session.getTransport("smtp");
            t.connect(mailAdress, password);
            t.sendMessage(message, message.getAllRecipients());

            // Cierre.
            t.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
	}
	private MimeMultipart createMessage(File pdfFile) throws MessagingException {
		// Se compone la parte del texto
		BodyPart texto = new MimeBodyPart();
		texto.setText("");
		
		// Una MultiParte para agrupar texto e imagen.
		MimeMultipart multiParte = new MimeMultipart();
		multiParte.addBodyPart(texto);
		
		
		
		//attachFile(multiParte,"PortfolioStatusReport.pdf");
		BodyPart adjunto = new MimeBodyPart();
		adjunto.setDataHandler(
		    new DataHandler(new FileDataSource(pdfFile)));
		adjunto.setFileName(file.getName().replaceAll(".docx", ".pdf"));		
		multiParte.addBodyPart(adjunto);
		return multiParte;
	}
	
	public static void printFile(File file){
		
	
		         FileInputStream inputStream = null;
		         try {
		             inputStream = new FileInputStream(file.getAbsolutePath());//Podria ser el canonical en lugar de este path
		         } catch (FileNotFoundException e) {
		             e.printStackTrace();
		         }
		         if (inputStream == null) {
		             return;
		         }

		        DocFlavor docFormat = DocFlavor.INPUT_STREAM.AUTOSENSE;
		        Doc document = new SimpleDoc(inputStream, docFormat, null);
				
				
			
		
		         PrintRequestAttributeSet attributeSet = new HashPrintRequestAttributeSet();

		         PrintService defaultPrintService = PrintServiceLookup.lookupDefaultPrintService();


		         if (defaultPrintService != null) {
		             DocPrintJob printJob = defaultPrintService.createPrintJob();
		             try {
		                 printJob.print(document, attributeSet);

		             } catch (Exception e) {
		                 e.printStackTrace();
		             }
		         } else {
		             System.err.println("No existen impresoras instaladas");
		         }

		         //inputStream.close();
		     
		 

	}
	private static void replaceTextInParagraph(XWPFParagraph xwpfParagraph, String valueToSearch, String valueToReplace) {
		List<XWPFRun> runs = xwpfParagraph.getRuns();
		boolean replaced=false;
		for (int i = 0; i < runs.size(); i++) {
			if(!replaced){
				String oneparaString = runs.get(i).getText(
			            runs.get(i).getTextPosition());
				
				if(oneparaString.contains(valueToSearch))
					runs.get(i).setText(oneparaString.replaceAll(valueToSearch, valueToReplace), 0);
				else{
					int index=oneparaString.indexOf("�");
					if(index!=-1){
						//Obtengo el valor hasta el final
						String subString= oneparaString.substring(index, oneparaString.length());
						
						int hasta=-1;
						for (int j = (i+1); (j < runs.size()) && (hasta==(-1)); j++) {
							String oneparaString2 = runs.get(j).getText(
						            runs.get(j).getTextPosition());
							if(oneparaString2.contains("�")){
								subString=subString.concat(oneparaString2.substring(0, oneparaString2.indexOf("�")+1));
								hasta=j;
							}else{
								subString=subString.concat(oneparaString2);
							}
						}
						
						if(hasta!=-1){
							if(valueToSearch.equals(subString)){
								String newText=oneparaString.replaceAll(oneparaString.substring(index, oneparaString.length()), valueToReplace);
								runs.get(i).setText(newText, 0);
								for (int j = (i+1); j <= hasta; j++) {
									
									if(j==hasta){
										String oneparaString2 = runs.get(j).getText(runs.get(j).getTextPosition());
										
									//	oneparaString2.substring(0, oneparaString2.indexOf("�")+1)
										runs.get(j).setText(oneparaString2.substring(oneparaString2.indexOf("�")+1,oneparaString2.length() ), 0);
									}else{
										runs.get(j).setText("", 0);
									}
								}
								
							}
							
						}
					}
				}
			}
			
		}
	}

	private void loadFileClicked() {
		JFileChooser fc=new JFileChooser();
		//Add a custom file filter and disable the default
	    //(Accept All) file filter.
		DocxFilter filter=new DocxFilter();
        fc.addChoosableFileFilter(filter);
        fc.setAcceptAllFileFilterUsed(false);
        fc.setFileFilter(filter);
        
        int returnVal = fc.showDialog(this,
                "Seleccionar archivo");

        //Process the results.
        if (returnVal == JFileChooser.APPROVE_OPTION) {
        	file = fc.getSelectedFile();
        	lblArchivo.setText("Archivo: "+file.getName());
        	okButton.setEnabled(true);
        } 
		
	}



	private void radioButtonCliked() {
		lblEmail.setEnabled(rdbtnEnviarPorEmail.isSelected());
		lblContrasea.setEnabled(rdbtnEnviarPorEmail.isSelected());
		textField.setEnabled(rdbtnEnviarPorEmail.isSelected());
		passwordField.setEnabled(rdbtnEnviarPorEmail.isSelected());
		textField_1.setEnabled(rdbtnEnviarPorEmail.isSelected());
		textField_2.setEnabled(rdbtnEnviarPorEmail.isSelected());
		lblServidorSmtp.setEnabled(rdbtnEnviarPorEmail.isSelected());
		lblPuertoSmtp.setEnabled(rdbtnEnviarPorEmail.isSelected());
		lblAsunto.setEnabled(rdbtnEnviarPorEmail.isSelected());
		textField_3.setEnabled(rdbtnEnviarPorEmail.isSelected());
	}



	private void cancelCliked() {
		this.dispose();
	}
	
	class PrintLetterTask extends SwingWorker<Void, Void> {
        /*
         * Main task. Executed in background thread.
         */
        @Override
        public Void doInBackground() {
        	for (int i = 0; i < results.size(); i++) {
        		setProgress(i);
    			Person person = results.get(i);
    			File pdfFile=getModifiedPdfFiles(person);
    			printFile(pdfFile);
    			//pdfFile.delete();
    			
    		}
        	return null;
        }
        @Override
        public void done() {
            progressBar.setVisible(false);
            cancelCliked();
        }
        
    }

	
	class SendByEmailTask extends SwingWorker<Void, Void> {
        /*
         * Main task. Executed in background thread.
         */
        @Override
        public Void doInBackground() {
        	for (int i = 0; i < results.size(); i++) {
        		setProgress(i);
    			Person person = results.get(i);
    			File pdfFile=getModifiedPdfFiles(person);
    			sendByEmailFile(pdfFile,person.getEmail());
    			//pdfFile.delete();
    			
    		}
        	return null;
        }
        
		@Override
        public void done() {
            progressBar.setVisible(false);
            cancelCliked();
        }
        
    }
	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		if ("progress" == evt.getPropertyName()) {
            int progress = (Integer) evt.getNewValue();
            
            progressBar.setValue(progress);
            //taskOutput.append(String.format(
                //    "Completed %d%% of task.\n", task.getProgress()));
        } 
		
	}
}
