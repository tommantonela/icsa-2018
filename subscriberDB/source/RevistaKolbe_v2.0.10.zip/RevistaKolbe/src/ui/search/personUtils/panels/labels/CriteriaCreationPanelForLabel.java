package ui.search.personUtils.panels.labels;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;

import ui.search.personUtils.panels.CriteriaCreationPanel;
import ui.search.personUtils.panels.labels.internalPanels.AssociatedFieldPanelForLabel;
import ui.search.personUtils.panels.labels.internalPanels.SimpleDatePanelForLabel;
import ui.search.personUtils.panels.labels.internalPanels.SimpleFieldPanelForLabel;
import ui.search.personUtils.panels.labels.internalPanels.utilForSearchResults.AssociatedFieldValueForSearch;
import ui.search.personUtils.searchCriteria.SearchCriteria;
import ui.search.personUtils.searchCriteria.SearchCriteriaForLabel;
import bd.pojos.AssociatedField;
import bd.pojos.Label;

public class CriteriaCreationPanelForLabel extends CriteriaCreationPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5253809212211087564L;
	private Label label;
	
	private Vector<AssociatedFieldPanelForLabel> associatedFieldPanels;
	private JCheckBox chckbxUsarCampos;
	private JRadioButton rdbtnAusente;
	private JRadioButton rdbtnPresente;
	
	public CriteriaCreationPanelForLabel(Label label) {
		super();
		this.label = label;
	
		
		setLayout(null);
		
		rdbtnPresente = new JRadioButton("Presente");
		rdbtnPresente.setBounds(6, 6, 141, 23);
		rdbtnPresente.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				rdbtnPresenteClicked();
			}
		});
		add(rdbtnPresente);
		
		rdbtnAusente = new JRadioButton("Ausente");
		rdbtnAusente.setBounds(6, 30, 141, 23);
		rdbtnAusente.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				rdbtnAusenteClicked();
			}
		});
		add(rdbtnAusente);
		
		ButtonGroup buttonGroupDataSource = new ButtonGroup();
		buttonGroupDataSource.add(rdbtnPresente);
		buttonGroupDataSource.add(rdbtnAusente);
		rdbtnPresente.setSelected(true);
		
		chckbxUsarCampos = new JCheckBox("Usar campos asociados");
		
		chckbxUsarCampos.setBounds(148, 17, 212, 23);
		if(label.getAssociatedFields().size()>0){
			add(chckbxUsarCampos);
			chckbxUsarCampos.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					chckbxUsarCamposChanged(chckbxUsarCampos.isSelected());
				}

			
			});
		}
		int yValue=55;
		associatedFieldPanels=new Vector<AssociatedFieldPanelForLabel>();
		for (Iterator<AssociatedField> iterator = label.getAssociatedFields().iterator(); iterator.hasNext();) {
			AssociatedField associatedField = iterator.next();
			if(associatedField.getType().equals(AssociatedField.date_Type)){
				SimpleDatePanelForLabel panel=new SimpleDatePanelForLabel(associatedField);
				panel.setBounds(0, yValue, 350, 125);
				yValue=yValue+125;
				add(panel);
				associatedFieldPanels.add(panel);
			}else{ //Es un string
				SimpleFieldPanelForLabel panel=new SimpleFieldPanelForLabel(associatedField);
				panel.setBounds(0, yValue, 350, 55);
				yValue=yValue+55;
				add(panel);
				associatedFieldPanels.add(panel);
			}
			JSeparator separator = new JSeparator();
			separator.setBounds(20, yValue, 350, 10);
			add(separator);
			yValue=yValue+10;
		}
		chckbxUsarCamposChanged(false);
		this.setPreferredSize(new Dimension(350,yValue));
	}

	private void rdbtnPresenteClicked() {
		chckbxUsarCampos.setEnabled(true);
		if(chckbxUsarCampos.isSelected())
			chckbxUsarCamposChanged(true);
	}

	private void rdbtnAusenteClicked() {
		chckbxUsarCampos.setEnabled(false);
		chckbxUsarCamposChanged(false);
		
	}

	private void chckbxUsarCamposChanged(boolean selected) {
		for (Iterator<AssociatedFieldPanelForLabel> iterator = associatedFieldPanels.iterator(); iterator.hasNext();) {
			AssociatedFieldPanelForLabel associatedFieldPanel = iterator.next();
			associatedFieldPanel.setEnableAllComponents(selected);
		}
	}

	@Override
	public SearchCriteria createSearchCriteria() {
		Vector<AssociatedFieldValueForSearch> associatedValues=new Vector<AssociatedFieldValueForSearch>();
		for (Iterator<AssociatedFieldPanelForLabel> iterator = associatedFieldPanels.iterator(); iterator
				.hasNext();) {
			AssociatedFieldPanelForLabel associatedFieldPanelForLabel = (AssociatedFieldPanelForLabel) iterator
					.next();
			associatedValues.add(associatedFieldPanelForLabel.getAssociatedValues());
		}
		return new SearchCriteriaForLabel(label, rdbtnPresente.isSelected(),chckbxUsarCampos.isSelected(),associatedValues);
	}
}
