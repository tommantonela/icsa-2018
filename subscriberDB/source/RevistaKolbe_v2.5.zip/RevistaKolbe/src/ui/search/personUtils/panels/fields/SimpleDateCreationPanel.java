package ui.search.personUtils.panels.fields;

import java.awt.Dimension;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;

import ui.search.personUtils.searchCriteria.SearchCriteria;
import ui.search.personUtils.searchCriteria.SearchCriteriaDate;
import ui.search.personUtils.searchCriteria.SearchCriteriaDateOnlyForMonth;
import ui.search.personUtils.searchCriteria.SearchCriteriaDateOnlyForMonthAndDay;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SimpleDateCreationPanel extends CriteriaCreationPanelForField {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7453589649887240745L;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JRadioButton rdbtnFechaCompleta;
	private JRadioButton rdbtnSoloDaY;
	private JRadioButton rdbtnSoloMes;
	private JRadioButton rdbtnIgual;
	/**
	 * Create the panel.
	 */
	public SimpleDateCreationPanel(String fieldToSearch, String columnName) {
		super(fieldToSearch,columnName);
		
		rdbtnIgual = new JRadioButton("Igual");
		
		JRadioButton rdbtnDistinto = new JRadioButton("Distinto");
		
		ButtonGroup buttonGroupDataSource = new ButtonGroup();
		buttonGroupDataSource.add(rdbtnIgual);
		buttonGroupDataSource.add(rdbtnDistinto);
		rdbtnIgual.setSelected(true);
		
		textField_1 = new JTextField();
		textField_1.setToolTipText("D\u00EDa");
		textField_1.setColumns(10);
		
		JLabel label = new JLabel("/");
		
		textField_2 = new JTextField();
		textField_2.setToolTipText("Mes");
		textField_2.setColumns(10);
		
		JLabel label_1 = new JLabel("/");
		
		textField_3 = new JTextField();
		textField_3.setToolTipText("A\u00F1o");
		textField_3.setColumns(10);
		
		rdbtnFechaCompleta = new JRadioButton("Fecha completa");
		rdbtnFechaCompleta.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				rdbtnFechaCompletaClicked();
			}
		});
		
		rdbtnSoloDaY = new JRadioButton("Solo d\u00EDa y mes");
		rdbtnSoloDaY.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				rdbtnSoloDaYClicked();
			}
		});
		
		rdbtnSoloMes = new JRadioButton("Solo mes");
		rdbtnSoloMes.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				rdbtnSoloMesClicked();
			}
		});
		
		ButtonGroup buttonKindOfDate = new ButtonGroup();
		buttonKindOfDate.add(rdbtnFechaCompleta);
		buttonKindOfDate.add(rdbtnSoloDaY);
		buttonKindOfDate.add(rdbtnSoloMes);
		rdbtnFechaCompleta.setSelected(true);
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
									.addGap(6)
									.addComponent(label, GroupLayout.PREFERRED_SIZE, 7, GroupLayout.PREFERRED_SIZE)
									.addGap(6)
									.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
									.addGap(6)
									.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 7, GroupLayout.PREFERRED_SIZE)
									.addGap(6)
									.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE))
								.addComponent(rdbtnFechaCompleta))
							.addPreferredGap(ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(rdbtnDistinto)
								.addComponent(rdbtnIgual)))
						.addComponent(rdbtnSoloDaY)
						.addComponent(rdbtnSoloMes))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(rdbtnIgual)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(rdbtnDistinto))
						.addGroup(groupLayout.createSequentialGroup()
							.addContainerGap()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addGroup(groupLayout.createSequentialGroup()
									.addGap(6)
									.addComponent(label))
								.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addGroup(groupLayout.createSequentialGroup()
									.addGap(6)
									.addComponent(label_1))
								.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(rdbtnFechaCompleta)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(rdbtnSoloDaY)))
					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(rdbtnSoloMes))
		);
		setLayout(groupLayout);
		this.setPreferredSize(new Dimension(270,125));
	}
	private void rdbtnSoloMesClicked() {
		textField_1.setEnabled(false);
		textField_3.setEnabled(false);
	}
	private void rdbtnSoloDaYClicked() {
		textField_1.setEnabled(true);
		textField_3.setEnabled(false);
	}
	private void rdbtnFechaCompletaClicked() {
		textField_1.setEnabled(true);
		textField_3.setEnabled(true);
	}
	@Override
	public SearchCriteria createSearchCriteria() {
		if(rdbtnSoloDaY.isSelected()){
			return new SearchCriteriaDateOnlyForMonthAndDay(field, textField_2.getText(), textField_1.getText(), rdbtnIgual.isSelected(), columnName);
		}else if(rdbtnSoloMes.isSelected()){
			return new SearchCriteriaDateOnlyForMonth(field, textField_2.getText(), rdbtnIgual.isSelected(), columnName);
		}else if (rdbtnFechaCompleta.isSelected()){
			return new SearchCriteriaDate(field, textField_3.getText(), textField_2.getText(), textField_1.getText(), rdbtnIgual.isSelected(), columnName);
		}else return null;
		
	}
}
