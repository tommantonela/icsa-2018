package ui.mailing;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;

public class JasperReportBuilder {
	public static void createReport(String fileName,
			Collection<?> beans) {

		@SuppressWarnings("rawtypes")
		HashMap hm = new HashMap();
		try {
			// Fill the report using an empty data source
			JasperPrint print = JasperFillManager.fillReport(fileName, hm,
					new JRBeanCollectionDataSource(beans));

			// Create a PDF exporter
			JRExporter exporter = new JRPdfExporter();

			// Configure the exporter (set output file name and print object)
			exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME,
					"labels.pdf");
			exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);

			// Export the PDF file
			exporter.exportReport();
			
			File path = new File("labels.pdf");
			CreateLetterDialog.printFile(path);

		} catch (JRException e) {
			e.printStackTrace();
			System.exit(1);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

}
