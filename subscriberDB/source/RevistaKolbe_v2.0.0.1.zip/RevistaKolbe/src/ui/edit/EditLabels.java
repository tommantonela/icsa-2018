package ui.edit;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.LayoutStyle.ComponentPlacement;

import bd.DataBaseManager;
import bd.pojos.AssociatedField;
import bd.pojos.AssociatedFieldValueForLabel;
import bd.pojos.Label;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class EditLabels extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private List<Label> labelsInComboBox;
	private JComboBox comboBox ;
	private Vector<Label> labelsToRemove;
	/**
	 * Create the dialog.
	 */
	public EditLabels() {
		setBounds(100, 100, 458, 121);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		labelsToRemove=new Vector<Label>();
		JLabel lblEtiquetas = new JLabel("Etiquetas");
		
		
		comboBox = new JComboBox();
		loadLabels();
		JButton btnModificar = new JButton("Modificar");
		btnModificar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				modifyButtonClicked();
			}
		});
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				deleteLabelClicked();
			}
		});
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblEtiquetas)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 175, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnModificar)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnEliminar)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblEtiquetas)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnModificar)
						.addComponent(btnEliminar))
					.addContainerGap(207, Short.MAX_VALUE))
		);
		contentPanel.setLayout(gl_contentPanel);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Guardar");
				okButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						saveButtonClicked();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancelar");
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						cancelButtonClicked();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}
	private void saveButtonClicked() {
		for (Iterator<Label> iterator = labelsInComboBox.iterator(); iterator.hasNext();) {
			Label type = (Label) iterator.next();
			DataBaseManager.getInstance().updateLabel(type);
		}
		for (Iterator<Label> iterator = labelsToRemove.iterator(); iterator.hasNext();) {
			Label type = (Label) iterator.next();
			DataBaseManager.getInstance().deleteLabel(type);
		}
		this.dispose();
	}
	private void deleteLabelClicked() {
		int n = JOptionPane.showConfirmDialog(
			    this,
			    "Esta a punto de eliminar la etiqueta",
			    "Atenci�n!",
			    JOptionPane.OK_CANCEL_OPTION);
		
		if(n==0){
			labelsToRemove.add(labelsInComboBox.remove(comboBox.getSelectedIndex()));
			createComboBoxModelOfLabels();
		}
		
	}
	private void cancelButtonClicked() {
		this.dispose();
	}
	private void modifyButtonClicked() {
		new ModifyLabelName(labelsInComboBox.get(comboBox.getSelectedIndex()), this);
		
	}
	private void loadLabels() {
		labelsInComboBox=new ArrayList<Label>();
		List<Label> allLabels=DataBaseManager.getInstance().listLabels();
		for (Iterator<Label> iterator = allLabels.iterator(); iterator.hasNext();) {
			Label label = (Label) iterator.next();
			if(label.isEliminable())
				labelsInComboBox.add(label);
		}
		
		
		createComboBoxModelOfLabels();
	}
	public void createComboBoxModelOfLabels(){
		String[] labelsNames=new String[labelsInComboBox.size()];
		for (int i = 0; i < labelsInComboBox.size(); i++) {
			labelsNames[i]=labelsInComboBox.get(i).getName();
		}
		
		ComboBoxModel jComboBox1Model2 = 
				new DefaultComboBoxModel(labelsNames);
		comboBox.setModel(jComboBox1Model2);
	}
}
