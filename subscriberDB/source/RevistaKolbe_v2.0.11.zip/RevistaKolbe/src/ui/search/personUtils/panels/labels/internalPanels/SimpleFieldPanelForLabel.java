package ui.search.personUtils.panels.labels.internalPanels;

import java.awt.Dimension;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;

import ui.search.personUtils.panels.labels.internalPanels.utilForSearchResults.AssociatedFieldValueForSearch;
import ui.search.personUtils.panels.labels.internalPanels.utilForSearchResults.AssociatedFieldValueStringForSearch;

import bd.pojos.AssociatedField;

public class SimpleFieldPanelForLabel extends AssociatedFieldPanelForLabel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1663262572165130615L;
	private JTextField textField;
	private JRadioButton rdbtnIgual;
	private AssociatedField associatedField;
	private JLabel lblNewLabel;
	private JRadioButton rdbtnDistinto;
	/**
	 * Create the panel.
	 */
	public SimpleFieldPanelForLabel(AssociatedField associatedField) {
		this.associatedField=associatedField;
		textField = new JTextField();
		textField.setColumns(10);
		
		rdbtnIgual = new JRadioButton("Igual");
		
		rdbtnDistinto = new JRadioButton("Distinto");
		
		ButtonGroup buttonGroupDataSource = new ButtonGroup();
		buttonGroupDataSource.add(rdbtnIgual);
		buttonGroupDataSource.add(rdbtnDistinto);
		rdbtnIgual.setSelected(true);
		
		lblNewLabel = new JLabel(associatedField.getName());
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(rdbtnDistinto)
						.addComponent(rdbtnIgual))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(11)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel)))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(rdbtnIgual)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(rdbtnDistinto)))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		setLayout(groupLayout);
		this.setPreferredSize(new Dimension(350,55));
	}
	@Override
	public void setEnableAllComponents(boolean enabled) {
		lblNewLabel.setEnabled(enabled);
		textField.setEnabled(enabled);
		rdbtnDistinto.setEnabled(enabled);
		rdbtnIgual.setEnabled(enabled);
	}
	@Override
	public AssociatedFieldValueForSearch getAssociatedValues() {
		return new AssociatedFieldValueStringForSearch(associatedField,
				rdbtnIgual.isSelected(), textField.getText());
	}
}