package ui.mailing;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.converter.core.XWPFConverterException;
import org.apache.poi.xwpf.converter.pdf.PdfConverter;
import org.apache.poi.xwpf.converter.pdf.PdfOptions;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

public class Prueba {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//try {
			//POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream("screenshoots/modeloagradabril.doc"));
			//MSWord2HtmlExtractor extractor=new MSWord2HtmlExtractor(new FileInputStream("screenshoots/modeloagradabril.doc"));
			//extractor.extractParagraphTexts("prueba", "extraidoAHtml");
			//extractor.extractImagesIntoDirectory("lasImagenes");
			//createLetterForPersons();
			modifyDocx();
			/**POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream("screenshoots/modeloagradabrilConImagen.doc"));
			HWPFDocument document = new HWPFDocument(fs);
			
			//createHTML(document);
			PicturesTable pt=document.getPicturesTable();
			List<Picture> pictures=pt.getAllPictures();
			int in=0;
			for (Iterator iterator = pictures.iterator(); iterator.hasNext();) {
				Picture picture = (Picture) iterator.next();
				picture.writeImageContent(new FileOutputStream(new File("Image"+in)));
				
				in++;
			}
			
			Range range = document.getRange();
			
			for (int i = 0; i < range.numSections(); i++) {
				System.out.println("Section "+i);
				Section section= range.getSection(i);
				for (int j = 0; j < section.numParagraphs(); j++) {
					Paragraph paragraph= section.getParagraph(j);
					System.out.println("paragrahp "+j);
					System.out.println(paragraph.text());
					if(paragraph.text().contains("�genero�")){
						int offset = paragraph.text().indexOf("�genero�");
						paragraph.replaceText("�genero�", "o", offset);
					}
					if(paragraph.text().contains("�nombre�")){
						int offset = paragraph.text().indexOf("�nombre�");
						paragraph.replaceText("�nombre�", "Santiago", offset);
					}
				}
			}
			
			
			for (int i = 0; i < range.numSections(); i++) {
				System.out.println("Section "+i);
				Section section= range.getSection(i);
				for (int j = 0; j < section.numParagraphs(); j++) {
					Paragraph paragraph= section.getParagraph(j);
					System.out.println("paragrahp "+j);
					System.out.println(paragraph.text());
				}
			}
			
			
			
			 document.write(new FileOutputStream(new File("Modificado.doc")));
			
			 
			// fs = new POIFSFileSystem(new FileInputStream("Modificado.doc"));
			 //document = new HWPFDocument(fs);
				
			
			
			 
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}**/
		
		

	}

	/**private static void createLetterForPersons() {
		XWPFDocument doc = new XWPFDocument();
		
		
		//Creo vector con nombres para probar
		Vector<String> persons=new Vector<String>();
		persons.add("Santiago");
		persons.add("Daiana");
		persons.add("Pampi");
		
		
		
		
	}*/

	private static void modifyDocx() {
		
		
		try {
			//POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream("screenshoots/modeloagradabril.doc"));
			XWPFDocument document = new XWPFDocument(OPCPackage.openOrCreate(new File("screenshoots/modeloagradabrilConImagen.docx")));
			
			
			
			List<XWPFParagraph> paragraphs=document.getParagraphs();
			for (Iterator<XWPFParagraph> iterator = paragraphs.iterator(); iterator.hasNext();) {
				XWPFParagraph xwpfParagraph = (XWPFParagraph) iterator.next();
				System.out.println(xwpfParagraph.getParagraphText());
				if(xwpfParagraph.getParagraphText().contains("�genero�")){
					replaceTextInParagraph(xwpfParagraph,"�genero�","o");
				}
				if(xwpfParagraph.getParagraphText().contains("�nombre�")){
					replaceTextInParagraph(xwpfParagraph,"�nombre�","Santiago");
				}
				if(xwpfParagraph.getParagraphText().contains("�donadot�")){
					replaceTextInParagraph(xwpfParagraph,"�donadot�","100");
				}
			}
			
			
		
			 document.write(new FileOutputStream(new File("Modificado.docx")));
			 saveAsPDF(document);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static void saveAsPDF(XWPFDocument document) {
		// 2) Prepare Pdf options
        PdfOptions options = PdfOptions.create();

        // 3) Convert XWPFDocument to Pdf
        OutputStream out;
		try {
			out = new FileOutputStream(new File(
			        "HelloWorld.pdf"));//�Deberia ser un archivo temporal?
			 PdfConverter.getInstance().convert(document, out, options);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (XWPFConverterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
	}

	private static void replaceTextInParagraph(XWPFParagraph xwpfParagraph, String valueToSearch, String valueToReplace) {
		List<XWPFRun> runs = xwpfParagraph.getRuns();
		boolean replaced=false;
		for (int i = 0; i < runs.size(); i++) {
			if(!replaced){
				String oneparaString = runs.get(i).getText(
			            runs.get(i).getTextPosition());
				
				if(oneparaString.contains(valueToSearch))
					runs.get(i).setText(oneparaString.replaceAll(valueToSearch, valueToReplace), 0);
				else{
					int index=oneparaString.indexOf("�");
					if(index!=-1){
						//Obtengo el valor hasta el final
						String subString= oneparaString.substring(index, oneparaString.length());
						
						int hasta=-1;
						for (int j = (i+1); (j < runs.size()) && (hasta==(-1)); j++) {
							String oneparaString2 = runs.get(j).getText(
						            runs.get(j).getTextPosition());
							if(oneparaString2.contains("�")){
								subString=subString.concat(oneparaString2.substring(0, oneparaString2.indexOf("�")+1));
								hasta=j;
							}else{
								subString=subString.concat(oneparaString2);
							}
						}
						
						if(hasta!=-1){
							if(valueToSearch.equals(subString)){
								String newText=oneparaString.replaceAll(oneparaString.substring(index, oneparaString.length()), valueToReplace);
								runs.get(i).setText(newText, 0);
								for (int j = (i+1); j <= hasta; j++) {
									
									if(j==hasta){
										String oneparaString2 = runs.get(j).getText(runs.get(j).getTextPosition());
										
									//	oneparaString2.substring(0, oneparaString2.indexOf("�")+1)
										runs.get(j).setText(oneparaString2.substring(oneparaString2.indexOf("�")+1,oneparaString2.length() ), 0);
									}else{
										runs.get(j).setText("", 0);
									}
								}
								
							}
							
						}
					}
				}
			}
			
		}
	}

/**	private static void createHTML(HWPFDocument wordDocument) {
		Document newDocument;
		try {
			newDocument = DocumentBuilderFactory.newInstance()
			        .newDocumentBuilder().newDocument();
			 WordToHtmlConverter wordToHtmlConverter = new WordToHtmlConverter(
		                newDocument );
			 
			 wordToHtmlConverter.setPicturesManager( new PicturesManager()
	            {
	                public String savePicture( byte[] content,
	                        PictureType pictureType, String suggestedName,
	                        float widthInches, float heightInches )
	                {
	                    return suggestedName;
	                }
	            } );
			 
			 wordToHtmlConverter.processDocument( wordDocument );

		        StringWriter stringWriter = new StringWriter();

		        Transformer transformer = TransformerFactory.newInstance()
		                .newTransformer();
		        transformer.setOutputProperty( OutputKeys.INDENT, "yes" );
		        transformer.setOutputProperty( OutputKeys.ENCODING, "utf-8" );
		        transformer.setOutputProperty( OutputKeys.METHOD, "html" );
		        transformer.transform(
		                new DOMSource( wordToHtmlConverter.getDocument() ),
		                new StreamResult( stringWriter ) );

		        String result = stringWriter.toString();
		        System.out.println(result);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
	   
		
	}*/

}
