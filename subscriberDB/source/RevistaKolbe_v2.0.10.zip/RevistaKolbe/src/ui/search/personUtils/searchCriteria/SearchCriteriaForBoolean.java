package ui.search.personUtils.searchCriteria;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

public class SearchCriteriaForBoolean extends SearchCriteriaForField{
	
	public SearchCriteriaForBoolean(String field, 
			boolean equals, String columnName) {
		super(field, equals,columnName);
		
	}
	
	@Override
	public String toString() {
		if(equals){
			return field;
		}else{
			return "No "+field;
		}
		
	}

	@Override
	public Criterion getCriterion() {
		Criterion ret=Restrictions.eq(columnName, equals);
		
		return ret;
	}
}
