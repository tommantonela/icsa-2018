package ui.search;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import ui.add.AddDonation;
import ui.add.AddPersonToEvent;
import ui.edit.EditPerson;
import ui.mailing.CreateLetterDialog;
import ui.mailing.MailLabel;
import bd.DataBaseManager;
import bd.pojos.Donation;
import bd.pojos.Person;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Searchresults extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4465210599980548074L;
	private JPanel contentPane;
	private JTable table;
	private String[][] tableData;
	private JPopupMenu popup;
	private List<Person> results;
	private JMenuBar menuBar;
	private JMenu mnExportar;
	private JMenuItem mntmExportarAExcel;
	private JLabel numberOfResults;
	private JMenu mnCorrespondencia;
	private JMenuItem mntmEnviar;
	private JMenuItem mntmImprimirEtiquetas;
	private Hashtable<Person, Donation> donationsOfLastSearch;
	private JTextField textField;
	private JComboBox comboBox;
	/**
	 * Create the frame.
	 * @param donationsOfLastSearch 
	 */
	public Searchresults(List<Person> results, Hashtable<Person, Donation> donationsOfLastSearch) {
		this.results=results;
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1235, 546);
		this.donationsOfLastSearch=donationsOfLastSearch;
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnExportar = new JMenu("Exportar");
		menuBar.add(mnExportar);
		
		mntmExportarAExcel = new JMenuItem("Exportar a Excel");
		mntmExportarAExcel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				exportToExcel();
			}
		});
		mnExportar.add(mntmExportarAExcel);
		
		mnCorrespondencia = new JMenu("Correspondencia");
		menuBar.add(mnCorrespondencia);
		
		mntmEnviar = new JMenuItem("Crear cartas");
		mntmEnviar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				createLetterClicked();
			}
		});
		mnCorrespondencia.add(mntmEnviar);
		
		mntmImprimirEtiquetas = new JMenuItem("Imprimir etiquetas");
		mntmImprimirEtiquetas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				printLabelsClicked();
			}
		});
		mnCorrespondencia.add(mntmImprimirEtiquetas);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		numberOfResults = new JLabel(results.size()+" personas encontradas");
		numberOfResults.setHorizontalAlignment(SwingConstants.CENTER);
		
		
		JScrollPane scrollPane = new JScrollPane();
		
		table = new JTable();
		updateTable();
	
		
		
		
		
		scrollPane.setViewportView(table);
		
		ComboBoxModel jComboBox1Model = 
				new DefaultComboBoxModel(new String[]{"Nombre","Apellido"});
		comboBox = new JComboBox();
		comboBox.setModel(jComboBox1Model);
		
		textField = new JTextField();
		textField.setColumns(10);
		
		JButton btnEncontrar = new JButton("Encontrar");
		btnEncontrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				encontrarButtonClicked();
			}
		});
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(417)
							.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnEncontrar))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(379)
							.addComponent(numberOfResults, GroupLayout.PREFERRED_SIZE, 440, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 1214, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnEncontrar))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(numberOfResults)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 434, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		popup = new JPopupMenu();
        
		JMenuItem addDonation = new JMenuItem("Agregar donación");
		addDonation.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				addDonation();
			}
		});
		popup.add(addDonation);
		
		JMenuItem listDonations = new JMenuItem("Listar donaciones");
		listDonations.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				listDonation();
			}
		});
		popup.add(listDonations);
        
     
        JMenuItem eventAssistance = new JMenuItem("Asistencia a eventos");
        eventAssistance.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				addPersonToEvent();
			}
		});
        popup.add(eventAssistance);
        
        JMenuItem modifyPerson = new JMenuItem("Modificar datos");
        modifyPerson.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				modifyPerson();
			}
		});
        popup.add(modifyPerson);
        
        JMenuItem deletePerson = new JMenuItem("Eliminar persona");
        deletePerson.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				deletePerson();
				
			}
		});
        popup.add(deletePerson);
        
        
        //MouseListener popupListener = new PopupListener(popup);
        //table.addMouseListener(popupListener);
        table.addMouseListener(new MouseAdapter() {
        	public void mousePressed(MouseEvent e) {
				createPopUp(e);
			}

			public void mouseReleased(MouseEvent e) {
				createPopUp(e);
			}
			private void createPopUp(MouseEvent e) {
				
				if(e.isPopupTrigger()&&(table.getSelectedRow()!=-1)){
					 popup.show(e.getComponent(), e.getX(), e.getY());
				}
			}
		});
		this.setVisible(true);
	}

	protected void encontrarButtonClicked() {
		int indexFirstPerson=getIndexOfPerson();
		//Una vez que tengo el lugar de la persona hago un focus
		if(indexFirstPerson!=-1){
			table.requestFocus();
			if(comboBox.getSelectedIndex()==0){
				table.changeSelection(indexFirstPerson,0,false, false);
			}else{
				table.changeSelection(indexFirstPerson,1,false, false);
			}
		}
		
	}
	private int getIndexOfPerson(){
		String stringToSearch=textField.getText().toLowerCase();
		if(comboBox.getSelectedIndex()==0){//Busco por nombre
			for (int i = 0; i < results.size(); i++) {
				Person person=results.get(i);
				if(person.getName().toLowerCase().contains(stringToSearch))
					return i;
			}
		}else{//busco por apellido
			for (int i = 0; i < results.size(); i++) {
				Person person=results.get(i);
				if(person.getFamilyName().toLowerCase().contains(stringToSearch))
					return i;
			}
		}
		return -1;
	}

	private void listDonation() {
		List<Donation> donationsFoPerson=DataBaseManager.getInstance().listDonationsForPerson(getSelectedPerson());
		
		Collections.sort(donationsFoPerson, new Comparator<Donation>() {
		    public int compare(Donation m1, Donation m2) {
		    	return m1.getDate().compareTo(m2.getDate());
		    }
		});
		
		new SearchDonationsResults(donationsFoPerson);
		
	}

	private void printLabelsClicked() {
		//Ordeno los resultados por misionero->por zona->por ciudad
		Vector<Person> orderedPersonsByZone=orderPersonsByDeliveryZone();
		//Creo el vector de MailLbel
		Vector<MailLabel> mailLabelBeans=new Vector<MailLabel>();
		for (Iterator<Person> iterator = orderedPersonsByZone.iterator(); iterator
				.hasNext();) {
			Person person = (Person) iterator.next();
			MailLabel newLabel=new MailLabel();
			newLabel.setFamilyNameAndName(person.getFamilyName()+" "+person.getName());
			newLabel.setCpAndCity("("+person.getPostalNumber()+") "+person.getCity());
			
			String houseNeighborhoodFloorFlatNumber="";
			if(person.getHouse().length()>0)
				houseNeighborhoodFloorFlatNumber=houseNeighborhoodFloorFlatNumber+"Casa: "+person.getHouse()+" ";
			if(person.getNeighborhood().length()>0)
				houseNeighborhoodFloorFlatNumber=houseNeighborhoodFloorFlatNumber+" Bº: "+person.getNeighborhood()+" ";
			if(person.getFloor().length()>0)
				houseNeighborhoodFloorFlatNumber=houseNeighborhoodFloorFlatNumber+" Piso: "+person.getFloor()+" ";
			if(person.getFlatNumber().length()>0)
				houseNeighborhoodFloorFlatNumber=houseNeighborhoodFloorFlatNumber+" Dept: "+person.getFlatNumber()+" ";
			
			
			newLabel.setHouseNeighborhoodFloorFlatNumber(houseNeighborhoodFloorFlatNumber);
			newLabel.setProvinceAndCountry(person.getProvince()+" - "+person.getCountry());
			newLabel.setStreetAndHouseNumber(person.getStreet()+" "+person.getHouseNumber());
			
			String zoneAndDistributor="";
			if(person.getDistributor()!=null){
				bd.pojos.Label misionero=person.getDistributor().getLabel("Misionero de la prensa");
				
				zoneAndDistributor=person.getDistributor().getAssociatedFieldValuesForLabel(misionero, misionero.getAssociatedFields().iterator().next()).getValueOfField();
				zoneAndDistributor=zoneAndDistributor+" "+person.getDistributor().getFamilyName()+" "+person.getDistributor().getName();
			}
			
			if(person.getNumberOfCopies()!=null && person.getNumberOfCopies().length()>0){//Si recibe mas de una copia lo agrego a la etiqueta
				try{
					int numberOfCopies=new Integer(person.getNumberOfCopies());
					if(numberOfCopies>1){
						zoneAndDistributor=zoneAndDistributor+" C:"+numberOfCopies;
					}
				}catch(Exception e){e.printStackTrace();}
			}
			
			if(person.getKindOfShipping()!=null){//Agrego una indicacion de por donde se enviara la etiqueta
				if(person.getKindOfShipping().equals("Correo Argentino")){
					zoneAndDistributor=zoneAndDistributor+" (CA)";
				}else if(person.getKindOfShipping().equals("Oca")){
					zoneAndDistributor=zoneAndDistributor+" (OCA)";
				}
			}
			
			newLabel.setZoneAndDistributor(zoneAndDistributor);
			
			newLabel.setCommentOfLabel(person.getCommentOfLabel());
			
			
			mailLabelBeans.add(newLabel);
			
			
			if(person.getNumberOfLabels()!=null &&person.getNumberOfLabels().length()>0){//Agrego mas veces el label en caso de que sea mayor que 1
				try{
					int numberOfLabels=new Integer(person.getNumberOfLabels());
					if(numberOfLabels>1){
						for (int i = 1; i < numberOfLabels; i++) {
							mailLabelBeans.add(newLabel);
						}
					}
				}catch(Exception e){e.printStackTrace();}
			}
			
			
		}
		//Creo el reporte
		ui.mailing.JasperReportBuilder.createReport("labels/labelTemplate.jasper", mailLabelBeans);
	}

	private Vector<Person> orderPersonsByDeliveryZone() {
		Vector<Person> aux=new Vector<Person>();
		for (Iterator<Person> iterator = results.iterator(); iterator.hasNext();) {
			Person person = (Person) iterator.next();
			aux.add(person);
		}
		
		Collections.sort(aux, new Comparator<Person>() {
		    public int compare(Person m1, Person m2) {
		    	//the value 0 if the argument Date is equal to this Date; a value less than 0 if this Date is before the Date argument; and a value greater than 0 if this Date is after the Date argument.
		       if(m1.getCity().equals(m2.getCity())){
		    	   if((m1.getDistributor()==null)&&(m2.getDistributor()==null))
			        	return 0;
			        else if((m1.getDistributor()!=null)&&(m2.getDistributor()==null))
			        	return 1;
			        else if((m1.getDistributor()==null)&&(m2.getDistributor()!=null))
			        	return -1;
			        else{
			        	bd.pojos.Label misionero1=m1.getDistributor().getLabel("Misionero de la prensa");
			        	bd.pojos.Label misionero2=m2.getDistributor().getLabel("Misionero de la prensa");
			        	
						return m1.getDistributor().getAssociatedFieldValuesForLabel(misionero1, misionero1.getAssociatedFields().iterator().next()).getValueOfField().compareTo(m2.getDistributor().getAssociatedFieldValuesForLabel(misionero2, misionero2.getAssociatedFields().iterator().next()).getValueOfField());
			        }
		       }else{
		    	   return m1.getCity().compareTo(m2.getCity());
		       }
		    	
		    	
		    }
		});
		return aux;
	}

	private void createLetterClicked() {
		new CreateLetterDialog(results,donationsOfLastSearch);
		
	}

	private void updateTable() {
		tableData=new String[results.size()][18];
		for (int i = 0; i < results.size(); i++) {
			Person person=results.get(i);	
			tableData[i][0]=person.getName();
			tableData[i][1]=person.getFamilyName();
			tableData[i][2]=person.getPhone();
			tableData[i][3]=person.getCellPhone();
			tableData[i][4]=person.getEmail();
			
			tableData[i][5]=person.getStreet();
			tableData[i][6]=person.getHouseNumber();
			tableData[i][7]=person.getNeighborhood();
			tableData[i][8]=person.getHouse();
			tableData[i][9]=person.getFloor();
			tableData[i][10]=person.getFlatNumber();
			
			
			tableData[i][11]=person.getCity();
			tableData[i][12]=person.getProvince();
			
			tableData[i][13]=person.getCountry();
			tableData[i][14]=person.getPostalNumber();
			if(person.isReceivesMagazine())
				tableData[i][15]="Si";
			else 
				tableData[i][15]="No";
			tableData[i][16]=person.getKindOfShipping();
			
			tableData[i][17]=calculateLastYearDonationForPerson(person);
		}
		TableModel tableModel = new DefaultTableModel(
				tableData, new String[] { "Nombre", "Apellido","Telefono","Celular","Email","Calle","Número","Barrio","Casa","Piso","Depto.","Ciudad","Provincia","Pais","C.P.","Recibe la revista", "Tipo de envio", "Donaciones ultimo año" });
		table.setModel(tableModel);
	}
	
	private String calculateLastYearDonationForPerson(Person person) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		
		Date today=cal.getTime();
		
		cal.add(Calendar.YEAR, -1);
		
		Date aYearAgo=cal.getTime();
		
		float totalDonations=0;
		List<Donation> donationsLastYear=DataBaseManager.getInstance().listDonationsForPersonBetweenDates(person, aYearAgo, today);
		for (Iterator<Donation> iterator = donationsLastYear.iterator(); iterator
				.hasNext();) {
			Donation donation = (Donation) iterator.next();
			totalDonations=totalDonations+donation.getAmount();
		}
		
		
		return totalDonations+"";
	}

	private void addDonation() {
		new AddDonation(getSelectedPerson());
	}

	protected void addPersonToEvent() {
		new AddPersonToEvent(getSelectedPerson());
		
	}

	private void exportToExcel() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Elija el archivo a guardar");    
		 
		int userSelection = fileChooser.showSaveDialog(this);
		 
		if (userSelection == JFileChooser.APPROVE_OPTION) {
		    File fileToSave = fileChooser.getSelectedFile();
		    String filePath = fileToSave.getPath();
		    if(!filePath.toLowerCase().endsWith(".xls"))
		    {
		    	fileToSave = new File(filePath + ".xls");
		    }
		    export(fileToSave);
		    
		}
		
	}
	private boolean export(File file){
		try
		{
		//Nuestro flujo de salida para apuntar a donde vamos a escribir
		DataOutputStream out=new DataOutputStream(new FileOutputStream(file));
		 
		//Representa nuestro archivo en excel y necesita un OutputStream para saber donde va locoar los datos
		WritableWorkbook w = Workbook.createWorkbook(out);
		 
		 
		//Como excel tiene muchas hojas esta crea o toma la hoja
		//Coloca el nombre del "tab" y el indice del tab
		WritableSheet s = w.createSheet("Resultados", 0);
		 
		for(int i=0;i< table.getRowCount();i++){	
			for(int j=0;j<table.getColumnCount();j++){
				Object objeto=table.getValueAt(i,j);
					s.addCell(new Label(j, i, String.valueOf(objeto)));        
		}
		}
		w.write();

		//Cerramos el WritableWorkbook y DataOutputStream
		w.close();
		out.close();
		 
		 
		//si todo sale bien salimos de aqui con un true :D
		return true;
		 
		}catch(IOException ex){ex.printStackTrace();}
		catch(WriteException ex){ex.printStackTrace();}
		 
		//Si llegamos hasta aqui algo salio mal
		return false;
	}
	private void deletePerson(){
		Person selectedPerson=getSelectedPerson();
		if( (selectedPerson.hasLabel("Misionero de la prensa"))&& (DataBaseManager.getInstance().peopleWhoDistributed(selectedPerson).size()>0) ){//Chequeo si es misionero y si hay gente hay su cargo
			JOptionPane.showConfirmDialog(
				    this,
				    "Esta persona no puede eliminarse dado que es un misionero de la prensa con repartos a su cargo. Modifique antes las personas a quienes reparte",
				    "Atención!",
				    JOptionPane.PLAIN_MESSAGE);
		}else{
			DataBaseManager.getInstance().deletePerson(selectedPerson);
			results.remove(selectedPerson);
			numberOfResults.setText(results.size()+" personas encontradas");
			updateSearchValue();
		}
	}

	private Person getSelectedPerson() {
		Person selectedPerson=results.get(table.getSelectedRow());
		return selectedPerson;
	}
	private void modifyPerson() {
		new EditPerson(getSelectedPerson(), this);
	}
	public void updateSearchValue(){
		updateTable();
		table.validate();
	}
}
