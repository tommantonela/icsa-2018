package ui.add.label.modifyAssociationField;

import java.awt.Dimension;

import javax.swing.GroupLayout;
import javax.swing.JLabel;

import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;



import bd.pojos.AssociatedField;


public class SimpleDatePanelForLabel extends AssociatedFieldPanelForLabel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7368540804734117330L;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JLabel lblNewLabel;
	
	private JLabel label;
	private JLabel label_1;
	
	public SimpleDatePanelForLabel(AssociatedField associatedField, String value) {
		
		
		
		
		textField_1 = new JTextField();
		textField_1.setToolTipText("D\u00EDa");
		textField_1.setColumns(10);
		
		label = new JLabel("/");
		
		textField_2 = new JTextField();
		textField_2.setToolTipText("Mes");
		textField_2.setColumns(10);
		
		label_1 = new JLabel("/");
		
		textField_3 = new JTextField();
		textField_3.setToolTipText("A\u00F1o");
		textField_3.setColumns(10);
		
		String[] date=value.split("/");
		if(date.length==3){
			textField_1.setText(date[0]);
			textField_2.setText(date[1]);
			textField_3.setText(date[2]);
		}
		
		lblNewLabel = new JLabel(associatedField.getName());
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(6)
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 76, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
					.addGap(6)
					.addComponent(label, GroupLayout.PREFERRED_SIZE, 7, GroupLayout.PREFERRED_SIZE)
					.addGap(6)
					.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
					.addGap(6)
					.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 7, GroupLayout.PREFERRED_SIZE)
					.addGap(6)
					.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
					.addGap(95))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
							.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(lblNewLabel))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addComponent(label))
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addComponent(label_1))
						.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(73, Short.MAX_VALUE))
		);
		setLayout(groupLayout);
		this.setPreferredSize(new Dimension(275, 39));
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return textField_1.getText()+"/"+
		textField_2.getText()+"/"+
		textField_3.getText();
	}
	
	
	
}
