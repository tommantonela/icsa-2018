package bd.pojos;

import java.util.Date;

public class Donation {
	private Long id;
	private Date date;
	private String meansOfPayment;
	private Float amount;
	private Person donor; 
	public Donation() {
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getMeansOfPayment() {
		return meansOfPayment;
	}
	public void setMeansOfPayment(String meansOfPayment) {
		this.meansOfPayment = meansOfPayment;
	}
	public Float getAmount() {
		return amount;
	}
	public void setAmount(Float amount) {
		this.amount = amount;
	}
	public Person getDonor() {
		return donor;
	}
	public void setDonor(Person donor) {
		this.donor = donor;
	}
}
