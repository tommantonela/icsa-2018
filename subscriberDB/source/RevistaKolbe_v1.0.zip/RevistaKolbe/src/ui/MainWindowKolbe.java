package ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import bd.DataBaseManager;
import bd.HSQLServer;
import bd.pojos.AssociatedField;
import bd.pojos.Label;

import ui.add.AddEvent;
import ui.add.AddLabel;
import ui.add.AddPersonFrame;
import ui.search.SearchPerson;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashSet;
import java.util.Set;

public class MainWindowKolbe {

	private JFrame frmMisionerasDeLa;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					MainWindowKolbe window = new MainWindowKolbe();
					window.frmMisionerasDeLa.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainWindowKolbe() {
		initialize();
		//loadDatabaseForTesting();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMisionerasDeLa = new JFrame();
		frmMisionerasDeLa.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
				HSQLServer.getInstance().stopFatabase();
			}
		});
		frmMisionerasDeLa.setTitle("Misioneras de la Inmaculada Padre Kolbe");
		frmMisionerasDeLa.setBounds(100, 100, 800, 85);
		frmMisionerasDeLa.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frmMisionerasDeLa.setJMenuBar(menuBar);
		
		JMenu mnAgregar = new JMenu("Agregar");
		menuBar.add(mnAgregar);
		
		JMenuItem mntmPersona = new JMenuItem("Persona");
		mntmPersona.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				openAddPersonFrame();
			}
		});
		mnAgregar.add(mntmPersona);
		
		JMenuItem mntmEtiqueta = new JMenuItem("Etiqueta");
		mntmEtiqueta.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new AddLabel();
			}
		});
		mnAgregar.add(mntmEtiqueta);
		
		JMenuItem mntmEvento = new JMenuItem("Evento");
		mntmEvento.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new AddEvent();
			}
		});
		mnAgregar.add(mntmEvento);
		
		JMenu mnBuscar = new JMenu("Buscar");
		menuBar.add(mnBuscar);
		
		JMenuItem mntmBuscarPersona = new JMenuItem("Buscar Persona");
		mntmBuscarPersona.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new SearchPerson();
			}
		});
		mnBuscar.add(mntmBuscarPersona);
		
		JMenuItem mntmBuscarDonacin = new JMenuItem("Buscar Donaci\u00F3n");
		mnBuscar.add(mntmBuscarDonacin);
	}
	private void openAddPersonFrame(){
		new AddPersonFrame();
	}
/*	private void loadDatabaseForTesting(){
		bd.pojos.Label l=new Label();
		l.setName("Misionera que vive en familia");
		DataBaseManager.getInstance().saveEntity(l);
		l=new Label();
		l.setName("Familiar misionera");
		DataBaseManager.getInstance().saveEntity(l);
		l=new Label();
		l.setName("Consagrado a la Virgen");
		DataBaseManager.getInstance().saveEntity(l);
		l=new Label();
		l.setName("Voluntario");
		DataBaseManager.getInstance().saveEntity(l);
		l=new Label();
		l.setName("Aspirante");
		DataBaseManager.getInstance().saveEntity(l);
		l=new Label();
		l.setName("Bienhechor");
		DataBaseManager.getInstance().saveEntity(l);
		l=new Label();
		l.setName("Amigo");
		DataBaseManager.getInstance().saveEntity(l);
		l=new Label();
		l.setName("Catequista");
		DataBaseManager.getInstance().saveEntity(l);
		l=new Label();
		l.setName("Sacerdote");
		DataBaseManager.getInstance().saveEntity(l);
		l=new Label();
		l.setName("Consagrada");
		Set<AssociatedField> associatedFields=new HashSet<AssociatedField>();
		AssociatedField af=new AssociatedField();
		af.setName("Fecha de consagraci�n");
		af.setType(AssociatedField.date_Type);
		associatedFields.add(af);
		l.setAssociatedFields(associatedFields);
		DataBaseManager.getInstance().saveEntity(l);
	}*/
}
