package ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import bd.DataBaseManager;
import bd.HSQLServer;
import bd.pojos.AssociatedField;
import bd.pojos.Label;

import ui.add.AddEvent;
import ui.add.AddLabel;
import ui.add.AddPersonFrame;
import ui.edit.EditEvents;
import ui.edit.EditLabels;
import ui.search.SearchDonations;
import ui.search.SearchPerson;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashSet;
import java.util.Set;
import java.util.prefs.Preferences;

import javax.swing.JCheckBoxMenuItem;

public class MainWindowKolbe {

	private JFrame frmMisionerasDeLa;
	private JCheckBoxMenuItem chckbxmntmServer;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					MainWindowKolbe window = new MainWindowKolbe();
					window.frmMisionerasDeLa.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainWindowKolbe() {
		initialize();
		
		//System.out.println(DataBaseManager.getInstance().listAssociatedField().size());
		//System.out.println(DataBaseManager.getInstance().listPersons().get(0).getAssociatedFieldValues().size());
		//loadDatabaseForTesting();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMisionerasDeLa = new JFrame();
		frmMisionerasDeLa.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
				HSQLServer.getInstance().stopFatabase();
			}
		});
		frmMisionerasDeLa.setTitle("Misioneras de la Inmaculada Padre Kolbe");
		frmMisionerasDeLa.setBounds(100, 100, 800, 85);
		frmMisionerasDeLa.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frmMisionerasDeLa.setJMenuBar(menuBar);
		
		JMenu mnAgregar = new JMenu("Agregar");
		menuBar.add(mnAgregar);
		
		JMenuItem mntmPersona = new JMenuItem("Persona");
		mntmPersona.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				openAddPersonFrame();
			}
		});
		mnAgregar.add(mntmPersona);
		
		JMenuItem mntmEtiqueta = new JMenuItem("Etiqueta");
		mntmEtiqueta.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new AddLabel();
			}
		});
		mnAgregar.add(mntmEtiqueta);
		
		JMenuItem mntmEvento = new JMenuItem("Evento");
		mntmEvento.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new AddEvent();
			}
		});
		mnAgregar.add(mntmEvento);
		
		JMenu mnBuscar = new JMenu("Buscar");
		menuBar.add(mnBuscar);
		
		JMenuItem mntmBuscarPersona = new JMenuItem("Buscar Persona");
		mntmBuscarPersona.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new SearchPerson();
			}
		});
		mnBuscar.add(mntmBuscarPersona);
		
		JMenuItem mntmBuscarDonacin = new JMenuItem("Buscar Donaci\u00F3n");
		mntmBuscarDonacin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new SearchDonations();
			}
		});
		mnBuscar.add(mntmBuscarDonacin);
		
		JMenu mnModificar = new JMenu("Modificar");
		menuBar.add(mnModificar);
		
		JMenuItem mntmEtiquetas = new JMenuItem("Etiquetas");
		mntmEtiquetas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new EditLabels();
			}
		});
		mnModificar.add(mntmEtiquetas);
		
		JMenuItem mntmEventos = new JMenuItem("Eventos");
		mntmEventos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				modifyEvents();
			}
		});
		mnModificar.add(mntmEventos);
		
		JMenu mnConfiguracin = new JMenu("Configuraci\u00F3n");
		menuBar.add(mnConfiguracin);
		
		chckbxmntmServer = new JCheckBoxMenuItem("Server");
		chckbxmntmServer.setSelected(Preferences.userNodeForPackage(MainWindowKolbe.class).getBoolean("EsServidor", true));
		chckbxmntmServer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				chckbxmntmServerChanged(chckbxmntmServer.isSelected());
			}
		});
		mnConfiguracin.add(chckbxmntmServer);
	}
	private void chckbxmntmServerChanged(boolean selected) {
		Preferences.userNodeForPackage(MainWindowKolbe.class).putBoolean("EsServidor", selected);
		
	}

	private void modifyEvents() {
		new EditEvents();
		
	}

	private void openAddPersonFrame(){
		new AddPersonFrame();
	}
	
}
