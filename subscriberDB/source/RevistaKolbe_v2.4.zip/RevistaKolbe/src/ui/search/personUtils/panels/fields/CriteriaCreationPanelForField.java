package ui.search.personUtils.panels.fields;

import ui.search.personUtils.panels.CriteriaCreationPanel;




public abstract class CriteriaCreationPanelForField extends CriteriaCreationPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3245753664580179045L;
	protected String field;
	protected String columnName;
	public CriteriaCreationPanelForField(String fieldToSearch, String columnName) {
		field=fieldToSearch;
		this.columnName=columnName;
	}
	
	
}
