package ui.add;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import bd.DataBaseManager;
import bd.pojos.AssociatedField;
import bd.pojos.AssociatedFieldValueForLabel;
import bd.pojos.Label;
import bd.pojos.Person;

public class EditLabel extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1425106794317779009L;
	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private String[][] tableData;
	private JComboBox comboBox;
	private List<Label> labelsInComboBox;
	
	private JButton btnEliminarEtiqueta;
	private JButton btnNewButton;
	private JScrollPane scrollPane;
	private JPanel panel;
	private Vector<JTextField> currentAssociatedFields;
	private Vector<Label> labelsSelected;
	private Vector<Vector<String>> selectedAssociatedFieldsLabels;
	private Person person;
	

	/**
	 * Create the dialog.
	 */
	public EditLabel(Person personToCreate) {
		person=personToCreate;
		setTitle("Editar etiquetas");
		setBounds(100, 100, 468, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		JLabel lblLabel = new JLabel("Etiquetas");
		labelsSelected=new Vector<Label>();
		currentAssociatedFields=new Vector<JTextField>();
		selectedAssociatedFieldsLabels=new Vector<Vector<String>>();
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				comboBoxChange();
			}
		});
		
		
		btnNewButton = new JButton("Agregar\n\n");
		btnNewButton.setEnabled(false);
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				addLabelButtonClicked();
			}
		});
		
		scrollPane = new JScrollPane();
		scrollPane.setVisible(false);
		
		panel = new JPanel();
		 panel.setLayout(null);
		scrollPane.setViewportView(panel);
		//scrollPane.getViewport().setBackground(UIManager.getColor("InternalFrame.background"));
		
		JScrollPane scrollPane_1 = new JScrollPane();
		
		btnEliminarEtiqueta = new JButton("Eliminar etiqueta");
		btnEliminarEtiqueta.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnEliminarEtiquetaClicked();
			}
		});
		btnEliminarEtiqueta.setEnabled(false);
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, 242, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnEliminarEtiqueta)
							.addGap(158))
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING, false)
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addComponent(lblLabel)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(comboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(btnNewButton))
								.addComponent(scrollPane, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 428, GroupLayout.PREFERRED_SIZE))
							.addContainerGap())))
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblLabel)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 66, GroupLayout.PREFERRED_SIZE)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGap(26)
							.addComponent(btnEliminarEtiqueta))
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(scrollPane_1, GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)))
					.addContainerGap())
		);
		
		 
		
		tableData=new String[0][1];
		TableModel tableModel = new DefaultTableModel(
				tableData, new String[] { "Etiquetas seleccionadas" });
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				tableClicked();
			}
		});
		table.setModel(tableModel);
		scrollPane_1.setViewportView(table);
		contentPanel.setLayout(gl_contentPanel);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Aceptar");
				okButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						okButtonClicked();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancelar");
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						cancelButtonClicked();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		loadLabels();
		comboBox.setSelectedIndex(-1);
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}

	

	
	private void okButtonClicked() {
		HashSet<Label> labels=new HashSet<Label>();
		HashSet<AssociatedFieldValueForLabel> associatedFieldValues=new HashSet<AssociatedFieldValueForLabel>();
		int index=0;
		for (Iterator<Label> iterator = labelsSelected.iterator(); iterator.hasNext();) {
			Label label = iterator.next();
			labels.add(label);
			
			Vector<String> associatedFields=selectedAssociatedFieldsLabels.get(index);
			index++;
			
			for (Iterator<AssociatedField> iterator2 = label.getAssociatedFields().iterator(); iterator2
					.hasNext();) {
				AssociatedField field = iterator2.next();
				AssociatedFieldValueForLabel afvl=new AssociatedFieldValueForLabel();
				afvl.setLabel(label);
				afvl.setAssociatedField(field);
				afvl.setValueOfField(associatedFields.remove(0));
				associatedFieldValues.add(afvl);
			}
		}
		person.setLabels(labels);
		
		person.setAssociatedFieldValues(associatedFieldValues);
		this.dispose();
	}




	private void comboBoxChange() {
		if(comboBox.getSelectedItem()!=null){
			btnNewButton.setEnabled(true);
			Label selectedLabel=labelsInComboBox.get(comboBox.getSelectedIndex());
			if(selectedLabel.getAssociatedFields().size()>0){
				panel.removeAll();
				scrollPane.setVisible(false);
				this.validate();
				scrollPane.setVisible(true);
				currentAssociatedFields=new Vector<JTextField>();
				int y=0;
				for (Iterator<AssociatedField> iterator = selectedLabel.getAssociatedFields().iterator(); iterator
						.hasNext();) {
					AssociatedField type = iterator.next();
					JLabel label=new JLabel();
					panel.add(label);
					int x=type.getName().length();
					label.setBounds(5, y, x*8, 16);
					label.setText(type.getName());
					
					if(type.getType().equals(AssociatedField.string_Type)){
						JTextField field= new JTextField();
						panel.add(field);
						field.setBounds(x*8+10, y, 65, 18);
						currentAssociatedFields.add(field);
					}else{
						//Completar para fechas
						JTextField field= new JTextField();
						panel.add(field);
						field.setBounds(x*8+10, y, 30, 18);
						currentAssociatedFields.add(field);
						
						JLabel label1=new JLabel();
						panel.add(label1);
						label1.setBounds(x*8+40, y, 8, 16);
						label1.setText("/");
						
						JTextField field2= new JTextField();
						panel.add(field2);
						field2.setBounds(x*8+48, y, 30, 18);
						currentAssociatedFields.add(field2);
						
						JLabel label2=new JLabel();
						panel.add(label2);
						label2.setBounds(x*8+78, y, 8, 16);
						label2.setText("/");
						
						JTextField field3= new JTextField();
						panel.add(field3);
						field3.setBounds(x*8+86, y, 50, 18);
						currentAssociatedFields.add(field3);
					}
					y=y+20;
					panel.setPreferredSize(new Dimension(180,y));
				}
				
				//scrollPane.getViewport().setBackground(UIManager.getColor("InternalFrame.background"));
				//scrollPane.setBackground(UIManager.getColor("InternalFrame.background"));
			}else{
				panel.removeAll();
				scrollPane.setVisible(false);
			}
			this.validate();
		}
		
	}

	private void cancelButtonClicked() {
		this.dispose();
	}

	private void loadLabels() {
		labelsInComboBox=DataBaseManager.getInstance().listLabels();
		//Filtro los labels que ya han sido utilizados
		//private Vector<Label> labelsSelected;
		//private Vector<Vector<String>> selectedAssociatedFieldsLabels;
		;
		if(person.getLabels()!=null){
			for (Iterator<Label> iterator = person.getLabels().iterator(); iterator.hasNext();) {
				Label label = iterator.next();
				labelsInComboBox.remove(label);
				labelsSelected.add(label);
				
				Vector<String> associatedFieldsLabels=new Vector<String>();
				for (Iterator<AssociatedField> iterator2 = label.getAssociatedFields().iterator(); iterator2
						.hasNext();) {
					AssociatedField field = iterator2.next();
					AssociatedFieldValueForLabel associatedFieldValue=person.getAssociatedFieldValuesForLabel(label,field);
					
					associatedFieldsLabels.add(associatedFieldValue.getValueOfField());
					
				}
				selectedAssociatedFieldsLabels.add(associatedFieldsLabels);
				//Actualizo las tablas
				addLabelToTable(label);
			}
		}
		
		createComboBoxModelOfLabels();
	}
	private void createComboBoxModelOfLabels(){
		String[] labelsNames=new String[labelsInComboBox.size()];
		for (int i = 0; i < labelsInComboBox.size(); i++) {
			labelsNames[i]=labelsInComboBox.get(i).getName();
		}
		
		ComboBoxModel jComboBox1Model2 = 
				new DefaultComboBoxModel(labelsNames);
		comboBox.setModel(jComboBox1Model2);
	}
	private void tableClicked() {
		if ((table.getSelectedRow() != -1)
				&& (tableData.length > 0))
			btnEliminarEtiqueta.setEnabled(true);
		else
			btnEliminarEtiqueta.setEnabled(false);
		
	}
	
	private void btnEliminarEtiquetaClicked() {
		int selectedRow = table.getSelectedRow();
		String[][] newscheduleTableModel = new String[tableData.length - 1][1];
		TableModel tm = table.getModel();
		for (int i = 0; i < selectedRow; i++)
				newscheduleTableModel[i][0] = (String) tm.getValueAt(i, 0);
		for (int i = selectedRow; i < tableData.length - 1; i++)
				newscheduleTableModel[i][0] = (String) tm.getValueAt(i + 1, 0);
		
		tableData = newscheduleTableModel;
		table.setModel(new DefaultTableModel(tableData,
				new String[] { "Etiquetas seleccionadas" }));
		btnEliminarEtiqueta.setEnabled(false);
		
		//Guardo el que saque en el JComboBox
		Label removedLabel=labelsSelected.remove(selectedRow);
		labelsInComboBox.add(removedLabel);
		createComboBoxModelOfLabels();
		selectedAssociatedFieldsLabels.remove(selectedRow);
	}
	private void addLabelButtonClicked() {
		Label selectedLabel=labelsInComboBox.remove(comboBox.getSelectedIndex());
		createComboBoxModelOfLabels();
		comboBox.setSelectedIndex(-1);
		labelsSelected.add(selectedLabel);
		Vector<String> associatedFieldsForLabel=new Vector<String>();
		
		int index=0;
		for (Iterator<AssociatedField> iterator = selectedLabel.getAssociatedFields().iterator(); iterator
				.hasNext();) {
			AssociatedField field = iterator.next();
			if(field.getType().equals(AssociatedField.string_Type)){
				associatedFieldsForLabel.add(currentAssociatedFields.get(index).getText());
				index++;
			}else{
				associatedFieldsForLabel.add(currentAssociatedFields.get(index).getText()+"/");
				index++;
				associatedFieldsForLabel.add(currentAssociatedFields.get(index).getText()+"/");
				index++;
				associatedFieldsForLabel.add(currentAssociatedFields.get(index).getText());
				index++;
			}
		}
		
		selectedAssociatedFieldsLabels.add(associatedFieldsForLabel);
		//Ahora falta actualizar la tabla
		addLabelToTable(selectedLabel);
		panel.removeAll();
		scrollPane.setVisible(false);
		this.validate();
	}




	private void addLabelToTable(Label selectedLabel) {
		String[][] newscheduleTableModel = new String[tableData.length + 1][1];
		TableModel tm = table.getModel();
		for (int i = 0; i < tableData.length; i++)
				newscheduleTableModel[i][0] = (String) tm.getValueAt(i, 0);
		
		newscheduleTableModel[tableData.length][0] = selectedLabel.getName();
		
		tableData = newscheduleTableModel;
		table.setModel(new DefaultTableModel(tableData,
				new String[] {"Campos asociados" }));
		table.getTableHeader().setVisible(true);
	}
}
