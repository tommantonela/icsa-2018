package ui.search.personUtils.panels.labels.internalPanels.utilForSearchResults;

import bd.pojos.AssociatedField;

public class AssociatedFieldValueForSearch {
	private AssociatedField associatedField;
	private boolean equal;
	public AssociatedFieldValueForSearch(AssociatedField associatedField,
			boolean equal) {
		super();
		this.associatedField = associatedField;
		this.equal = equal;
	}
	public AssociatedField getAssociatedField() {
		return associatedField;
	}
	public boolean isEqual() {
		return equal;
	}
	 
}
