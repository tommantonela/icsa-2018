package ui.search.personUtils.searchCriteria;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import bd.specialCriterions.MonthEqExpression;


public class SearchCriteriaDateOnlyForMonth extends SearchCriteriaForField {
	
	protected String monthValue;
	 
	
	public SearchCriteriaDateOnlyForMonth(String field,String monthValue,boolean equals, String columnName) {
		super(field, equals,columnName);
		this.monthValue=monthValue;
	}
	@Override
	public String toString() {
		if(equals){
			return field+" en el mes "+monthValue;
		}else{
			return field+" distinto del mes "+monthValue;
		}
		
	}
	@Override
	public Criterion getCriterion() {
		
		Criterion ret=new MonthEqExpression(columnName, new Integer(monthValue));
		if(!equals){
			ret=Restrictions.not(ret);
		}
		return ret;
	}
}
