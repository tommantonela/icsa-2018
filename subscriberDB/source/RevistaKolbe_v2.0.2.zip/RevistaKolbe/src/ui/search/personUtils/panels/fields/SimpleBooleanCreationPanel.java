package ui.search.personUtils.panels.fields;

import java.awt.Dimension;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.JRadioButton;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import ui.search.personUtils.searchCriteria.SearchCriteria;
import ui.search.personUtils.searchCriteria.SearchCriteriaForBoolean;

public class SimpleBooleanCreationPanel extends CriteriaCreationPanelForField {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3994715593600469798L;
	private JRadioButton rdbtnIgual;

	/**
	 * Create the panel.
	 */
	public SimpleBooleanCreationPanel(String fieldToSearch, String columnName) {
		super(fieldToSearch,columnName);
		
		rdbtnIgual = new JRadioButton("Verdadero");
		
		JRadioButton rdbtnDistinto = new JRadioButton("Falso");
		
		ButtonGroup buttonGroupDataSource = new ButtonGroup();
		buttonGroupDataSource.add(rdbtnIgual);
		buttonGroupDataSource.add(rdbtnDistinto);
		rdbtnIgual.setSelected(true);
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap(181, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(rdbtnDistinto)
						.addComponent(rdbtnIgual))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(rdbtnIgual)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(rdbtnDistinto)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		setLayout(groupLayout);
		this.setPreferredSize(new Dimension(100,55));
	}
	@Override
	public SearchCriteria createSearchCriteria() {
		return new SearchCriteriaForBoolean(field, 
				rdbtnIgual.isSelected(), columnName);
	}
}
