package bd.pojos;


import java.util.Set;

public class Label {
	private Long id;
	private String name;
	private boolean eliminable;
	private Set<AssociatedField> associatedFields;
	public Label() {
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Set<AssociatedField> getAssociatedFields() {
		return associatedFields;
	}
	public void setAssociatedFields(Set<AssociatedField> associatedFields) {
		this.associatedFields = associatedFields;
	}
	@Override
	public String toString() {
		return name;
	}
	@Override
	public boolean equals(Object obj) {
		return name.equals(((Label)obj).getName());
	}
	public boolean isEliminable() {
		return eliminable;
	}
	public void setEliminable(boolean eliminable) {
		this.eliminable = eliminable;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
}
