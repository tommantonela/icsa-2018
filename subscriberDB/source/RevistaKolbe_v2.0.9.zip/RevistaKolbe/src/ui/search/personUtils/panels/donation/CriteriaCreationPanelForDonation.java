package ui.search.personUtils.panels.donation;

import ui.search.SearchPerson;
import ui.search.personUtils.panels.CriteriaCreationPanel;
import ui.search.personUtils.searchCriteria.SearchCriteria;
import ui.search.personUtils.searchCriteria.SearchCriteriaForDonation;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CriteriaCreationPanelForDonation extends CriteriaCreationPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6270685580771353616L;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JCheckBox chckbxUtilizarFechas;
	private JLabel label;
	private JLabel label_1;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel label_5;
	private JRadioButton rdbtnRealizoDonacin;
	private SearchPerson searchPersonPanel;
	
	public CriteriaCreationPanelForDonation(SearchPerson searchPersonPanel) {
		this.searchPersonPanel=searchPersonPanel;
		rdbtnRealizoDonacin = new JRadioButton("Realizo donaci\u00F3n");
		rdbtnRealizoDonacin.setSelected(true);
		JRadioButton rdbtnNoRealizarDonacin = new JRadioButton("No realizo donaci\u00F3n");
		
		ButtonGroup buttonGroupDataSource = new ButtonGroup();
		buttonGroupDataSource.add(rdbtnRealizoDonacin);
		buttonGroupDataSource.add(rdbtnNoRealizarDonacin);
		
		chckbxUtilizarFechas = new JCheckBox("Utilizar fechas");
		chckbxUtilizarFechas.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				chckbxUtilizarFechasClicked();
			}
		});
		
		label = new JLabel("Desde");
		label.setEnabled(false);
		
		textField = new JTextField();
		textField.setToolTipText("D\u00EDa");
		textField.setColumns(10);
		textField.setEnabled(false);
		
		label_1 = new JLabel("/");
		label_1.setEnabled(false);
		
		textField_1 = new JTextField();
		textField_1.setToolTipText("Mes");
		textField_1.setColumns(10);
		textField_1.setEnabled(false);
		
		label_2 = new JLabel("/");
		label_2.setEnabled(false);
		
		textField_2 = new JTextField();
		textField_2.setToolTipText("A\u00F1o");
		textField_2.setColumns(10);
		textField_2.setEnabled(false);
		
		label_3 = new JLabel("Hasta");
		label_3.setEnabled(false);
		
		textField_3 = new JTextField();
		textField_3.setToolTipText("D\u00EDa");
		textField_3.setColumns(10);
		textField_3.setEnabled(false);
		
		label_4 = new JLabel("/");
		label_4.setEnabled(false);
		
		textField_4 = new JTextField();
		textField_4.setToolTipText("Mes");
		textField_4.setColumns(10);
		textField_4.setEnabled(false);
		
		label_5 = new JLabel("/");
		label_5.setEnabled(false);
		
		textField_5 = new JTextField();
		textField_5.setToolTipText("A\u00F1o");
		textField_5.setColumns(10);
		textField_5.setEnabled(false);
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addContainerGap()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(rdbtnRealizoDonacin)
								.addComponent(rdbtnNoRealizarDonacin)
								.addComponent(chckbxUtilizarFechas)))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(15)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 7, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(label_5, GroupLayout.PREFERRED_SIZE, 7, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE))
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(label, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
									.addGap(12)
									.addComponent(textField, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 7, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 7, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)))))
					.addContainerGap(270, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(rdbtnRealizoDonacin)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(rdbtnNoRealizarDonacin)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(chckbxUtilizarFechas)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(label_1)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_2)
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_3)
						.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_4)
						.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_5)
						.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(151, Short.MAX_VALUE))
		);
		setLayout(groupLayout);
	}

	private void chckbxUtilizarFechasClicked() {
		
		
		
		label.setEnabled(chckbxUtilizarFechas.isSelected());
		textField.setEnabled(chckbxUtilizarFechas.isSelected());
		label_1.setEnabled(chckbxUtilizarFechas.isSelected());
		textField_1.setEnabled(chckbxUtilizarFechas.isSelected());
		label_2.setEnabled(chckbxUtilizarFechas.isSelected());
		label_3.setEnabled(chckbxUtilizarFechas.isSelected());
		label_4.setEnabled(chckbxUtilizarFechas.isSelected());
		label_5.setEnabled(chckbxUtilizarFechas.isSelected());
		textField_2.setEnabled(chckbxUtilizarFechas.isSelected());
		textField_3.setEnabled(chckbxUtilizarFechas.isSelected());
		textField_4.setEnabled(chckbxUtilizarFechas.isSelected());
		textField_5.setEnabled(chckbxUtilizarFechas.isSelected());
	}

	@Override
	public SearchCriteria createSearchCriteria() {
		
		Date from=null;
		Date to=null;
		if(chckbxUtilizarFechas.isSelected()){
			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			try {
				from=df.parse(textField.getText()+"/"+textField_1.getText()+"/"+textField_2.getText());
				to=df.parse(textField_3.getText()+"/"+textField_4.getText()+"/"+textField_5.getText());
			}catch (Exception e1){
				e1.printStackTrace();
			}
		}
		return new SearchCriteriaForDonation(rdbtnRealizoDonacin.isSelected(), chckbxUtilizarFechas.isSelected(),
				from, to, searchPersonPanel);
	}
}
