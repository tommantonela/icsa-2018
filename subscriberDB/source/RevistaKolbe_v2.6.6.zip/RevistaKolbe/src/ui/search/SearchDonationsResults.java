package ui.search;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import bd.DataBaseManager;
import bd.pojos.Donation;
import bd.pojos.Person;
import javax.swing.JMenuBar;
import javax.swing.SwingConstants;
import javax.swing.JMenu;

import ui.add.AddDonation;
import ui.add.AddPersonToEvent;
import ui.edit.EditDonation;
import ui.edit.EditPerson;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

public class SearchDonationsResults extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4465210599980548074L;
	private JPanel contentPane;
	private JTable table;
	private String[][] tableData;
	private JPopupMenu popup;
	private List<Donation> results;
	private JMenuBar menuBar;
	private JMenu mnExportar;
	private JMenuItem mntmExportarAExcel;
	private JLabel numberOfResults;
	
	/**
	 * Create the frame.
	 */
	public SearchDonationsResults(List<Donation> results) {
		this.results=results;
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnExportar = new JMenu("Exportar");
		menuBar.add(mnExportar);
		
		mntmExportarAExcel = new JMenuItem("Exportar a Excel");
		mntmExportarAExcel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				exportToExcel();
			}
		});
		mnExportar.add(mntmExportarAExcel);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		numberOfResults = new JLabel(results.size()+" donaciones encontradas");
		numberOfResults.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(numberOfResults, BorderLayout.NORTH);
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		table = new JTable();
		
		updateTable();
		
		
		
		scrollPane.setViewportView(table);
		popup = new JPopupMenu();
        
		JMenuItem addDonation = new JMenuItem("Modificar donación");
		addDonation.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				modifyDonation();
			}
		});
		popup.add(addDonation);
        
     
        JMenuItem eventAssistance = new JMenuItem("Eliminar donación");
        eventAssistance.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				deleteDonation();
			}
		});
        popup.add(eventAssistance);
        
       /* JMenuItem modifyPerson = new JMenuItem("Modificar datos");
        modifyPerson.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				modifyPerson();
			}
		});
        popup.add(modifyPerson);
        
        JMenuItem deletePerson = new JMenuItem("Eliminar persona");
        deletePerson.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				deletePerson();
				
			}
		});
        popup.add(deletePerson);*/
        
        
       
        table.addMouseListener(new MouseAdapter() {
        	public void mousePressed(MouseEvent e) {
				createPopUp(e);
			}

			public void mouseReleased(MouseEvent e) {
				createPopUp(e);
			}
			private void createPopUp(MouseEvent e) {
				
				if(e.isPopupTrigger()){
					 popup.show(e.getComponent(), e.getX(), e.getY());
				}
			}
		});
		this.setVisible(true);
	}





	private void modifyDonation() {
		new EditDonation(getSelectedDonation(), this);
	}





	private void updateTable() {
		tableData=new String[results.size()][5];
		NumberFormat formatter = new DecimalFormat("#0.00");
		for (int i = 0; i < results.size(); i++) {
			Donation donation=results.get(i);	
			tableData[i][0]=donation.getDonor().getName();
			tableData[i][1]=donation.getDonor().getFamilyName();
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			tableData[i][2]=dateFormat.format(donation.getDate());
			tableData[i][3]=formatter.format(donation.getAmount());
			tableData[i][4]=donation.getMeansOfPayment();
		}
		TableModel tableModel = new DefaultTableModel(
				tableData, new String[] { "Nombre", "Apellido","Fecha","Monto","Tipo de pago" });
		
		table.setModel(tableModel);
	}
	
	

	

	private void deleteDonation() {
		DataBaseManager.getInstance().deleteDonation(getSelectedDonation());
		results.remove(getSelectedDonation());
		numberOfResults.setText(results.size()+" donaciones encontradas");
		updateSearchValue();
	}





	private void exportToExcel() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Elija el archivo a guardar");    
		 
		int userSelection = fileChooser.showSaveDialog(this);
		 
		if (userSelection == JFileChooser.APPROVE_OPTION) {
		    File fileToSave = fileChooser.getSelectedFile();
		    String filePath = fileToSave.getPath();
		    if(!filePath.toLowerCase().endsWith(".xls"))
		    {
		    	fileToSave = new File(filePath + ".xls");
		    }
		    export(fileToSave);
		    
		}
		
	}
	private boolean export(File file){
		try
		{
		//Nuestro flujo de salida para apuntar a donde vamos a escribir
		DataOutputStream out=new DataOutputStream(new FileOutputStream(file));
		 
		//Representa nuestro archivo en excel y necesita un OutputStream para saber donde va locoar los datos
		WritableWorkbook w = Workbook.createWorkbook(out);
		 
		 
		//Como excel tiene muchas hojas esta crea o toma la hoja
		//Coloca el nombre del "tab" y el indice del tab
		WritableSheet s = w.createSheet("Resultados", 0);
		 
		for(int i=0;i< table.getRowCount();i++){	
			for(int j=0;j<table.getColumnCount();j++){
				Object objeto=table.getValueAt(i,j);
					s.addCell(new Label(j, i, String.valueOf(objeto)));        
		}
		}
		w.write();

		//Cerramos el WritableWorkbook y DataOutputStream
		w.close();
		out.close();
		 
		 
		//si todo sale bien salimos de aqui con un true :D
		return true;
		 
		}catch(IOException ex){ex.printStackTrace();}
		catch(WriteException ex){ex.printStackTrace();}
		 
		//Si llegamos hasta aqui algo salio mal
		return false;
	}


	private Donation getSelectedDonation() {
		Donation selectedDonation=results.get(table.getSelectedRow());
		return selectedDonation;
	}
	public void updateSearchValue(){
		updateTable();
		table.validate();
	}
	
}
