package ui.search.personUtils.searchCriteria;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import bd.specialCriterions.DayMonthAndYearEqExpression;

public class SearchCriteriaDate extends SearchCriteriaDateOnlyForMonthAndDay {
	private String yearValue;
	
	public SearchCriteriaDate(String field,String year,String monthValue,String dayValue,  boolean equals, String columnName) {
		super(field, monthValue, dayValue,  equals,  columnName);
		this.yearValue=year;
	}
	@Override
	public String toString() {
		if(equals){
			return field+"="+dayValue+"/"+monthValue+"/"+yearValue;
		}else{
			return field+" distinto de "+dayValue+"/"+monthValue+"/"+yearValue;
		}
		
	}
	@Override
	public Criterion getCriterion() {
		Criterion ret=new DayMonthAndYearEqExpression(columnName, new Integer(dayValue).intValue(),new Integer(monthValue).intValue(),new Integer(yearValue).intValue());
		if(!equals){
			ret=Restrictions.not(ret);
		}
		return ret;
	}
}
