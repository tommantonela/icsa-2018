package ui.search.personUtils.panels.fields;

import java.awt.Dimension;

import javax.swing.ButtonGroup;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.JRadioButton;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;

import ui.search.personUtils.searchCriteria.SearchCriteria;
import ui.search.personUtils.searchCriteria.SearchCriteriaForSimpleField;

public class SimpleComboBoxCreationPanel extends CriteriaCreationPanelForField {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2430789939312569937L;
	private JRadioButton rdbtnIgual;
	private JComboBox comboBox;
	/**
	 * Create the panel.
	 */
	public SimpleComboBoxCreationPanel(String fieldToSearch, String columnName, String[] comboBoxData) {
		super(fieldToSearch, columnName);
		
		rdbtnIgual = new JRadioButton("Igual");
		
		JRadioButton rdbtnDistinto = new JRadioButton("Distinto");
		
		ButtonGroup buttonGroupDataSource = new ButtonGroup();
		buttonGroupDataSource.add(rdbtnIgual);
		buttonGroupDataSource.add(rdbtnDistinto);
		rdbtnIgual.setSelected(true);
		
		comboBox = new JComboBox();
		ComboBoxModel jComboBox1Model = 
				new DefaultComboBoxModel(comboBoxData);
		comboBox.setModel(jComboBox1Model);
		comboBox.setSelectedIndex(0);
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(comboBox, 0, 157, Short.MAX_VALUE)
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(rdbtnDistinto)
						.addComponent(rdbtnIgual))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(rdbtnIgual)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(rdbtnDistinto))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(14)
							.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		setLayout(groupLayout);
		this.setPreferredSize(new Dimension(270,55));
	}
	@Override
	public SearchCriteria createSearchCriteria() {
		return new SearchCriteriaForSimpleField(field, comboBox.getSelectedItem().toString(),
				rdbtnIgual.isSelected(), columnName);
	}
}
