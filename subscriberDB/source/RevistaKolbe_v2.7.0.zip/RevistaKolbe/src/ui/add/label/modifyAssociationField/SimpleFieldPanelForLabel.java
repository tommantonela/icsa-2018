package ui.add.label.modifyAssociationField;

import java.awt.Dimension;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;

import bd.pojos.AssociatedField;

public class SimpleFieldPanelForLabel extends AssociatedFieldPanelForLabel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1663262572165130615L;
	private JTextField textField;
	private JLabel lblNewLabel;
	/**
	 * Create the panel.
	 * @param value 
	 */
	public SimpleFieldPanelForLabel(AssociatedField associatedField, String value) {
		textField = new JTextField();
		textField.setColumns(10);
		textField.setText(value);
		lblNewLabel = new JLabel(associatedField.getName());
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(107))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(11)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		setLayout(groupLayout);
		this.setPreferredSize(new Dimension(275, 45));
	}
	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return textField.getText();
	}
	
}