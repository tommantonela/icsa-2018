package ui.search;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import bd.pojos.Person;

public class Searchresults extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4465210599980548074L;
	private JPanel contentPane;
	private JTable table;
	private String[][] tableData;
	private JPopupMenu popup;
	private List<Person> results;
	
	/**
	 * Create the frame.
	 */
	public Searchresults(List<Person> results) {
		this.results=results;
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		tableData=new String[results.size()][10];
		for (int i = 0; i < results.size(); i++) {
			Person person=results.get(i);	
			tableData[i][0]=person.getName();
			tableData[i][1]=person.getFamilyName();
			tableData[i][2]=person.getPhone();
			tableData[i][3]=person.getCellPhone();
			tableData[i][4]=person.getEmail();
			tableData[i][5]=person.getCity();
			tableData[i][6]=person.getProvince();
			tableData[i][7]=person.getCountry();
			if(person.isReceivesMagazine())
				tableData[i][8]="Si";
			else 
				tableData[i][8]="No";
			tableData[i][9]=person.getKindOfShipping();
		}
		TableModel tableModel = new DefaultTableModel(
				tableData, new String[] { "Nombre", "Apellido","Telefono","Celular","Email","Ciudad","Provincia","Pais","Recibe la revista", "Tipo de envio" });
		
		
		
		table = new JTable();
		table.setModel(tableModel);
		scrollPane.setViewportView(table);
		popup = new JPopupMenu();
        
		JMenuItem addDonation = new JMenuItem("Donaciones");
		addDonation.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//AGREGAR DONACION
			}
		});
		popup.add(addDonation);
        
     
        JMenuItem eventAssistance = new JMenuItem("Asistencia a eventos");
        eventAssistance.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//AGREGAR DONACION
			}
		});
        popup.add(eventAssistance);
        
        JMenuItem modifyPerson = new JMenuItem("Modificar datos");
        modifyPerson.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//AGREGAR DONACION
			}
		});
        popup.add(modifyPerson);
        
        JMenuItem deletePerson = new JMenuItem("Eliminar persona");
        deletePerson.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//AGREGAR DONACION
				deletePerson();
				
			}
		});
        popup.add(deletePerson);
        
        
        //MouseListener popupListener = new PopupListener(popup);
        //table.addMouseListener(popupListener);
        table.addMouseListener(new MouseAdapter() {
        	public void mousePressed(MouseEvent e) {
				createPopUp(e);
			}

			public void mouseReleased(MouseEvent e) {
				createPopUp(e);
			}
			private void createPopUp(MouseEvent e) {
				
				if(e.isPopupTrigger()){
					 popup.show(e.getComponent(), e.getX(), e.getY());
				}
			}
		});
		this.setVisible(true);
	}
	private void deletePerson(){
		Person selectedPerson=results.get(table.getSelectedRow());
		System.out.println(selectedPerson.getName());
	}
}
