package ui.search.personUtils.panels.labels.internalPanels.utilForSearchResults;

import bd.pojos.AssociatedField;

public class AssociatedFieldValueStringForSearch extends
		AssociatedFieldValueForSearch {
	private String value;

	public AssociatedFieldValueStringForSearch(AssociatedField associatedField,
			boolean equal, String value) {
		super(associatedField, equal);
		this.value = value;
	}
	public String getValue() {
		return value;
	}
}
