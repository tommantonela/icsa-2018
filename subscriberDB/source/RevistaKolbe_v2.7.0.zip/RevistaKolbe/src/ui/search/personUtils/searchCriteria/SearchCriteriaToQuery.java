package ui.search.personUtils.searchCriteria;

import org.hibernate.criterion.Criterion;

public abstract class SearchCriteriaToQuery extends SearchCriteria {
	protected String columnName;
	public SearchCriteriaToQuery(String columnName) {
		this.columnName=columnName;
	}
	public abstract Criterion getCriterion();
	@Override
	public boolean isCriteriaToQuery() {
		return true;
	}
	public String getColumnName() {
		return columnName;
	}
}
