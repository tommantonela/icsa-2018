package bd.specialCriterions;

import org.hibernate.Criteria;
import org.hibernate.EntityMode;
import org.hibernate.HibernateException;
import org.hibernate.criterion.CriteriaQuery;
import org.hibernate.criterion.Criterion;
import org.hibernate.engine.spi.TypedValue;
import org.hibernate.type.IntegerType;

public class DayMonthAndYearEqExpression implements Criterion {

    /**
	 * 
	 */
	private static final long serialVersionUID = 2281408824917792797L;
	private final String propertyName;
    private final int day;
    private final int month;
    private final int year;
    
    public DayMonthAndYearEqExpression(String propertyName, int day, int month, int year) {
        this.propertyName = propertyName;
        this.day = day;
        this.month=month;
        this.year=year;
    }

	@Override
	public TypedValue[] getTypedValues(Criteria arg0, CriteriaQuery arg1)
			throws HibernateException {
		return new TypedValue[] {new TypedValue(IntegerType.INSTANCE, day, EntityMode.POJO), new TypedValue(IntegerType.INSTANCE, month, EntityMode.POJO), new TypedValue(IntegerType.INSTANCE, year, EntityMode.POJO)};
	}

	@Override
	public String toSqlString(Criteria arg0, CriteriaQuery arg1)
			throws HibernateException {
		String[] columns = arg1.findColumns(propertyName, arg0);
        if (columns.length!=1) {
            throw new HibernateException("dayMondAndYearEq may only be used with single-column properties");
        }
        return "DAYOFMONTH(" + columns[0] + ") = ?"+" AND "+"month(" + columns[0] + ") = ?"+" AND "+"YEAR(" + columns[0] + ") = ?";
        
	}

    
}
