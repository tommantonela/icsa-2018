package ui.search.personUtils.panels.fields;

import java.awt.Dimension;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import ui.search.personUtils.searchCriteria.SearchCriteria;
import ui.search.personUtils.searchCriteria.SearchCriteriaForSimpleField;

public class SimpleFieldCreationPanel extends CriteriaCreationPanelForField {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7071079133089528070L;
	private JTextField textField;
	private JRadioButton rdbtnIgual;

	/**
	 * Create the panel.
	 */
	public SimpleFieldCreationPanel(String fieldToSearch, String columnName) {
		super(fieldToSearch,columnName);
		textField = new JTextField();
		textField.setColumns(10);
		
		rdbtnIgual = new JRadioButton("Igual");
		
		JRadioButton rdbtnDistinto = new JRadioButton("Distinto");
		
		ButtonGroup buttonGroupDataSource = new ButtonGroup();
		buttonGroupDataSource.add(rdbtnIgual);
		buttonGroupDataSource.add(rdbtnDistinto);
		rdbtnIgual.setSelected(true);
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
					.addContainerGap(14, Short.MAX_VALUE)
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, 149, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(rdbtnDistinto)
						.addComponent(rdbtnIgual))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(11)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(rdbtnIgual)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(rdbtnDistinto)))
					.addContainerGap(8, Short.MAX_VALUE))
		);
		setLayout(groupLayout);
		this.setPreferredSize(new Dimension(270,55));
	}
	@Override
	public SearchCriteria createSearchCriteria() {
		return new SearchCriteriaForSimpleField(field, textField.getText(),
				rdbtnIgual.isSelected(), columnName);
	}
}
