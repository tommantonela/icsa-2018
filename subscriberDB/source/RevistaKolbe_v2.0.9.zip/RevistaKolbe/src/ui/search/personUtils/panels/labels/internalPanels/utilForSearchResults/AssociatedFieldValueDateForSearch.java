package ui.search.personUtils.panels.labels.internalPanels.utilForSearchResults;

import bd.pojos.AssociatedField;

public class AssociatedFieldValueDateForSearch extends
		AssociatedFieldValueForSearch {
	private String day;
	private String month;
	private String year;
	private boolean completeDate;
	private boolean justMonth;
	private boolean justMonthAndDay;
	public AssociatedFieldValueDateForSearch(AssociatedField associatedField,
			boolean equal, String day, String month, String year,
			boolean completeDate, boolean justMonth, boolean justMonthAndDay) {
		super(associatedField, equal);
		this.day = day;
		this.month = month;
		this.year = year;
		this.completeDate = completeDate;
		this.justMonth = justMonth;
		this.justMonthAndDay = justMonthAndDay;
	}
	public boolean isCompleteDate() {
		return completeDate;
	}
	public boolean isJustMonth() {
		return justMonth;
	}
	public boolean isJustMonthAndDay() {
		return justMonthAndDay;
	}
	public String getDay() {
		return day;
	}
	public String getMonth() {
		return month;
	}
	public String getYear() {
		return year;
	}
}
