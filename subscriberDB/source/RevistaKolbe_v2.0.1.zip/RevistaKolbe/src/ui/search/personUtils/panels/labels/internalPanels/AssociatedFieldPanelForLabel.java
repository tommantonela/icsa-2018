package ui.search.personUtils.panels.labels.internalPanels;

import javax.swing.JPanel;

import ui.search.personUtils.panels.labels.internalPanels.utilForSearchResults.AssociatedFieldValueForSearch;

public abstract class AssociatedFieldPanelForLabel extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5702441885318199358L;

	public abstract void setEnableAllComponents(boolean enable);
	public abstract AssociatedFieldValueForSearch getAssociatedValues();
}
