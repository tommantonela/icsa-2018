package ui.search.personUtils.panels.labels.internalPanels;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import ui.search.personUtils.panels.labels.internalPanels.utilForSearchResults.AssociatedFieldValueDateForSearch;
import ui.search.personUtils.panels.labels.internalPanels.utilForSearchResults.AssociatedFieldValueForSearch;

import bd.pojos.AssociatedField;


public class SimpleDatePanelForLabel extends AssociatedFieldPanelForLabel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7368540804734117330L;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	
	private JRadioButton rdbtnFechaCompleta;
	private JRadioButton rdbtnSoloDaY;
	private JRadioButton rdbtnSoloMes;
	private JRadioButton rdbtnSoloAnio;
	private JRadioButton rdbtnIgual;
	private JLabel lblNewLabel;
	private AssociatedField associatedField;
	private JRadioButton rdbtnDistinto;
	private JLabel label;
	private JLabel label_1;
	
	public SimpleDatePanelForLabel(AssociatedField associatedField) {
		this.associatedField=associatedField;
		rdbtnIgual = new JRadioButton("Igual");
		
		rdbtnDistinto = new JRadioButton("Distinto");
		
		ButtonGroup buttonGroupDataSource = new ButtonGroup();
		buttonGroupDataSource.add(rdbtnIgual);
		buttonGroupDataSource.add(rdbtnDistinto);
		rdbtnIgual.setSelected(true);
		
		textField_1 = new JTextField();
		textField_1.setToolTipText("D\u00EDa");
		textField_1.setColumns(10);
		
		label = new JLabel("/");
		
		textField_2 = new JTextField();
		textField_2.setToolTipText("Mes");
		textField_2.setColumns(10);
		
		label_1 = new JLabel("/");
		
		textField_3 = new JTextField();
		textField_3.setToolTipText("A\u00F1o");
		textField_3.setColumns(10);
		
		rdbtnFechaCompleta = new JRadioButton("Fecha completa");
		rdbtnFechaCompleta.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				rdbtnFechaCompletaClicked();
			}
		});
		
		rdbtnSoloDaY = new JRadioButton("Solo d\u00EDa y mes");
		rdbtnSoloDaY.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				rdbtnSoloDaYClicked();
			}
		});
		
		rdbtnSoloMes = new JRadioButton("Solo mes");
		rdbtnSoloMes.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				rdbtnSoloMesClicked();
			}
		});
		
		
		rdbtnSoloAnio = new JRadioButton("Solo a\u00F1o");
		rdbtnSoloAnio.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				rdbtnSoloAnioClicked();
			}
		});
		
		ButtonGroup buttonKindOfDate = new ButtonGroup();
		buttonKindOfDate.add(rdbtnFechaCompleta);
		buttonKindOfDate.add(rdbtnSoloDaY);
		buttonKindOfDate.add(rdbtnSoloMes);
		buttonKindOfDate.add(rdbtnSoloAnio);
		rdbtnFechaCompleta.setSelected(true);
		
		lblNewLabel = new JLabel(associatedField.getName());
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(6)
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 76, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(rdbtnSoloMes)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
									.addGap(6)
									.addComponent(label, GroupLayout.PREFERRED_SIZE, 7, GroupLayout.PREFERRED_SIZE)
									.addGap(6)
									.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
									.addGap(6)
									.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 7, GroupLayout.PREFERRED_SIZE)
									.addGap(6)
									.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE))
								.addComponent(rdbtnFechaCompleta)
								.addComponent(rdbtnSoloAnio)
								.addComponent(rdbtnSoloDaY))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(rdbtnDistinto)
								.addComponent(rdbtnIgual))))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(rdbtnIgual)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(rdbtnDistinto))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
									.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addComponent(lblNewLabel))
								.addGroup(groupLayout.createSequentialGroup()
									.addGap(6)
									.addComponent(label))
								.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addGroup(groupLayout.createSequentialGroup()
									.addGap(6)
									.addComponent(label_1))
								.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(rdbtnFechaCompleta)
							.addComponent(rdbtnSoloAnio)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(rdbtnSoloDaY)
							.addGap(4)
							.addComponent(rdbtnSoloMes)))
					.addContainerGap())
		);
		setLayout(groupLayout);
		this.setPreferredSize(new Dimension(350, 143));
	}
	private void rdbtnSoloMesClicked() {
		textField_1.setEnabled(false);
		textField_2.setEnabled(true);
		textField_3.setEnabled(false);
	}
	private void rdbtnSoloDaYClicked() {
		textField_1.setEnabled(true);
		textField_2.setEnabled(true);
		textField_3.setEnabled(false);
	}
	private void rdbtnFechaCompletaClicked() {
		textField_1.setEnabled(true);
		textField_2.setEnabled(true);
		textField_3.setEnabled(true);
	}
	private void rdbtnSoloAnioClicked(){
		textField_1.setEnabled(false);
		textField_2.setEnabled(false);
		textField_3.setEnabled(true);
	}
	
	
	
	@Override
	public void setEnableAllComponents(boolean enabled) {
		lblNewLabel.setEnabled(enabled);
		textField_1.setEnabled(enabled);
		textField_2.setEnabled(enabled);
		textField_3.setEnabled(enabled);
		rdbtnDistinto.setEnabled(enabled);
		rdbtnIgual.setEnabled(enabled);
		rdbtnFechaCompleta.setEnabled(enabled);
		rdbtnSoloDaY.setEnabled(enabled);
		rdbtnSoloMes.setEnabled(enabled);
		rdbtnSoloAnio.setEnabled(enabled);
		label.setEnabled(enabled);
		label_1.setEnabled(enabled);
	}
	@Override
	public AssociatedFieldValueForSearch getAssociatedValues() {
		return new AssociatedFieldValueDateForSearch(associatedField,
				rdbtnIgual.isSelected(), textField_1.getText(), textField_2.getText(), textField_3.getText(),
				rdbtnFechaCompleta.isSelected(), rdbtnSoloMes.isSelected(), rdbtnSoloDaY.isSelected(),rdbtnSoloAnio.isSelected());
	}
	
	
}
