package ui.edit;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import bd.DataBaseManager;
import bd.pojos.Donation;
import bd.pojos.Person;
import ui.add.AddDonation;
import ui.search.SearchDonationsResults;

public class EditDonation extends AddDonation {
	private SearchDonationsResults searchresults;
	private Donation donationToChange;
	
	public EditDonation(Donation donation, SearchDonationsResults searchresults) {
		super(donation.getDonor());
		this.searchresults=searchresults;
		donationToChange=donation;
		searchresults.setEnabled(false);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		String[] date=dateFormat.format(donation.getDate()).split("/");
		textField.setText(date[0]);
		textField_1.setText(date[1]);
		textField_2.setText(date[2]);
		comboBox.setSelectedItem(donation.getMeansOfPayment());
		textField_3.setText(donation.getAmount().toString());
	}
	
	protected void saveButtonCliked() {
		
		
		donationToChange.setAmount(new Float(textField_3.getText()));
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		try {
			donationToChange.setDate(df.parse(textField.getText()+"/"+textField_1.getText()+"/"+textField_2.getText()));
		}catch (Exception e){
			try {
				donationToChange.setDate(df.parse("01/01/1900"));
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		
		donationToChange.setMeansOfPayment(comboBox.getSelectedItem().toString());
		
		DataBaseManager.getInstance().updateDonation(donationToChange);
		this.dispose();
		searchresults.setEnabled(true);
		searchresults.updateSearchValue();
	}
	
	protected void cancelButtonCliked() {
		this.dispose();
		searchresults.setEnabled(true);
	}
}
