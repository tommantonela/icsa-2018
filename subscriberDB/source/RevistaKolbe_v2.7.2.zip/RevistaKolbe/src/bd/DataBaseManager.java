package bd;

import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Vector;
import java.util.prefs.Preferences;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.NotExpression;
import org.hibernate.criterion.Restrictions;

import ui.MainWindowKolbe;

import bd.pojos.AssociatedField;
import bd.pojos.AssociatedFieldValueForLabel;
import bd.pojos.Donation;
import bd.pojos.Event;
import bd.pojos.EventInstance;
import bd.pojos.Label;
import bd.pojos.Person;


public class DataBaseManager{

	
	
	private static DataBaseManager instance;
	
	public static DataBaseManager getInstance() {
		if(instance==null)
			instance=new DataBaseManager();
		return instance;
	}
	private DataBaseManager() {
		if(Preferences.userNodeForPackage(MainWindowKolbe.class).getBoolean("EsServidor", true)){
			HSQLServer.getInstance().startDatabase();
		
			if(listLabels().size()==0)
				loadLabels();
		}
	}
	private void loadLabels() {
		bd.pojos.Label l=new Label();
		l.setName("Misionero de la prensa");
		l.setEliminable(false);
		Set<AssociatedField> associatedFields1=new HashSet<AssociatedField>();
		AssociatedField af1=new AssociatedField();
		af1.setName("Zona");
		af1.setType(AssociatedField.string_Type);
		associatedFields1.add(af1);
		l.setAssociatedFields(associatedFields1);
		saveEntity(l);
		
		l=new Label();
		l.setName("Misionera que vive en familia");
		l.setEliminable(true);
		saveEntity(l);
		l=new Label();
		l.setName("Familiar misionera");
		l.setEliminable(true);
		saveEntity(l);
		l=new Label();
		l.setName("Consagrado a la Virgen");
		l.setEliminable(true);
		saveEntity(l);
		l=new Label();
		l.setName("Voluntario");
		l.setEliminable(true);
		saveEntity(l);
		l=new Label();
		l.setName("Aspirante");
		l.setEliminable(true);
		saveEntity(l);
		l=new Label();
		l.setName("Bienhechor");
		l.setEliminable(true);
		saveEntity(l);
		l=new Label();
		l.setName("Amigo");
		l.setEliminable(true);
		saveEntity(l);
		l=new Label();
		l.setName("Catequista");
		l.setEliminable(true);
		saveEntity(l);
		l=new Label();
		l.setName("Sacerdote");
		l.setEliminable(true);
		saveEntity(l);
		l=new Label();
		l.setName("Consagrada");
		l.setEliminable(true);
		Set<AssociatedField> associatedFields=new HashSet<AssociatedField>();
		AssociatedField af=new AssociatedField();
		af.setName("Fecha de consagración");
		af.setType(AssociatedField.date_Type);
		associatedFields.add(af);
		l.setAssociatedFields(associatedFields);
		saveEntity(l);
		
	}
	public List<AssociatedField> listAssociatedField(){
		return (List<AssociatedField>) searchForTable(AssociatedField.class);
	}
	public List<Event> listEvents()
	{
		return (List<Event>) searchForTable(Event.class);
	}
	
	public List<Donation> listDonations()
	{
		return (List<Donation>) searchForTable(Donation.class);
	}
	
	public List<Label> listLabels()
	{
		return (List<Label>) searchForTable(Label.class);
	}
	public List<Person> listPersons()
	{
		return (List<Person>) searchForTable(Person.class);
	}
	
	public List<Person> listPerson(Vector<Criterion> databaseCriterion){
		Session session =HibernateUtil.getSessionFactory().openSession();
		
		
		
		Criteria crit = session.createCriteria(Person.class);
		for (Iterator<Criterion> iterator = databaseCriterion.iterator(); iterator
				.hasNext();) {
			Criterion criterion = iterator.next();
			crit.add(criterion);
			
		}
		
		List<Person> ret= crit.list();
		
		
		session.close();
		return ret;
	}
	/*public Criteria getCriteria(Class aClass){
		Session session = HibernateUtil.getSessionFactory().openSession();
		return session.createCriteria(aClass);
	}*/
	private List<?> searchForTable(Class<?> aClass){
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		
		
		Criteria crit = session.createCriteria(aClass);
		//crit.setMaxResults(50);
		
		List<?> results= crit.list();
		
		
		session.close();
		return results;
		/*Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			List<?> results = session.createQuery("from Label").list();
			
			transaction.commit();
			return results;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return null;*/
	}
	public void saveEntity(Object objecToSave){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			session.save(objecToSave);
			transaction.commit();
		}catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			session.close();
		}
	}
	
	
	public List<EventInstance> listEventsIntancesForEvenr(Event eventToSearch) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Criteria crit = session.createCriteria(EventInstance.class);
		List<EventInstance> ret= crit.createCriteria("event").add( Restrictions.eq("id", eventToSearch.getId()) ).list();
		
		session.close();
		return ret;
		
	}
	public void updateLabel(Label type) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Label label = (Label) session.get(Label.class, type.getId());
			label.setName(type.getName());
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	public void deleteLabel(Label type) {
		removeLabelFromPersons(type);
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Label label = (Label) session.get(Label.class, type.getId());		
			label.getAssociatedFields().clear();
			session.delete(label);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	private void removeLabelFromPersons(Label label){
		//Recorro las personas para eliminar los associated fields
		Vector<Person> personsWithLabel=getPersonsWithLabel(label);
		for (Iterator<Person> iterator = personsWithLabel.iterator(); iterator
				.hasNext();) {
			Person person = (Person) iterator.next();
			Session session2 = HibernateUtil.getSessionFactory().openSession();
			Transaction transaction2=session2.beginTransaction();
			Person person2=(Person) session2.get(Person.class, person.getId());
			person2.removeLabelsAndAssociatedFields(label);
			transaction2.commit();
			session2.close();
		}
	}
	private Vector<Person> getPersonsWithLabel(Label label){
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		List<Person> aux=session.createCriteria(Person.class)
	    .createCriteria("labels")
	        .add( Restrictions.like("id", label.getId()) )
	    .list();
		
		session.close();
		
		return new Vector<Person>(aux);
	}
	public void updatePerson(Person type) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Person person = (Person) session.get(Person.class, type.getId());
			person.setAssitedToEvents(type.getAssitedToEvents());
			
			person.getAssociatedFieldValues().clear();
			//recorrer AssociatedFieldValues y crearlos de nuevo
			for (Iterator<AssociatedFieldValueForLabel> iterator = type.getAssociatedFieldValues().iterator(); iterator.hasNext();) {
				AssociatedFieldValueForLabel type2 = (AssociatedFieldValueForLabel) iterator.next();
				AssociatedFieldValueForLabel newassociatedfv=new AssociatedFieldValueForLabel();
				newassociatedfv.setAssociatedField(type2.getAssociatedField());
				newassociatedfv.setLabel(type2.getLabel());
				newassociatedfv.setValueOfField(type2.getValueOfField());
				person.getAssociatedFieldValues().add(newassociatedfv);
			}
			//person.getAssociatedFieldValues().addAll(type.getAssociatedFieldValues());
			
			person.setBirthDate(type.getBirthDate());
			person.setCellPhone(type.getCellPhone());
			person.setCity(type.getCity());
			person.setCivilState(type.getCivilState());
			person.setCountry(type.getCountry());
			person.setDistributor(type.getDistributor());
			person.setEmail(type.getEmail());
			person.setFamilyName(type.getFamilyName());
			person.setFlatNumber(type.getFlatNumber());
			person.setFloor(type.getFloor());
			person.setGender(type.getGender());
			person.setHouse(type.getHouse());
			person.setHouseNumber(type.getHouseNumber());
			person.setKindOfShipping(type.getKindOfShipping());
			person.setLabels(type.getLabels());
			person.setName(type.getName());
			person.setNeighborhood(type.getNeighborhood());
			person.setNotes(type.getNotes());
			person.setNumberOfCopies(type.getNumberOfCopies());
			person.setNumberOfLabels(type.getNumberOfLabels());
			person.setCommentOfLabel(type.getCommentOfLabel());
			person.setNumberOfPersons(type.getNumberOfPersons());
			person.setPhone(type.getPhone());
			person.setPostalNumber(type.getPostalNumber());
			person.setProvince(type.getProvince());
			person.setReceivesMagazine(type.isReceivesMagazine());
			person.setStreet(type.getStreet());
			person.setWork(type.getWork());
			person.setSector(type.getSector());
			
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	public void deletePerson(Person type) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Person person = (Person) session.get(Person.class, type.getId());
			person.getLabels().clear();
			person.getAssitedToEvents().clear();
			session.delete(person);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	public void updateEvent(Event type) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Event event = (Event) session.get(Event.class, type.getId());
			event.setName(type.getName());
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	public void updateEventInstance(EventInstance type) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			EventInstance label = (EventInstance) session.get(EventInstance.class, type.getId());
			label.setDate(type.getDate());
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	public void deleteEvent(Event type) {
		removeEventInstances(type);
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Event label = (Event) session.get(Event.class, type.getId());		
			
			session.delete(label);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	private void removeEventInstances(Event type) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		List<EventInstance> aux=session.createCriteria(EventInstance.class)
	    .createCriteria("event")
	        .add( Restrictions.like("id", type.getId()) )
	    .list();
		
		for (Iterator<EventInstance> iterator = aux.iterator(); iterator.hasNext();) {
			EventInstance eventInstance = (EventInstance) iterator.next();
			Transaction transaction =session.beginTransaction();
			session.delete(eventInstance);
			transaction.commit();
		}
		session.close();
		
	}
	public void deleteEventIntance(EventInstance type) {
		removeEventInstanceFromPersons(type);
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			EventInstance label = (EventInstance) session.get(EventInstance.class, type.getId());		
			
			session.delete(label);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	private void removeEventInstanceFromPersons(EventInstance label){
		//Recorro las personas para eliminar los associated fields
		Vector<Person> personsWithLabel=getPersonsWithEventInstance(label);
		for (Iterator<Person> iterator = personsWithLabel.iterator(); iterator
				.hasNext();) {
			Person person = (Person) iterator.next();
			Session session2 = HibernateUtil.getSessionFactory().openSession();
			Transaction transaction2=session2.beginTransaction();
			Person person2=(Person) session2.get(Person.class, person.getId());
			person2.removeEventInstance(label);
			transaction2.commit();
			session2.close();
		}
	}
	private Vector<Person> getPersonsWithEventInstance(EventInstance label){
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		List<Person> aux=session.createCriteria(Person.class)
	    .createCriteria("assitedToEvents")
	        .add( Restrictions.like("id", label.getId()) )
	    .list();
		
		session.close();
		return new Vector<Person>(aux);
	}
	public List<Donation> listDonationsBetweenDates(Date from, Date to){
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		List<Donation> aux=session.createCriteria(Donation.class)
	    
	    .add( Restrictions.between("date", from,to) )
	    .list();
		session.close();
		return aux;
	}
	
	public List<Donation> listDonationsForPersonBetweenDates(Person donor, Date from, Date to){
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		List<Donation> aux=session.createCriteria(Donation.class)
	    
	    .add( Restrictions.between("date", from,to) )
	      .createCriteria("donor")
	        .add( Restrictions.like("id", donor.getId()) )
	    .list();
		session.close();
		return aux;
	}
	public List<Donation> listDonationsForPerson(Person donor){
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		List<Donation> aux=session.createCriteria(Donation.class)
	      .createCriteria("donor")
	        .add( Restrictions.like("id", donor.getId()) )
	    .list();
		session.close();
		return aux;
	}
	public List<Person> listMisionerosDeLaPrensa(){
		Session session = HibernateUtil.getSessionFactory().openSession();
		Criteria cri=session.createCriteria(Person.class);			      
		cri.createAlias("labels", "l");
		cri.add(Restrictions.like("l.name", "Misionero de la prensa"));
		List<Person> aux=cri.list();
		session.close();
		return aux;
	}
	public Donation getLastDonation(Person donor){
		List<Donation> donations=listDonationsForPerson(donor);
		Collections.sort(donations, new Comparator<Donation>() {
		    public int compare(Donation m1, Donation m2) {
		    	//the value 0 if the argument Date is equal to this Date; a value less than 0 if this Date is before the Date argument; and a value greater than 0 if this Date is after the Date argument.
		      return m1.getDate().compareTo(m2.getDate());
		    }
		});
		if(donations.size()>0){
			return donations.get(donations.size()-1);
		}
		return null;
	}
	public void deleteDonation(Donation type) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Donation label = (Donation) session.get(Donation.class, type.getId());		
			
			session.delete(label);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	public void updateDonation(Donation type) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Donation label = (Donation) session.get(Donation.class, type.getId());
			label.setDate(type.getDate());
			label.setAmount(type.getAmount());
			label.setMeansOfPayment(type.getMeansOfPayment());
			
			
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
	/**Devuelvo todas las personas cuyo repartidor es distributor
	 * 
	 * @param distributor
	 * @return
	 */
	public List<Person> peopleWhoDistributed(Person distributor){
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		List<Person> aux=session.createCriteria(Person.class)
				 .createCriteria("distributor")
			        .add( Restrictions.like("id", distributor.getId()) ).list();
		
		session.close();
		return aux;
	}
	public boolean eventHasInstanceDate(Event selectedEvent, Date instanceDate) {
		List<EventInstance> instances=listEventsIntancesForEvenr(selectedEvent);
		Calendar cal = Calendar.getInstance();
	    cal.setTime(instanceDate);
	    int year = cal.get(Calendar.YEAR);
	    int month = cal.get(Calendar.MONTH);
	    int day = cal.get(Calendar.DAY_OF_MONTH);
		for (Iterator<EventInstance> iterator = instances.iterator(); iterator.hasNext();) {
			EventInstance eventInstance = (EventInstance) iterator.next();
			Calendar cal2 = Calendar.getInstance();
		    cal2.setTime(eventInstance.getDate());
			if(year==cal2.get(Calendar.YEAR)&&month==cal2.get(Calendar.MONTH)&&day==cal2.get(Calendar.DAY_OF_MONTH))
				return true;
		}
		return false;
	}
}
