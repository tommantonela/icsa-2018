package bd.pojos;


import java.util.Set;

public class Label {
	private String name;
	
	private Set<AssociatedField> associatedFields;
	public Label() {
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Set<AssociatedField> getAssociatedFields() {
		return associatedFields;
	}
	public void setAssociatedFields(Set<AssociatedField> associatedFields) {
		this.associatedFields = associatedFields;
	}
	@Override
	public String toString() {
		return name;
	}
	@Override
	public boolean equals(Object obj) {
		return name.equals(((Label)obj).getName());
	}
}
