package bd.pojos;



public class Event {
	private Long id;
	private String name;
	
	public Event() {
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public boolean equals(Object arg0) {
		return name.equals(((Event)arg0).getName());
	}
	@Override
	public String toString() {
		return name;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
}
