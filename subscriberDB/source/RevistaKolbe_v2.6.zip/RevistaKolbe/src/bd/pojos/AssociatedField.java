package bd.pojos;

public class AssociatedField {
	private String name;
	private Long id;
	private String type;
	
	public static String string_Type = "String";
	public static String date_Type = "Date";
	
	public AssociatedField() {
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getType() {
		return type;
	}
	@Override
	public boolean equals(Object obj) {
		return id.equals(((AssociatedField) obj).getId());
	}
}
