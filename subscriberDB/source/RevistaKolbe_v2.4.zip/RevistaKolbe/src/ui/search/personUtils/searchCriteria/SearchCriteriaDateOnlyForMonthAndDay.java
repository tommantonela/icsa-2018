package ui.search.personUtils.searchCriteria;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import bd.specialCriterions.DayAndMonthEqExpression;


public class SearchCriteriaDateOnlyForMonthAndDay extends
		SearchCriteriaDateOnlyForMonth {
	protected String dayValue;
	public SearchCriteriaDateOnlyForMonthAndDay(String field,String monthValue,String dayValue, boolean equals, String columnName) {
		super(field,monthValue,equals,columnName);
		this.dayValue=dayValue;
	}
	@Override
	public String toString() {
		if(equals){
			return field+" en "+dayValue+"/"+monthValue;
		}else{
			return field+" distinto de "+dayValue+"/"+monthValue;
		}
		
	}
	@Override
	public Criterion getCriterion() {
		Criterion ret=new DayAndMonthEqExpression(columnName, new Integer(dayValue).intValue(),new Integer(monthValue).intValue());
		if(!equals){
			ret=Restrictions.not(ret);
		}
		return ret;
	}
}
