package ui.add;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import bd.DataBaseManager;
import bd.pojos.Person;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.JCheckBox;
import javax.swing.JScrollPane;
import javax.swing.JButton;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;


public class AddPersonFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3107628726794679102L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTextField textField_2;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JCheckBox chckbxRecibeRevista;
	private JLabel lblRepartidor;
	private JLabel lblCantDeEtiquetas;
	private JLabel lblCopiasEnSobre;
	private JLabel lblTipoDeEnvio;
	private JComboBox comboBox_2;
	private Person personToCreate;
	private JComboBox comboBox;
	private JComboBox comboBox_1;
	private JTextArea textArea;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					new AddPersonFrame();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddPersonFrame() {
			
		setTitle("Agregar Persona");
		initializePerson();
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 641, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNombre = new JLabel("Nombre");
		
		textField = new JTextField();
		textField.setColumns(10);
		
		JLabel lblApellido = new JLabel("Apellido");
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		
		JLabel lblGenero = new JLabel("G\u00E9nero");
		
		ComboBoxModel jComboBox1Model = 
				new DefaultComboBoxModel(new String[]{"Masculino","Femenino"});
		
		 comboBox = new JComboBox();
		comboBox.setModel(jComboBox1Model);
		
		JLabel lblFechaDeNacimiento = new JLabel("Fecha de nacimiento");
		
		textField_3 = new JTextField();
		textField_3.setToolTipText("D\u00EDa");
		textField_3.setColumns(10);
		
		JLabel label = new JLabel("/");
		
		textField_2 = new JTextField();
		textField_2.setToolTipText("Mes");
		textField_2.setColumns(10);
		
		JLabel label_1 = new JLabel("/");
		
		textField_4 = new JTextField();
		textField_4.setToolTipText("A\u00F1o");
		textField_4.setColumns(10);
		
		JLabel lblEstadoCivil = new JLabel("Estado civil");
		
		ComboBoxModel jComboBox1Model2 = 
				new DefaultComboBoxModel(new String[]{"Soltero/a","Casado/a", "Viudo/a", "Divorciado/a"});
		comboBox_1 = new JComboBox();
		comboBox_1.setModel(jComboBox1Model2);
		
		JLabel lblTelfono = new JLabel("Tel\u00E9fono");
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		
		JLabel lblCelular = new JLabel("Celular");
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		
		JLabel lblEmail = new JLabel("Email");
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		
		JLabel lblOcupacin = new JLabel("Ocupaci\u00F3n");
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		
		JSeparator separator = new JSeparator();
		
		JLabel lblNotas = new JLabel("Notas");
		
		
		JLabel lblDireccin = new JLabel("Direcci\u00F3n");
		lblDireccin.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		
		JLabel lblCalle = new JLabel("Calle");
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		
		JLabel lblNmero = new JLabel("N\u00FAmero");
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		
		JLabel lblBarrio = new JLabel("Barrio");
		
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		
		JLabel lblCasa = new JLabel("Casa");
		
		textField_12 = new JTextField();
		textField_12.setColumns(10);
		
		JLabel lblPiso = new JLabel("Piso");
		
		textField_13 = new JTextField();
		textField_13.setColumns(10);
		
		JLabel lblDepto = new JLabel("Depto.");
		
		textField_14 = new JTextField();
		textField_14.setColumns(10);
		
		JLabel lblLocalidad = new JLabel("Localidad");
		
		textField_15 = new JTextField();
		textField_15.setColumns(10);
		
		JLabel lblProvincia = new JLabel("Provincia");
		
		textField_16 = new JTextField();
		textField_16.setColumns(10);
		
		JLabel lblPais = new JLabel("Pais");
		
		textField_17 = new JTextField();
		textField_17.setColumns(10);
		
		JLabel lblCp = new JLabel("C.P.");
		
		textField_18 = new JTextField();
		textField_18.setColumns(10);
		
		JSeparator separator_1 = new JSeparator();
		
		JLabel lblInformacinDeEnvio = new JLabel("Informaci\u00F3n de envio");
		lblInformacinDeEnvio.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		
		chckbxRecibeRevista = new JCheckBox("Recibe revista");
		chckbxRecibeRevista.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				checkBoxSendMagazineChanged(chckbxRecibeRevista.isSelected());
			}

		
		});
		
		lblRepartidor = new JLabel("Repartidor");
		lblRepartidor.setEnabled(false);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				acceptButtonClicked();
			}
		});
		
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				cancelButtonClicked();
			}
		});
		
		textField_19 = new JTextField();
		textField_19.setEnabled(false);
		textField_19.setColumns(10);
		
		lblCantDeEtiquetas = new JLabel("Cant. de etiquetas");
		lblCantDeEtiquetas.setEnabled(false);
		
		textField_20 = new JTextField();
		textField_20.setEnabled(false);
		textField_20.setColumns(10);
		
		lblCopiasEnSobre = new JLabel("Copias en sobre");
		lblCopiasEnSobre.setEnabled(false);
		
		textField_21 = new JTextField();
		textField_21.setEnabled(false);
		textField_21.setColumns(10);
		
		lblTipoDeEnvio = new JLabel("Tipo de envio");
		lblTipoDeEnvio.setEnabled(false);
		
		
		
		ComboBoxModel jComboBox1Model3 = 
				new DefaultComboBoxModel(new String[]{"Correo Argentino","Oca", "A mano", "Encomienda"});
		comboBox_2 = new JComboBox();
		comboBox_2.setEnabled(false);
		comboBox_2.setModel(jComboBox1Model3);
		
		JButton btnEditarEtiquetas = new JButton("Editar etiquetas");
		btnEditarEtiquetas.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				btnEditarEtiquetasClicked();
			}
		});
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblCalle)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField_9, GroupLayout.PREFERRED_SIZE, 168, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(lblNmero)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(textField_10, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(lblBarrio)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField_11, GroupLayout.PREFERRED_SIZE, 176, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(46, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(separator, GroupLayout.DEFAULT_SIZE, 609, Short.MAX_VALUE)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNombre)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(lblApellido)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblGenero)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblFechaDeNacimiento)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(label)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 7, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblEstadoCivil)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNotas)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 566, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblTelfono)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(lblCelular))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblOcupacin)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField_8, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(btnEditarEtiquetas)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(textField_6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(lblEmail)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField_7, GroupLayout.PREFERRED_SIZE, 171, GroupLayout.PREFERRED_SIZE)))))
					.addGap(16))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblDireccin)
					.addContainerGap(568, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblCasa)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_12, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(lblPiso)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(textField_13, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(lblDepto)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(textField_14, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(lblCp)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_18, 0, 0, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblLocalidad)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(textField_15, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(lblProvincia)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(textField_16, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(lblPais)))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(textField_17, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(15, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(separator_1, GroupLayout.PREFERRED_SIZE, 608, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(17, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblInformacinDeEnvio, GroupLayout.PREFERRED_SIZE, 165, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(chckbxRecibeRevista)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(29)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblRepartidor)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField_19, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
								.addComponent(lblTipoDeEnvio))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblCantDeEtiquetas)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField_20, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(lblCopiasEnSobre)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField_21, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
									.addGroup(gl_contentPane.createSequentialGroup()
										.addGap(6)
										.addComponent(comboBox_2, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
									.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(btnAceptar)
										.addGap(18)
										.addComponent(btnCancelar))))))
					.addContainerGap(52, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNombre)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblApellido)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblGenero)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(lblFechaDeNacimiento)
							.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(label)
							.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(label_1)
							.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(lblEstadoCivil))
						.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTelfono)
						.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblCelular)
						.addComponent(textField_6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblEmail)
						.addComponent(textField_7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblOcupacin)
						.addComponent(textField_8, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnEditarEtiquetas))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNotas)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(separator, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblDireccin)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCalle)
						.addComponent(textField_9, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNmero)
						.addComponent(textField_10, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblBarrio)
						.addComponent(textField_11, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField_12, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblCasa)
						.addComponent(lblPiso)
						.addComponent(textField_13, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblDepto)
						.addComponent(textField_14, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblCp)
						.addComponent(textField_18, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblLocalidad)
						.addComponent(textField_15, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblProvincia)
						.addComponent(textField_16, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblPais)
						.addComponent(textField_17, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(separator_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblInformacinDeEnvio)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(chckbxRecibeRevista)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblRepartidor)
						.addComponent(textField_19, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblCantDeEtiquetas)
						.addComponent(textField_20, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblCopiasEnSobre)
						.addComponent(textField_21, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTipoDeEnvio)
						.addComponent(comboBox_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancelar)
						.addComponent(btnAceptar)))
		);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		contentPane.setLayout(gl_contentPane);
		this.setVisible(true);
	}
	private void acceptButtonClicked() {
		// TODO Auto-generated method stub
		personToCreate.setName(textField.getText());
		personToCreate.setFamilyName(textField_1.getText());
		personToCreate.setGender(comboBox.getSelectedItem().toString());
		
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		try {
			personToCreate.setBirthDate(df.parse(textField_3.getText()+"/"+textField_2.getText()+"/"+textField_4.getText()));
		}catch (Exception e){
			try {
				personToCreate.setBirthDate(df.parse("01/01/1900"));
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		personToCreate.setCivilState(comboBox_1.getSelectedItem().toString());
		personToCreate.setPhone(textField_5.getText());
		personToCreate.setCellPhone(textField_6.getText());
		personToCreate.setEmail(textField_7.getText());
		personToCreate.setWork(textField_8.getText());
		personToCreate.setNotes(textArea.getText());
		personToCreate.setStreet(textField_9.getText());
		personToCreate.setHouseNumber(textField_10.getText());
		personToCreate.setHouse(textField_12.getText());
		personToCreate.setNeighborhood(textField_11.getText());
		personToCreate.setFloor(textField_13.getText());
		personToCreate.setFlatNumber(textField_14.getText());
		personToCreate.setPostalNumber(textField_18.getText());
		personToCreate.setCity(textField_15.getText());
		personToCreate.setProvince(textField_16.getText());
		personToCreate.setCountry(textField_17.getText());
		personToCreate.setReceivesMagazine(chckbxRecibeRevista.isSelected());
		if(personToCreate.isReceivesMagazine()){
			personToCreate.setDistributor(textField_19.getText());
			personToCreate.setNumberOfLabels(textField_20.getText());
			personToCreate.setNumberOfCopies(textField_21.getText());
			personToCreate.setKindOfShipping(comboBox_2.getSelectedItem().toString());
		}
		DataBaseManager.getInstance().saveEntity(personToCreate);
		this.dispose();
	}

	private void initializePerson() {
		personToCreate=new Person();
		
	}

	private void btnEditarEtiquetasClicked() {
		new EditLabel(personToCreate);
		
	}

	private void cancelButtonClicked() {
		this.dispose();
		
	}
	private void checkBoxSendMagazineChanged(boolean isSelected) {
		lblRepartidor.setEnabled(isSelected);
		textField_19.setEnabled(isSelected);
		lblCantDeEtiquetas.setEnabled(isSelected);
		textField_20.setEnabled(isSelected);
		lblCopiasEnSobre.setEnabled(isSelected);
		textField_21.setEnabled(isSelected);
		lblTipoDeEnvio.setEnabled(isSelected);
		comboBox_2.setEnabled(isSelected);
	}
}
