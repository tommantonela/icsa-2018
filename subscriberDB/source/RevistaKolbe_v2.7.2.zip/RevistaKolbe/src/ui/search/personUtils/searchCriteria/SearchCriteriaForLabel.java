package ui.search.personUtils.searchCriteria;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import ui.search.personUtils.panels.labels.internalPanels.utilForSearchResults.AssociatedFieldValueDateForSearch;
import ui.search.personUtils.panels.labels.internalPanels.utilForSearchResults.AssociatedFieldValueForSearch;
import ui.search.personUtils.panels.labels.internalPanels.utilForSearchResults.AssociatedFieldValueStringForSearch;
import bd.pojos.AssociatedField;
import bd.pojos.AssociatedFieldValueForLabel;
import bd.pojos.Label;
import bd.pojos.Person;

public class SearchCriteriaForLabel extends SearchCriteriaToFilter {
	private Label label;
	private boolean rdbtnPresente;
	private boolean useAssociatedFields;
	private Vector<AssociatedFieldValueForSearch> associatedValues;
	public SearchCriteriaForLabel(Label label, boolean rdbtnPresente, boolean useAssociatedFields, Vector<AssociatedFieldValueForSearch> associatedValues) {
		this.label=label;
		this.rdbtnPresente=rdbtnPresente;
		this.useAssociatedFields=useAssociatedFields;
		this.associatedValues=associatedValues;
	}

	@Override
	public List<Person> filterListOfPersons(List<Person> persons) {
		if(persons.size()==0) return persons;
		List<Person> ret=new ArrayList<Person>();
		if(rdbtnPresente){
			//LABEL PRESENTE
			for (Iterator<Person> iterator = persons.iterator(); iterator.hasNext();) {
				Person person = (Person) iterator.next();
				if(person.hasLabel(label))
					ret.add(person);
			}
			if(useAssociatedFields){
				//LABEL PRESENTE Y CON ASSOCIATED FIELDS
				for (Iterator<AssociatedFieldValueForSearch> iterator = associatedValues.iterator(); iterator
						.hasNext();) {
					AssociatedFieldValueForSearch type = (AssociatedFieldValueForSearch) iterator.next();
					List<Person> ret2=new ArrayList<Person>();
					if(type.getAssociatedField().getType().equals(AssociatedField.date_Type)){
						//El field es una fecha
						AssociatedFieldValueDateForSearch type2=(AssociatedFieldValueDateForSearch)type;

						
						if(type2.isCompleteDate()){
							int day=new Integer(type2.getDay());
							int month=new Integer(type2.getMonth());
							int year=new Integer(type2.getYear());
							if(type2.isEqual()){
								//Miro si la fecha completa coincide con la otra
								for (Iterator<Person> iterator2 = ret.iterator(); iterator2
										.hasNext();) {
									Person person = (Person) iterator2.next();
									AssociatedFieldValueForLabel associatedFieldValueForLabel=person.getAssociatedFieldValuesForLabel(label, type2.getAssociatedField());
									String date=associatedFieldValueForLabel.getValueOfField();
									if(day==getDay(date) && month==getMonth(date) && year==getYear(date))
										ret2.add(person);
								}
							}else{
								for (Iterator<Person> iterator2 = ret.iterator(); iterator2
										.hasNext();) {
									Person person = (Person) iterator2.next();
									AssociatedFieldValueForLabel associatedFieldValueForLabel=person.getAssociatedFieldValuesForLabel(label, type2.getAssociatedField());
									String date=associatedFieldValueForLabel.getValueOfField();
									if(!(day==getDay(date) && month==getMonth(date) && year==getYear(date)))
										ret2.add(person);
								}
							}
						}else if(type2.isJustMonthAndDay()){
							int day=new Integer(type2.getDay());
							int month=new Integer(type2.getMonth());
							if(type2.isEqual()){
								for (Iterator<Person> iterator2 = ret.iterator(); iterator2
										.hasNext();) {
									Person person = (Person) iterator2.next();
									AssociatedFieldValueForLabel associatedFieldValueForLabel=person.getAssociatedFieldValuesForLabel(label, type2.getAssociatedField());
									String date=associatedFieldValueForLabel.getValueOfField();
									if(day==getDay(date) && month==getMonth(date))
										ret2.add(person);
								}
							}else{
								for (Iterator<Person> iterator2 = ret.iterator(); iterator2
										.hasNext();) {
									Person person = (Person) iterator2.next();
									AssociatedFieldValueForLabel associatedFieldValueForLabel=person.getAssociatedFieldValuesForLabel(label, type2.getAssociatedField());
									String date=associatedFieldValueForLabel.getValueOfField();
									if(!(day==getDay(date) && month==getMonth(date)))
										ret2.add(person);
								}
							}
						}else if(type2.isJustMonth()){
							int month=new Integer(type2.getMonth());
							if(type2.isEqual()){
								for (Iterator<Person> iterator2 = ret.iterator(); iterator2
										.hasNext();) {
									Person person = (Person) iterator2.next();
									AssociatedFieldValueForLabel associatedFieldValueForLabel=person.getAssociatedFieldValuesForLabel(label, type2.getAssociatedField());
									String date=associatedFieldValueForLabel.getValueOfField();
									if( month==getMonth(date))
										ret2.add(person);
								}
							}else{
								for (Iterator<Person> iterator2 = ret.iterator(); iterator2
										.hasNext();) {
									Person person = (Person) iterator2.next();
									AssociatedFieldValueForLabel associatedFieldValueForLabel=person.getAssociatedFieldValuesForLabel(label, type2.getAssociatedField());
									String date=associatedFieldValueForLabel.getValueOfField();
									if(!( month==getMonth(date)))
										ret2.add(person);
								}
							}
						}else if(type2.isJustYear()){
							int year=new Integer(type2.getYear());
							if(type2.isEqual()){
								for (Iterator<Person> iterator2 = ret.iterator(); iterator2
										.hasNext();) {
									Person person = (Person) iterator2.next();
									AssociatedFieldValueForLabel associatedFieldValueForLabel=person.getAssociatedFieldValuesForLabel(label, type2.getAssociatedField());
									String date=associatedFieldValueForLabel.getValueOfField();
									if( year==getYear(date))
										ret2.add(person);
								}
							}else{
								for (Iterator<Person> iterator2 = ret.iterator(); iterator2
										.hasNext();) {
									Person person = (Person) iterator2.next();
									AssociatedFieldValueForLabel associatedFieldValueForLabel=person.getAssociatedFieldValuesForLabel(label, type2.getAssociatedField());
									String date=associatedFieldValueForLabel.getValueOfField();
									if(!( year==getYear(date)))
										ret2.add(person);
								}
							}
						}
					}else{//Es un string
						String valueForField=((AssociatedFieldValueStringForSearch)type).getValue();
						
						if(type.isEqual()){
							for (Iterator<Person> iterator2 = ret.iterator(); iterator2
									.hasNext();) {
								Person person = (Person) iterator2.next();
								AssociatedFieldValueForLabel associatedFieldValueForLabel=person.getAssociatedFieldValuesForLabel(label, type.getAssociatedField());
								if(associatedFieldValueForLabel.getValueOfField().equalsIgnoreCase(valueForField))
									ret2.add(person);
							}
						}else{
							for (Iterator<Person> iterator2 = ret.iterator(); iterator2
									.hasNext();) {
								Person person = (Person) iterator2.next();
								AssociatedFieldValueForLabel associatedFieldValueForLabel=person.getAssociatedFieldValuesForLabel(label, type.getAssociatedField());
								if(!associatedFieldValueForLabel.getValueOfField().equalsIgnoreCase(valueForField))
									ret2.add(person);
							}
						}
						
					}
					ret=ret2;
				}
			}
		}else{
			//LABEL AUSENTE
			for (Iterator<Person> iterator = persons.iterator(); iterator.hasNext();) {
				Person person = (Person) iterator.next();
				if(!person.hasLabel(label))
					ret.add(person);
			}
		}
		return ret;
	}
	

	public Label getLabel() {
		return label;
	}
	@Override
	public boolean isLabelCriteria() {
		return true;
	}
	@Override
	public String toString() {
		String ret="Etiqueta \""+label.getName()+"\"";
		if(rdbtnPresente){
			ret=ret+" presente";
			if(useAssociatedFields){
				ret=ret+" { ";
				for (Iterator<AssociatedFieldValueForSearch> iterator = associatedValues.iterator(); iterator
						.hasNext();) {
					AssociatedFieldValueForSearch type = (AssociatedFieldValueForSearch) iterator.next();
					if(type.getAssociatedField().getType().equals(AssociatedField.date_Type)){
						AssociatedFieldValueDateForSearch type2=(AssociatedFieldValueDateForSearch)type;
						if(type2.isCompleteDate()){
							if(type2.isEqual()){
								ret=ret+type2.getAssociatedField().getName()+"="+type2.getDay()+"/"+type2.getMonth()+"/"+type2.getYear();
							}else{
								ret=ret+type2.getAssociatedField().getName()+" distinto de "+type2.getDay()+"/"+type2.getMonth()+"/"+type2.getYear();
							}
						}else if(type2.isJustMonthAndDay()){
							if(type2.isEqual()){
								ret=ret+type2.getAssociatedField().getName()+" en "+type2.getDay()+"/"+type2.getMonth();
							}else{
								ret=ret+type2.getAssociatedField().getName()+" distinto de "+type2.getDay()+"/"+type2.getMonth();
							}
						}else if(type2.isJustMonth()){
							if(type2.isEqual()){
								ret=ret+type2.getAssociatedField().getName()+" en el mes "+type2.getMonth();
							}else{
								ret=ret+type2.getAssociatedField().getName()+" distinto del mes "+type2.getMonth();
							}
						}else if(type2.isJustYear()){
							if(type2.isEqual()){
								ret=ret+type2.getAssociatedField().getName()+" en el a\u00F1o "+type2.getYear();
							}else{
								ret=ret+type2.getAssociatedField().getName()+" distinto del a\u00F1o "+type2.getYear();
							}
						}
					}else{//Es un string
						ret=ret+type.getAssociatedField().getName();
						if(type.isEqual()){
							ret=ret+"="+ ((AssociatedFieldValueStringForSearch)type).getValue();
						}else{
							ret=ret+" distinto a "+ ((AssociatedFieldValueStringForSearch)type).getValue();
						}
					}
					ret=ret+" "; 
				}
				ret=ret+"}";
			}
		}else{
			ret=ret+" ausente";
		}
		return ret;
	}
	private int getDay(String date){
		if(date.length()==2)//No pusieron fecha
			return 0;
		return new Integer(date.split("/")[0]);
	}
	private int getMonth(String date){
		if(date.length()==2)//No pusieron fecha
			return 0;
		return new Integer(date.split("/")[1]);
	}
	private int getYear(String date){
		if(date.length()==2)//No pusieron fecha
			return 0;
		return new Integer(date.split("/")[2]);
	}
}
