package ui.search.personUtils.searchCriteria;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import ui.search.SearchPerson;

import bd.DataBaseManager;
import bd.pojos.Donation;
import bd.pojos.Person;

public class SearchCriteriaForDonation extends SearchCriteriaToFilter {
	private boolean madeDonation;
	private boolean useDate;
	private Date fromDate;
	private Date toDate;
	private SearchPerson searchPersonPanel;//Solo lo lleno si estoy buscando si se hicieron donaciones
	
	
	
	public SearchCriteriaForDonation(boolean madeDonation, boolean useDate,
			Date fromDate, Date toDate, SearchPerson searchPersonPanel) {
		super();
		this.madeDonation = madeDonation;
		this.useDate = useDate;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.searchPersonPanel=searchPersonPanel;
	}
	@Override
	public String toString() {
		String ret;
		if(madeDonation)
			ret="Realizo donaci�n";
		else
			ret="No realizo donaci�n";
		if(useDate){
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			ret=ret+" durante "+dateFormat.format(fromDate)+" y "+dateFormat.format(toDate);
		}
		return ret;
	}

	@Override
	public boolean isDonationCriteria() {
		return true;
	}

	@Override
	public List<Person> filterListOfPersons(List<Person> persons) {
		List<Person> ret=new ArrayList<Person>();
		Hashtable<Person,Donation> donationsOfLastSearch=new Hashtable<Person, Donation>();
		
		for (Iterator<Person> iterator = persons.iterator(); iterator.hasNext();) {
			Person person = (Person) iterator.next();
			if(useDate){
				List<Donation> donations=DataBaseManager.getInstance().listDonationsForPersonBetweenDates(person, fromDate, toDate);
				if(madeDonation){
					if(donations.size()>0){
						ret.add(person);
						
						//Ordeno para obtener la ultima
						Collections.sort(donations, new Comparator<Donation>() {
						    public int compare(Donation m1, Donation m2) {
						        return m1.getDate().compareTo(m2.getDate());
						    }
						});
						donationsOfLastSearch.put(person, donations.get(donations.size()-1));
					}
				}else{
					if(donations.size()==0)
						ret.add(person);
				}
			}else{
				List<Donation> donations=DataBaseManager.getInstance().listDonationsForPerson(person);
				if(madeDonation){
					if(donations.size()>0){
						ret.add(person);
						
						//Ordeno para obtener la ultima
						Collections.sort(donations, new Comparator<Donation>() {
						    public int compare(Donation m1, Donation m2) {
						        return m1.getDate().compareTo(m2.getDate());
						    }
						});
						donationsOfLastSearch.put(person, donations.get(donations.size()-1));
					}
				}else{
					if(donations.size()==0)
						ret.add(person);
				}
			}
		}
		searchPersonPanel.setDonationsOfLastSearch(donationsOfLastSearch);
		return ret;
	}

}
