package bd.pojos;

import java.text.SimpleDateFormat;
import java.util.Date;

public class EventInstance {
	private Date date;
	private Event event;
	
	public EventInstance() {
		// TODO Auto-generated constructor stub
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Event getEvent() {
		return event;
	}
	public void setEvent(Event event) {
		this.event = event;
	}
	@Override
	public boolean equals(Object obj) {
		return date.equals(((EventInstance)obj).getDate()) && event.equals(((EventInstance)obj).getEvent());
	}
	@Override
	public String toString() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		return event.getName()+" ("+dateFormat.format(date)+")";
	}
}
