package ui.add;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.WindowConstants;

import bd.DataBaseManager;
import bd.pojos.AssociatedField;
import bd.pojos.Label;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import javax.swing.JComboBox;

public class AddLabel extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4028815875007820466L;
	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTable table;
	private String[][] tableData;
	private JButton btnEliminarCampo;
	private JComboBox comboBox;
	private Vector<String> kindOfFieldsSelected;
	
	

	/**
	 * Create the dialog.
	 */
	public AddLabel() {
		setTitle("Agregar etiqueta");
		setBounds(100, 100, 597, 219);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		JLabel lblNombreDeEtiqueta = new JLabel("Nombre de etiqueta");
		textField = new JTextField();
		textField.setColumns(10);
		
		JLabel lblAgregarCampoAsociado = new JLabel("Campo asociado");
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		
		JButton btnAgregarCampo = new JButton("Agregar campo");
		btnAgregarCampo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnAgregarCampoClicked();
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		
		btnEliminarCampo = new JButton("Eliminar campo");
		btnEliminarCampo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnEliminarCampoClicked();
			}
		});
		btnEliminarCampo.setEnabled(false);
		
		JLabel lblTipo = new JLabel("Tipo");
		
		ComboBoxModel jComboBox1Model2 = 
				new DefaultComboBoxModel(new String[]{"Texto","Fecha"});
		comboBox = new JComboBox();
		comboBox.setModel(jComboBox1Model2);
		kindOfFieldsSelected=new Vector<String>();
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addComponent(lblAgregarCampoAsociado)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
								.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 210, GroupLayout.PREFERRED_SIZE))
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(lblTipo)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(btnAgregarCampo)
									.addContainerGap())
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addGap(18)
									.addComponent(btnEliminarCampo)
									.addContainerGap())))
						.addGroup(Alignment.LEADING, gl_contentPanel.createSequentialGroup()
							.addComponent(lblNombreDeEtiqueta)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())))
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNombreDeEtiqueta)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAgregarCampoAsociado)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblTipo)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnAgregarCampo))
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGap(18)
							.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 56, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGap(28)
							.addComponent(btnEliminarCampo)))
					.addGap(16))
		);
		
		tableData=new String[0][1];
		TableModel tableModel = new DefaultTableModel(
				tableData, new String[] { "Campos asociados" });
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				tableClicked();
			}
		});
		table.setModel(tableModel);
		scrollPane.setViewportView(table);
		contentPanel.setLayout(gl_contentPanel);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Agregar");
				okButton.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent arg0) {
						okButtonClicked();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancelar");
				cancelButton.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						cancelButtonClicked();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}

	

	private void btnAgregarCampoClicked() {
		String[][] newscheduleTableModel = new String[tableData.length + 1][1];
		TableModel tm = table.getModel();
		for (int i = 0; i < tableData.length; i++)
				newscheduleTableModel[i][0] = (String) tm.getValueAt(i, 0);
		
		newscheduleTableModel[tableData.length][0] = textField_1.getText();
		textField_1.setText("");
		kindOfFieldsSelected.add((String)comboBox.getSelectedItem());
		tableData = newscheduleTableModel;
		table.setModel(new DefaultTableModel(tableData,
				new String[] {"Campos asociados" }));
		table.getTableHeader().setVisible(true);
	}

	private void btnEliminarCampoClicked() {
		int selectedRow = table.getSelectedRow();
		String[][] newscheduleTableModel = new String[tableData.length - 1][1];
		TableModel tm = table.getModel();
		for (int i = 0; i < selectedRow; i++)
				newscheduleTableModel[i][0] = (String) tm.getValueAt(i, 0);
		for (int i = selectedRow; i < tableData.length - 1; i++)
				newscheduleTableModel[i][0] = (String) tm.getValueAt(i + 1, 0);
		kindOfFieldsSelected.remove(selectedRow);
		tableData = newscheduleTableModel;
		table.setModel(new DefaultTableModel(tableData,
				new String[] { "Campos asociados" }));
		btnEliminarCampo.setSelected(false);
		
	}

	private void tableClicked() {
		if ((table.getSelectedRow() != -1)
				&& (tableData.length > 0))
			btnEliminarCampo.setEnabled(true);
		else
			btnEliminarCampo.setEnabled(false);
		
	}

	private void cancelButtonClicked() {
		this.dispose();
		
	}
	private void okButtonClicked() {
		Label newLabel=new Label();
		newLabel.setName(textField.getText());
		Set<AssociatedField> associatedFields=new HashSet<AssociatedField>();
		TableModel tm = table.getModel();
		for (int i = 0; i < tableData.length; i++){
			AssociatedField newField=new AssociatedField();
			newField.setName((String) tm.getValueAt(i, 0));
			if((kindOfFieldsSelected.get(i)).equals("Texto"))
				newField.setType(AssociatedField.string_Type);
			else
				newField.setType(AssociatedField.date_Type);
			associatedFields.add(newField);
			//DataBaseManager.getInstance().saveEntity(newField);
		}
				
		newLabel.setAssociatedFields(associatedFields);
		
		DataBaseManager.getInstance().saveEntity(newLabel);
		this.dispose();
	}
}
