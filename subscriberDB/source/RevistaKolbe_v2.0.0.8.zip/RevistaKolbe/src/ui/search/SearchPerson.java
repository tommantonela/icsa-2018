package ui.search;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import org.hibernate.criterion.Criterion;

import ui.search.personUtils.panels.donation.CriteriaCreationPanelForDonation;
import ui.search.personUtils.panels.events.CriteriaCreationPanelForEvent;
import ui.search.personUtils.panels.fields.CriteriaCreationPanelForField;
import ui.search.personUtils.panels.fields.SimpleBooleanCreationPanel;
import ui.search.personUtils.panels.fields.SimpleComboBoxCreationPanel;
import ui.search.personUtils.panels.fields.SimpleDateCreationPanel;
import ui.search.personUtils.panels.fields.SimpleFieldCreationPanel;
import ui.search.personUtils.panels.labels.CriteriaCreationPanelForLabel;
import ui.search.personUtils.searchCriteria.SearchCriteria;
import ui.search.personUtils.searchCriteria.SearchCriteriaForField;
import ui.search.personUtils.searchCriteria.SearchCriteriaForLabel;
import ui.search.personUtils.searchCriteria.SearchCriteriaToFilter;
import ui.search.personUtils.searchCriteria.SearchCriteriaToQuery;
import bd.DataBaseManager;
import bd.pojos.Donation;
import bd.pojos.Event;
import bd.pojos.Label;
import bd.pojos.Person;

public class SearchPerson extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7332055148173535906L;
	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private String[][] tableData;
	private Vector<String> fieldsInComboBox;
	private Vector<Label> labelsInComboBox;
	private Vector<Event> eventsInComboBox;
	private JComboBox comboBox;
	private JComboBox comboBox_1;
	private JComboBox comboBox_2;
	//private CriteriaCreationPanel fieldsPanel;
	private JButton btnAgregarField;
	private JButton btnAgregarLabel;
	private JButton btnAgregarEvent;
	private JButton btnEliminarCriterio;
	private JButton btnAgregarDonation;
	private JScrollPane scrollPaneField;
	private JScrollPane scrollPaneLabels;
	private JScrollPane scrollPaneSearchs;
	private JScrollPane scrollPaneEvents;
	private JScrollPane scrollPaneDonations;
	private Vector<SearchCriteria> criteriaSelected;
	private JButton searchButton;
	private JCheckBox chckbxDonaciones;
	private Hashtable<Person,Donation> donationsOfLastSearch;
	private JButton btnBuscarTodasLas;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			 new SearchPerson();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public SearchPerson() {
		setBounds(100, 100, 450, 621);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		JLabel lblCampos = new JLabel("Campos");
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				comboBoxFieldsChanged();
			}
		});
		loadFields();
		btnAgregarField = new JButton("Agregar");
		btnAgregarField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				btnAgregarFieldClicked();
			}
		});
		btnAgregarField.setEnabled(false);
		
		scrollPaneField = new JScrollPane();
		JPanel fakePanel = new JPanel();
		scrollPaneField.setViewportView(fakePanel);
		//scrollPane.setVisible(false);
		
		JLabel lblEtiquetas = new JLabel("Etiquetas");
		
		comboBox_1 = new JComboBox();
		comboBox_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				comboBoxLabelsChanged();
			}
		});
		loadLabels();
		btnAgregarLabel = new JButton("Agregar");
		btnAgregarLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				btnAgregarLabelClicked();
			}
		});
		btnAgregarLabel.setEnabled(false);
		scrollPaneLabels = new JScrollPane();
		//scrollPane_1.setVisible(false);
		
		scrollPaneEvents = new JScrollPane();
		//scrollPane_2.setVisible(false);
		
		JLabel lblEventos = new JLabel("Eventos");
		
		comboBox_2 = new JComboBox();
		comboBox_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				comboBoxEventsChanged();
			}
		});
		loadEvents();
		btnAgregarEvent = new JButton("Agregar");
		btnAgregarEvent.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				btnAgregarEventClicked();
			}
		});
		btnAgregarEvent.setEnabled(false);
		scrollPaneSearchs = new JScrollPane();
		
		btnEliminarCriterio = new JButton("<html>Eliminar<br>criterio</html>");
		btnEliminarCriterio.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				btnEliminarCriterioClicked();
			}
		});
		btnEliminarCriterio.setEnabled(false);
		
		chckbxDonaciones = new JCheckBox("Donaciones");
		chckbxDonaciones.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				donationsButtonClicked();
			}
		});
		
		btnAgregarDonation = new JButton("Agregar");
		btnAgregarDonation.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnAgregarDonationClicked();
			}
		});
		btnAgregarDonation.setEnabled(false);
		
		scrollPaneDonations = new JScrollPane();
		
		btnBuscarTodasLas = new JButton("Buscar todas las personas");
		btnBuscarTodasLas.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnBuscarTodasLasClicked();
			}
		});
		
		
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addComponent(lblEventos, GroupLayout.PREFERRED_SIZE, 73, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(comboBox_2, GroupLayout.PREFERRED_SIZE, 201, GroupLayout.PREFERRED_SIZE)
									.addGap(45)
									.addComponent(btnAgregarEvent, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addComponent(scrollPaneSearchs, 0, 0, Short.MAX_VALUE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(btnEliminarCriterio, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE))
								.addComponent(scrollPaneEvents, GroupLayout.PREFERRED_SIZE, 420, GroupLayout.PREFERRED_SIZE))
							.addGroup(gl_contentPanel.createSequentialGroup()
								.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING, false)
									.addGroup(gl_contentPanel.createSequentialGroup()
										.addComponent(lblEtiquetas, GroupLayout.PREFERRED_SIZE, 73, GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, 201, GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(btnAgregarLabel, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE))
									.addComponent(scrollPaneField, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 420, GroupLayout.PREFERRED_SIZE)
									.addComponent(scrollPaneLabels, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 420, GroupLayout.PREFERRED_SIZE)
									.addGroup(Alignment.LEADING, gl_contentPanel.createSequentialGroup()
										.addComponent(lblCampos)
										.addGap(26)
										.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
											.addComponent(btnBuscarTodasLas, GroupLayout.PREFERRED_SIZE, 273, GroupLayout.PREFERRED_SIZE)
											.addGroup(gl_contentPanel.createSequentialGroup()
												.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 201, GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
												.addComponent(btnAgregarField)))))
								.addPreferredGap(ComponentPlacement.RELATED, 7, GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING, false)
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addComponent(chckbxDonaciones)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(btnAgregarDonation))
								.addComponent(scrollPaneDonations, GroupLayout.PREFERRED_SIZE, 420, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED, 7, GroupLayout.PREFERRED_SIZE)))
					.addGap(7))
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addComponent(btnBuscarTodasLas)
					.addGap(10)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCampos)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnAgregarField))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPaneField, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
					.addGap(13)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblEtiquetas)
						.addComponent(btnAgregarLabel))
					.addGap(7)
					.addComponent(scrollPaneLabels, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGap(1)
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblEventos)
								.addComponent(comboBox_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addComponent(btnAgregarEvent))
					.addGap(7)
					.addComponent(scrollPaneEvents, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
					.addGap(6)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(chckbxDonaciones)
						.addComponent(btnAgregarDonation))
					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(scrollPaneDonations, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING)
						.addComponent(scrollPaneSearchs, GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addComponent(btnEliminarCriterio)
							.addGap(40)))
					.addContainerGap())
		);
		
		tableData=new String[0][1];
		TableModel tableModel = new DefaultTableModel(
				tableData, new String[] { "Criterios de búsqueda" });
		
		table = new JTable();
		table.setModel(tableModel);
		scrollPaneSearchs.setViewportView(table);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				tableClicked();
			}
		});
		
		//table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		
		JPanel panel_2 = new JPanel();
		scrollPaneEvents.setViewportView(panel_2);
		
		JPanel panel_1 = new JPanel();
		scrollPaneLabels.setViewportView(panel_1);
		
		JPanel panel_3 = new JPanel();
		scrollPaneDonations.setViewportView(panel_3);
		//scrollPane.setViewportView(panel);
		contentPanel.setLayout(gl_contentPanel);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				searchButton = new JButton("Buscar");
				searchButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						searchButtonClicked();
					}
				});
				searchButton.setActionCommand("OK");
				searchButton.setEnabled(false);
				buttonPane.add(searchButton);
				getRootPane().setDefaultButton(searchButton);
			}
			{
				JButton cancelButton = new JButton("Cancelar");
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						cancelButtonClicked();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		comboBox.setSelectedIndex(-1);
		comboBox_1.setSelectedIndex(-1);
		comboBox_2.setSelectedIndex(-1);
		criteriaSelected=new Vector<SearchCriteria>();
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}

	

	private void btnBuscarTodasLasClicked() {
		List<Person> persons=DataBaseManager.getInstance().listPersons();
		
		new Searchresults(persons,new Hashtable<Person, Donation>());
		
	}

	private void btnAgregarDonationClicked() {
		chckbxDonaciones.setSelected(false);
		btnAgregarDonation.setEnabled(false);
		
		SearchCriteria searchCriteriaSelected=((CriteriaCreationPanelForDonation)scrollPaneDonations.getViewport().getView()).createSearchCriteria();
		criteriaSelected.add(searchCriteriaSelected);
		addCriteriaToTable(searchCriteriaSelected);
		searchButton.setEnabled(true);
		scrollPaneDonations.setViewportView(new JPanel());
	}

	private void donationsButtonClicked() {
		if(chckbxDonaciones.isSelected()){
			btnAgregarDonation.setEnabled(true);
			scrollPaneDonations.setViewportView(new CriteriaCreationPanelForDonation(this));
			this.validate();
		}else{
			btnAgregarDonation.setEnabled(false);
			scrollPaneDonations.setViewportView(new JPanel());
		}
		
	}

	private void btnAgregarEventClicked() {
		//labelsInComboBox.remove(comboBox_1.getSelectedIndex());
		SearchCriteria searchCriteriaSelected=((CriteriaCreationPanelForEvent)scrollPaneEvents.getViewport().getView()).createSearchCriteria();
		criteriaSelected.add(searchCriteriaSelected);
		//createComboBoxModel(labelsInComboBox, comboBox_1);
		
		addCriteriaToTable(searchCriteriaSelected);
		
		//scrollPaneLabels.setViewportView(new JPanel());
		//this.validate();
		searchButton.setEnabled(true);
		
	}

	private void searchButtonClicked() {
		donationsOfLastSearch=new Hashtable<Person, Donation>();
		Vector<Criterion> databaseCriterion=new Vector<Criterion>();
		for (Iterator<SearchCriteria> iterator = criteriaSelected.iterator(); iterator.hasNext();) {
			SearchCriteria searchCriteria = iterator.next();
			if(searchCriteria.isCriteriaToQuery())
				databaseCriterion.add(((SearchCriteriaToQuery)searchCriteria).getCriterion());
		}
		List<Person> persons=DataBaseManager.getInstance().listPerson(databaseCriterion);
		for (Iterator<SearchCriteria> iterator = criteriaSelected.iterator(); iterator.hasNext();) {
			SearchCriteria searchCriteria = iterator.next();
			if(searchCriteria.isCriteriaToFilter())
				persons=((SearchCriteriaToFilter)searchCriteria).filterListOfPersons(persons);
		}
		new Searchresults(persons,donationsOfLastSearch);
	}

	private void tableClicked() {
		if ((table.getSelectedRow() != -1)
				&& (tableData.length > 0))
		
			btnEliminarCriterio.setEnabled(true);
		
		else
			btnEliminarCriterio.setEnabled(false);
		
	}



	private void btnEliminarCriterioClicked() {
		int selectedRow = table.getSelectedRow();
		String[][] newscheduleTableModel = new String[tableData.length - 1][1];
		TableModel tm = table.getModel();
		for (int i = 0; i < selectedRow; i++)
				newscheduleTableModel[i][0] = (String) tm.getValueAt(i, 0);
		for (int i = selectedRow; i < tableData.length - 1; i++)
				newscheduleTableModel[i][0] = (String) tm.getValueAt(i + 1, 0);
		
		tableData = newscheduleTableModel;
		table.setModel(new DefaultTableModel(tableData,
				new String[] { "Criterios de búsqueda" }));
		btnEliminarCriterio.setEnabled(false);
		SearchCriteria removedCriteria=criteriaSelected.remove(selectedRow);
		
		if(removedCriteria.isFieldCriteria()){
			fieldsInComboBox.add(((SearchCriteriaForField)removedCriteria).getField());
			createComboBoxModel(fieldsInComboBox, comboBox);
			scrollPaneField.setViewportView(new JPanel());
			this.validate();
		}else if(removedCriteria.isLabelCriteria()){
			labelsInComboBox.add(((SearchCriteriaForLabel)removedCriteria).getLabel());
			createComboBoxModel(labelsInComboBox, comboBox_1);
			scrollPaneLabels.setViewportView(new JPanel());
			this.validate();
		}else if(removedCriteria.isEventCriteria()){
			/*eventsInComboBox.add(((SearchCriteriaForEvent)removedCriteria).getEvent());
			createComboBoxModel(eventsInComboBox, comboBox_2);
			scrollPaneEvents.setViewportView(new JPanel());
			this.validate();*/
		}else if(removedCriteria.isDonationCriteria()){
			/*eventsInComboBox.add(((SearchCriteriaForEvent)removedCriteria).getEvent());
			createComboBoxModel(eventsInComboBox, comboBox_2);
			scrollPaneEvents.setViewportView(new JPanel());
			this.validate();*/
		}
		searchButton.setEnabled(criteriaSelected.size()>0);
	}

	private void btnAgregarFieldClicked() {
		fieldsInComboBox.remove(comboBox.getSelectedIndex());
		SearchCriteria searchCriteriaSelected=((CriteriaCreationPanelForField)scrollPaneField.getViewport().getView()).createSearchCriteria();
		criteriaSelected.add(searchCriteriaSelected);
		createComboBoxModel(fieldsInComboBox, comboBox);
		
		addCriteriaToTable(searchCriteriaSelected);
		
		scrollPaneField.setViewportView(new JPanel());
		this.validate();
		searchButton.setEnabled(true);
	}
	private void btnAgregarLabelClicked() {
		labelsInComboBox.remove(comboBox_1.getSelectedIndex());
		SearchCriteria searchCriteriaSelected=((CriteriaCreationPanelForLabel)scrollPaneLabels.getViewport().getView()).createSearchCriteria();
		criteriaSelected.add(searchCriteriaSelected);
		createComboBoxModel(labelsInComboBox, comboBox_1);
		
		addCriteriaToTable(searchCriteriaSelected);
		
		scrollPaneLabels.setViewportView(new JPanel());
		this.validate();
		searchButton.setEnabled(true);
	}
	private void addCriteriaToTable(SearchCriteria searchCriteriaSelected) {
		String[][] newscheduleTableModel = new String[tableData.length + 1][1];
		TableModel tm = table.getModel();
		for (int i = 0; i < tableData.length; i++)
				newscheduleTableModel[i][0] = (String) tm.getValueAt(i, 0);
		
		newscheduleTableModel[tableData.length][0] = searchCriteriaSelected.toString();
		
		tableData = newscheduleTableModel;
		table.setModel(new DefaultTableModel(tableData,
				new String[] {"Criterios de búsqueda" }));
		table.getTableHeader().setVisible(true);
		
		/*scrollPaneSearchs.setViewportView(null);
		scrollPaneSearchs.setViewportView(table);*/
	}

	private void comboBoxFieldsChanged() {
		if(comboBox.getSelectedItem()!=null){
			btnAgregarField.setEnabled(true);
			String selectedField=comboBox.getSelectedItem().toString();
			scrollPaneField.setVisible(false);
			this.validate();
			scrollPaneField.setVisible(true);
			scrollPaneField.setViewportView(getCriteriaCreationPanelForField(selectedField));
			this.validate();
		}
		
	}
	
	private void comboBoxLabelsChanged() {
		if(comboBox_1.getSelectedItem()!=null){
			btnAgregarLabel.setEnabled(true);
			Label selectedLabel=labelsInComboBox.get(comboBox_1.getSelectedIndex());
			scrollPaneLabels.setVisible(false);
			this.validate();
			scrollPaneLabels.setVisible(true);
			scrollPaneLabels.setViewportView(new CriteriaCreationPanelForLabel(selectedLabel/*,"labels"*/));
			this.validate();
		}
	}
	
	private void comboBoxEventsChanged() {
		if(comboBox_2.getSelectedItem()!=null){
			btnAgregarEvent.setEnabled(true);
			Event selectedEvent=eventsInComboBox.get(comboBox_2.getSelectedIndex());
			scrollPaneEvents.setVisible(false);
			this.validate();
			scrollPaneEvents.setVisible(true);
			scrollPaneEvents.setViewportView(new CriteriaCreationPanelForEvent(selectedEvent));
			this.validate();
		}
	}
	private Component getCriteriaCreationPanelForField(String selectedField) {
		if(selectedField.equals("Género")||selectedField.equals("Estado civil")){
			if(selectedField.equals("Género")){
				return new SimpleComboBoxCreationPanel(selectedField,"gender", new String[]{"Masculino","Femenino"});
			}else{
				return new SimpleComboBoxCreationPanel(selectedField,"civilState", new String[]{"Soltero/a","Casado/a", "Viudo/a", "Divorciado/a", "En pareja"});
			}
		}else{ 
			if(selectedField.equals("Fecha de nacimiento")){
				return new SimpleDateCreationPanel(selectedField,"birthDate");
			}else{
				if(selectedField.equals("Nombre")){
					return new SimpleFieldCreationPanel(selectedField,"name");
				}else{
					if(selectedField.equals("Apellido")){
						return new SimpleFieldCreationPanel(selectedField,"familyName");
					}else{
						if(selectedField.equals("Email")){
							return new SimpleFieldCreationPanel(selectedField,"email");
						}else{
							if(selectedField.equals("Ocupación")){
								return new SimpleFieldCreationPanel(selectedField,"work");
							}else{
								if(selectedField.equals("Localidad")){
									return new SimpleFieldCreationPanel(selectedField,"city");
								}else{
									if(selectedField.equals("Provincia")){
										return new SimpleFieldCreationPanel(selectedField,"province");
									}else{
										if(selectedField.equals("Pais")){
											return new SimpleFieldCreationPanel(selectedField,"country");
										}else{
											if(selectedField.equals("Recibe la revista")){
												return new SimpleBooleanCreationPanel(selectedField,"receivesMagazine");
											}else{
												if(selectedField.equals("Tipo de envio")){
													return new SimpleComboBoxCreationPanel(selectedField,"kindOfShipping", new String[]{"Correo Argentino","Oca", "A mano", "Encomienda"});
												}else{
													return null;
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	
	}

	private void cancelButtonClicked() {
		this.dispose();
	}
	private void loadLabels(){
		labelsInComboBox=new Vector<Label>(DataBaseManager.getInstance().listLabels());
		createComboBoxModel(labelsInComboBox,comboBox_1);
	}
	private void createComboBoxModel(Vector<?> source, JComboBox destination){
		if(source!=null){
			String[] labelsNames=new String[source.size()];
			for (int i = 0; i < source.size(); i++) {
				labelsNames[i]=source.get(i).toString();
			}
			
			ComboBoxModel jComboBox1Model2 = 
					new DefaultComboBoxModel(labelsNames);
			destination.setModel(jComboBox1Model2);
		}
		destination.setSelectedIndex(-1);
	}
	private void loadFields(){
		fieldsInComboBox=new Vector<String>();
		fieldsInComboBox.add("Nombre");
		fieldsInComboBox.add("Apellido");
		fieldsInComboBox.add("Fecha de nacimiento");
		fieldsInComboBox.add("Género");
		fieldsInComboBox.add("Estado civil");
		fieldsInComboBox.add("Email");
		fieldsInComboBox.add("Ocupación");
		fieldsInComboBox.add("Localidad");
		fieldsInComboBox.add("Provincia");
		fieldsInComboBox.add("Pais");
		fieldsInComboBox.add("Recibe la revista");
		fieldsInComboBox.add("Tipo de envio");
		createComboBoxModel(fieldsInComboBox, comboBox);
	}
	private void loadEvents(){
		eventsInComboBox=new Vector<Event>(DataBaseManager.getInstance().listEvents());
		createComboBoxModel(eventsInComboBox,comboBox_2);
	}
	public void setDonationsOfLastSearch(
			Hashtable<Person, Donation> donationsOfLastSearch) {
		this.donationsOfLastSearch = donationsOfLastSearch;
	}
}
