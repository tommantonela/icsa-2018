package ui.search.personUtils.searchCriteria;

import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

public class SearchCriteriaForSimpleField extends SearchCriteriaForField{
	
	private String searchValue;
	
	
	public SearchCriteriaForSimpleField(String field, String searchValue,
			boolean equals, String columnName) {
		super(field, equals,columnName);
		this.searchValue = searchValue;
	}
	
	@Override
	public String toString() {
		if(equals){
			return field+"="+searchValue;
		}else{
			return field+" distinto de "+searchValue;
		}
		
	}

	@Override
	public Criterion getCriterion() {
		Criterion ret=Restrictions.ilike(columnName, "%"+searchValue+"%");//Los signos % me permiten significan "cualquier cosa antes o despues"
		
		if(searchValue.equals(""))//Cuando se pone esto quiero buscar el valor vacio asi que no necesito %
			ret=Restrictions.ilike(columnName, "");
		
		if(!equals){
			ret=Restrictions.not(ret);
		}
		return ret;
	}
}
