package ui.search.personUtils.searchCriteria;

public abstract class SearchCriteriaForField extends SearchCriteriaToQuery {
	protected String field;
	protected boolean equals; 
	public SearchCriteriaForField(String field, boolean equals, String columnName) {
		super(columnName);
		this.field=field;
		this.equals=equals;
	}
	@Override
	public boolean isFieldCriteria() {
		return true;
	}
	public String getField() {
		return field;
	}
}
