package ui.mailing;

public class MailLabel {
	private String familyNameAndName;
	private String streetAndHouseNumber;
	private String houseNeighborhoodFloorFlatNumber;
	private String cpAndCity;
	private String provinceAndCountry;
	private String zoneAndDistributor;
	public MailLabel() {
		// TODO Auto-generated constructor stub
	}
	public String getFamilyNameAndName() {
		return familyNameAndName;
	}
	public void setFamilyNameAndName(String familyNameAndName) {
		this.familyNameAndName = familyNameAndName;
	}
	public String getStreetAndHouseNumber() {
		return streetAndHouseNumber;
	}
	public void setStreetAndHouseNumber(String streetAndHouseNumber) {
		this.streetAndHouseNumber = streetAndHouseNumber;
	}
	public String getHouseNeighborhoodFloorFlatNumber() {
		return houseNeighborhoodFloorFlatNumber;
	}
	public void setHouseNeighborhoodFloorFlatNumber(
			String houseNeighborhoodFloorFlatNumber) {
		this.houseNeighborhoodFloorFlatNumber = houseNeighborhoodFloorFlatNumber;
	}
	public String getCpAndCity() {
		return cpAndCity;
	}
	public void setCpAndCity(String cpAndCity) {
		this.cpAndCity = cpAndCity;
	}
	public String getProvinceAndCountry() {
		return provinceAndCountry;
	}
	public void setProvinceAndCountry(String provinceAndCountry) {
		this.provinceAndCountry = provinceAndCountry;
	}
	public String getZoneAndDistributor() {
		return zoneAndDistributor;
	}
	public void setZoneAndDistributor(String zoneAndDistributor) {
		this.zoneAndDistributor = zoneAndDistributor;
	}
	
}
