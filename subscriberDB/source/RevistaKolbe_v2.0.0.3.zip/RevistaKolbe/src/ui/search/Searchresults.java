package ui.search;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import ui.add.AddDonation;
import ui.add.AddPersonToEvent;
import ui.edit.EditPerson;
import ui.mailing.CreateLetterDialog;
import ui.mailing.MailLabel;
import bd.DataBaseManager;
import bd.pojos.Donation;
import bd.pojos.Person;

public class Searchresults extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4465210599980548074L;
	private JPanel contentPane;
	private JTable table;
	private String[][] tableData;
	private JPopupMenu popup;
	private List<Person> results;
	private JMenuBar menuBar;
	private JMenu mnExportar;
	private JMenuItem mntmExportarAExcel;
	private JLabel numberOfResults;
	private JMenu mnCorrespondencia;
	private JMenuItem mntmEnviar;
	private JMenuItem mntmImprimirEtiquetas;
	private Hashtable<Person, Donation> donationsOfLastSearch;
	/**
	 * Create the frame.
	 * @param donationsOfLastSearch 
	 */
	public Searchresults(List<Person> results, Hashtable<Person, Donation> donationsOfLastSearch) {
		this.results=results;
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		this.donationsOfLastSearch=donationsOfLastSearch;
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnExportar = new JMenu("Exportar");
		menuBar.add(mnExportar);
		
		mntmExportarAExcel = new JMenuItem("Exportar a Excel");
		mntmExportarAExcel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				exportToExcel();
			}
		});
		mnExportar.add(mntmExportarAExcel);
		
		mnCorrespondencia = new JMenu("Correspondencia");
		menuBar.add(mnCorrespondencia);
		
		mntmEnviar = new JMenuItem("Crear cartas");
		mntmEnviar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				createLetterClicked();
			}
		});
		mnCorrespondencia.add(mntmEnviar);
		
		mntmImprimirEtiquetas = new JMenuItem("Imprimir etiquetas");
		mntmImprimirEtiquetas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				printLabelsClicked();
			}
		});
		mnCorrespondencia.add(mntmImprimirEtiquetas);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		numberOfResults = new JLabel(results.size()+" personas encontradas");
		numberOfResults.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(numberOfResults, BorderLayout.NORTH);
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		table = new JTable();
		updateTable();
		
		
		
		
		
		scrollPane.setViewportView(table);
		popup = new JPopupMenu();
        
		JMenuItem addDonation = new JMenuItem("Agregar donaci�n");
		addDonation.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				addDonation();
			}
		});
		popup.add(addDonation);
        
     
        JMenuItem eventAssistance = new JMenuItem("Asistencia a eventos");
        eventAssistance.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				addPersonToEvent();
			}
		});
        popup.add(eventAssistance);
        
        JMenuItem modifyPerson = new JMenuItem("Modificar datos");
        modifyPerson.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				modifyPerson();
			}
		});
        popup.add(modifyPerson);
        
        JMenuItem deletePerson = new JMenuItem("Eliminar persona");
        deletePerson.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				deletePerson();
				
			}
		});
        popup.add(deletePerson);
        
        
        //MouseListener popupListener = new PopupListener(popup);
        //table.addMouseListener(popupListener);
        table.addMouseListener(new MouseAdapter() {
        	public void mousePressed(MouseEvent e) {
				createPopUp(e);
			}

			public void mouseReleased(MouseEvent e) {
				createPopUp(e);
			}
			private void createPopUp(MouseEvent e) {
				
				if(e.isPopupTrigger()&&(table.getSelectedRow()!=-1)){
					 popup.show(e.getComponent(), e.getX(), e.getY());
				}
			}
		});
		this.setVisible(true);
	}

	private void printLabelsClicked() {
		//Ordeno los resultados segun la zona
		Vector<Person> orderedPersonsByZone=orderPersonsByDeliveryZone();
		//Creo el vector de MailLbel
		Vector<MailLabel> mailLabelBeans=new Vector<MailLabel>();
		for (Iterator<Person> iterator = orderedPersonsByZone.iterator(); iterator
				.hasNext();) {
			Person person = (Person) iterator.next();
			MailLabel newLabel=new MailLabel();
			newLabel.setFamilyNameAndName(person.getFamilyName()+" "+person.getName());
			newLabel.setCpAndCity("("+person.getPostalNumber()+") "+person.getCity());
			
			String houseNeighborhoodFloorFlatNumber="";
			if(person.getHouse().length()>0)
				houseNeighborhoodFloorFlatNumber=houseNeighborhoodFloorFlatNumber+"Casa: "+person.getHouse()+" ";
			if(person.getNeighborhood().length()>0)
				houseNeighborhoodFloorFlatNumber=houseNeighborhoodFloorFlatNumber+" Barrio: "+person.getNeighborhood()+" ";
			if(person.getFloor().length()>0)
				houseNeighborhoodFloorFlatNumber=houseNeighborhoodFloorFlatNumber+" Piso: "+person.getFloor()+" ";
			if(person.getFlatNumber().length()>0)
				houseNeighborhoodFloorFlatNumber=houseNeighborhoodFloorFlatNumber+" Dept: "+person.getFlatNumber()+" ";
			
			
			newLabel.setHouseNeighborhoodFloorFlatNumber(houseNeighborhoodFloorFlatNumber);
			newLabel.setProvinceAndCountry(person.getProvince()+" - "+person.getCountry());
			newLabel.setStreetAndHouseNumber(person.getStreet()+" "+person.getHouseNumber());
			
			String zoneAndDistributor="";
			if(person.getDistributor()!=null){
				bd.pojos.Label misionero=person.getDistributor().getLabel("Misionero de la prensa");
				
				zoneAndDistributor=person.getDistributor().getAssociatedFieldValuesForLabel(misionero, misionero.getAssociatedFields().iterator().next()).getValueOfField();
				zoneAndDistributor=zoneAndDistributor+" "+person.getDistributor().getFamilyName()+" "+person.getDistributor().getName();
			}
			
			if(person.getNumberOfCopies().length()>0){//Si recibe mas de una copia lo agrego a la etiqueta
				try{
					int numberOfCopies=new Integer(person.getNumberOfCopies());
					if(numberOfCopies>1){
						zoneAndDistributor=zoneAndDistributor+" C:"+numberOfCopies;
					}
				}catch(Exception e){e.printStackTrace();}
			}
			
			newLabel.setZoneAndDistributor(zoneAndDistributor);
			
			
			
			
			mailLabelBeans.add(newLabel);
			
			
			if(person.getNumberOfLabels().length()>0){//Agrego mas veces el label en caso de que sea mayor que 1
				try{
					int numberOfLabels=new Integer(person.getNumberOfLabels());
					if(numberOfLabels>1){
						for (int i = 1; i < numberOfLabels; i++) {
							mailLabelBeans.add(newLabel);
						}
					}
				}catch(Exception e){e.printStackTrace();}
			}
			
			
		}
		//Creo el reporte
		ui.mailing.JasperReportBuilder.createReport("labels/labelTemplate.jasper", mailLabelBeans);
	}

	private Vector<Person> orderPersonsByDeliveryZone() {
		Vector<Person> aux=new Vector<Person>();
		for (Iterator<Person> iterator = results.iterator(); iterator.hasNext();) {
			Person person = (Person) iterator.next();
			aux.add(person);
		}
		
		Collections.sort(aux, new Comparator<Person>() {
		    public int compare(Person m1, Person m2) {
		    	//the value 0 if the argument Date is equal to this Date; a value less than 0 if this Date is before the Date argument; and a value greater than 0 if this Date is after the Date argument.
		        if((m1.getDistributor()==null)&&(m2.getDistributor()==null))
		        	return 0;
		        else if((m1.getDistributor()!=null)&&(m2.getDistributor()==null))
		        	return 1;
		        else if((m1.getDistributor()==null)&&(m2.getDistributor()!=null))
		        	return -1;
		        else{
		        	bd.pojos.Label misionero1=m1.getDistributor().getLabel("Misionero de la prensa");
		        	bd.pojos.Label misionero2=m2.getDistributor().getLabel("Misionero de la prensa");
		        	
					return m1.getDistributor().getAssociatedFieldValuesForLabel(misionero1, misionero1.getAssociatedFields().iterator().next()).getValueOfField().compareTo(m2.getDistributor().getAssociatedFieldValuesForLabel(misionero2, misionero2.getAssociatedFields().iterator().next()).getValueOfField());
		        }
		    }
		});
		return aux;
	}

	private void createLetterClicked() {
		new CreateLetterDialog(results,donationsOfLastSearch);
		
	}

	private void updateTable() {
		tableData=new String[results.size()][17];
		for (int i = 0; i < results.size(); i++) {
			Person person=results.get(i);	
			tableData[i][0]=person.getName();
			tableData[i][1]=person.getFamilyName();
			tableData[i][2]=person.getPhone();
			tableData[i][3]=person.getCellPhone();
			tableData[i][4]=person.getEmail();
			
			tableData[i][5]=person.getStreet();
			tableData[i][6]=person.getHouseNumber();
			tableData[i][7]=person.getNeighborhood();
			tableData[i][8]=person.getHouse();
			tableData[i][9]=person.getFloor();
			tableData[i][10]=person.getFlatNumber();
			
			
			tableData[i][11]=person.getCity();
			tableData[i][12]=person.getProvince();
			tableData[i][13]=person.getPostalNumber();
			tableData[i][14]=person.getCountry();
			if(person.isReceivesMagazine())
				tableData[i][15]="Si";
			else 
				tableData[i][15]="No";
			tableData[i][16]=person.getKindOfShipping();
		}
		TableModel tableModel = new DefaultTableModel(
				tableData, new String[] { "Nombre", "Apellido","Telefono","Celular","Email","Calle","N�mero","Barrio","Casa","Piso","Depto.","Ciudad","Provincia","Pais","C.P.","Recibe la revista", "Tipo de envio" });
		table.setModel(tableModel);
	}
	
	private void addDonation() {
		new AddDonation(getSelectedPerson());
	}

	protected void addPersonToEvent() {
		new AddPersonToEvent(getSelectedPerson());
		
	}

	private void exportToExcel() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Elija el archivo a guardar");    
		 
		int userSelection = fileChooser.showSaveDialog(this);
		 
		if (userSelection == JFileChooser.APPROVE_OPTION) {
		    File fileToSave = fileChooser.getSelectedFile();
		    String filePath = fileToSave.getPath();
		    if(!filePath.toLowerCase().endsWith(".xls"))
		    {
		    	fileToSave = new File(filePath + ".xls");
		    }
		    export(fileToSave);
		    
		}
		
	}
	private boolean export(File file){
		try
		{
		//Nuestro flujo de salida para apuntar a donde vamos a escribir
		DataOutputStream out=new DataOutputStream(new FileOutputStream(file));
		 
		//Representa nuestro archivo en excel y necesita un OutputStream para saber donde va locoar los datos
		WritableWorkbook w = Workbook.createWorkbook(out);
		 
		 
		//Como excel tiene muchas hojas esta crea o toma la hoja
		//Coloca el nombre del "tab" y el indice del tab
		WritableSheet s = w.createSheet("Resultados", 0);
		 
		for(int i=0;i< table.getRowCount();i++){	
			for(int j=0;j<table.getColumnCount();j++){
				Object objeto=table.getValueAt(i,j);
					s.addCell(new Label(j, i, String.valueOf(objeto)));        
		}
		}
		w.write();

		//Cerramos el WritableWorkbook y DataOutputStream
		w.close();
		out.close();
		 
		 
		//si todo sale bien salimos de aqui con un true :D
		return true;
		 
		}catch(IOException ex){ex.printStackTrace();}
		catch(WriteException ex){ex.printStackTrace();}
		 
		//Si llegamos hasta aqui algo salio mal
		return false;
	}
	private void deletePerson(){
		Person selectedPerson=getSelectedPerson();
		if( (selectedPerson.hasLabel("Misionero de la prensa"))&& (DataBaseManager.getInstance().peopleWhoDistributed(selectedPerson).size()>0) ){//Chequeo si es misionero y si hay gente hay su cargo
			JOptionPane.showConfirmDialog(
				    this,
				    "Esta persona no puede eliminarse dado que es un misionero de la prensa con repartos a su cargo. Modifique antes las personas a quienes reparte",
				    "Atenci�n!",
				    JOptionPane.PLAIN_MESSAGE);
		}else{
			DataBaseManager.getInstance().deletePerson(selectedPerson);
			results.remove(selectedPerson);
			numberOfResults.setText(results.size()+" personas encontradas");
			updateSearchValue();
		}
	}

	private Person getSelectedPerson() {
		Person selectedPerson=results.get(table.getSelectedRow());
		return selectedPerson;
	}
	private void modifyPerson() {
		new EditPerson(getSelectedPerson(), this);
	}
	public void updateSearchValue(){
		updateTable();
		table.validate();
	}
}
