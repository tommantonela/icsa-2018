package ui.search.personUtils.searchCriteria;

import java.util.List;

import bd.pojos.Person;


public abstract class SearchCriteriaToFilter extends SearchCriteria {

	@Override
	public boolean isCriteriaToFilter() {
		return true;
	}
	
	public abstract List<Person> filterListOfPersons(List<Person> persons);
}
