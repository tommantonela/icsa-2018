package ui.search.personUtils.panels.events;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.LayoutStyle.ComponentPlacement;

import ui.search.personUtils.panels.CriteriaCreationPanel;
import ui.search.personUtils.searchCriteria.SearchCriteria;
import ui.search.personUtils.searchCriteria.SearchCriteriaForEvent;
import bd.DataBaseManager;
import bd.pojos.Event;
import bd.pojos.EventInstance;

public class CriteriaCreationPanelForEvent extends CriteriaCreationPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7071079133089528070L;
	private JRadioButton rdbtnIgual;
	private Event eventToSearch; 
	private JComboBox comboBox;
	private JCheckBox chckbxUsarFechaEspecifica;
	private List<EventInstance> eventInstances;
	
	/**
	 * Create the panel.
	 */
	public CriteriaCreationPanelForEvent(Event event) {
		this.eventToSearch=event;
		rdbtnIgual = new JRadioButton("Asistio");
		
		JRadioButton rdbtnDistinto = new JRadioButton("No asistio");
		
		ButtonGroup buttonGroupDataSource = new ButtonGroup();
		buttonGroupDataSource.add(rdbtnIgual);
		buttonGroupDataSource.add(rdbtnDistinto);
		rdbtnIgual.setSelected(true);
		
		chckbxUsarFechaEspecifica = new JCheckBox("Usar fecha especifica");
		chckbxUsarFechaEspecifica.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				chckbxUsarFechaEspecificaClicked();
			}
		});
		
		
		comboBox = new JComboBox();
		loadEvents();
		comboBox.setEnabled(false);
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(chckbxUsarFechaEspecifica)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(6)
							.addComponent(comboBox, 0, 153, Short.MAX_VALUE)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(rdbtnDistinto)
						.addComponent(rdbtnIgual))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(chckbxUsarFechaEspecifica)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(rdbtnIgual)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(rdbtnDistinto)))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		setLayout(groupLayout);
		this.setPreferredSize(new Dimension(270,55));
	}
	private void chckbxUsarFechaEspecificaClicked() {
		if(eventInstances.size()>0){
			comboBox.setEnabled(chckbxUsarFechaEspecifica.isSelected());
		}
	}
	private void loadEvents() {
		eventInstances=DataBaseManager.getInstance().listEventsIntancesForEvenr(eventToSearch);
		String[] eventsNames=new String[eventInstances.size()];
		for (int i = 0; i < eventInstances.size(); i++) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			eventsNames[i]=dateFormat.format(eventInstances.get(i).getDate());
		}
		
		ComboBoxModel jComboBox1Model2 = 
				new DefaultComboBoxModel(eventsNames);
		comboBox.setModel(jComboBox1Model2);
		
		if(eventInstances.size()==0){
			chckbxUsarFechaEspecifica.setEnabled(false);
		}else 
			comboBox.setSelectedIndex(0);
	}
	@Override
	public SearchCriteria createSearchCriteria() {
		EventInstance eventInstance=null;
		if(chckbxUsarFechaEspecifica.isSelected())
			eventInstance=eventInstances.get(comboBox.getSelectedIndex());
		return new SearchCriteriaForEvent(eventToSearch, rdbtnIgual.isSelected(),
				 eventInstance);
	}
	
}
