package bd.pojos;

public class AssociatedFieldValueForLabel {
	private Long id;
	private Label label;
	private AssociatedField associatedField;
	private String valueOfField;
	public AssociatedFieldValueForLabel() {
		// TODO Auto-generated constructor stub
	}
	public Label getLabel() {
		return label;
	}
	public void setLabel(Label label) {
		this.label = label;
	}
	public AssociatedField getAssociatedField() {
		return associatedField;
	}
	public void setAssociatedField(AssociatedField associatedField) {
		this.associatedField = associatedField;
	}
	public String getValueOfField() {
		return valueOfField;
	}
	public void setValueOfField(String valueOfField) {
		this.valueOfField = valueOfField;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@Override
	public boolean equals(Object obj) {
		return id.equals(((AssociatedFieldValueForLabel) obj).getId());
	}
}
