package ui.mailing;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

public class OpenOrPrintFileDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private File file;
	

	/**
	 * Create the dialog.
	 */
	public OpenOrPrintFileDialog(File file, boolean printOption) {
		this.file=file;
		setBounds(100, 100, 306, 98);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		JButton btnVer = new JButton("Ver");
		btnVer.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				verButtonClicked();
			}
		});
		
		
		JButton btnImprimir = new JButton("Imprimir");
		btnImprimir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				printButtonClicked();
			}
		});
		
		btnImprimir.setVisible(printOption);
		
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				cancelButtonClicked();
			}
		});
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addComponent(btnVer)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnImprimir)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnCancelar)
					.addContainerGap(138, Short.MAX_VALUE))
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPanel.createSequentialGroup()
					.addContainerGap(20, Short.MAX_VALUE)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnVer)
						.addComponent(btnImprimir)
						.addComponent(btnCancelar))
					.addGap(17))
		);
		contentPanel.setLayout(gl_contentPanel);
		setVisible(true);
	}


	private void verButtonClicked() {
		try {
			/*Runtime.getRuntime().exec(new String[]
			        {"rundll32 url.dll,FileProtocolHandler ",
			         file.getAbsolutePath()});*/
			Desktop.getDesktop().open(file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	private void printButtonClicked() {
		CreateLetterDialog.printFile(file);
		
	}


	private void cancelButtonClicked() {
		this.dispose();
	}
}
