package ui.add;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.LayoutStyle.ComponentPlacement;

import bd.DataBaseManager;
import bd.pojos.Event;
import bd.pojos.EventInstance;
import bd.pojos.Person;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class AddPersonToEvent extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private Vector<Event> eventInComboBox;
	private Vector<EventInstance> eventIntancesInComboBox;
	private JComboBox comboBox_1;
	private JComboBox comboBox;
	private JButton okButton;
	private Person person;
	private JTable table;
	private String[][] tableData;
	private JButton btnAgregar;
	private JButton btnEliminar;
	private Vector<EventInstance> intancesInTableEventInstances;
	private JButton btnAgregarFechaActual;
	
	/**
	 * Create the dialog.
	 */
	public AddPersonToEvent(Person person) {
		this.person=person;
		setBounds(100, 100, 440, 345);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		JLabel lblEvento = new JLabel("Evento");
		
		comboBox = new JComboBox();
		loadComboBoxes();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				comboOfEventsChanged();
			}
		});
		
		JLabel lblFecha = new JLabel("Fecha");
		
		comboBox_1 = new JComboBox();
		
		JLabel lblEventosALos = new JLabel("Eventos a los que asistio");
		
		JScrollPane scrollPane = new JScrollPane();
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnEliminarClicked();
			}
		});
		
		btnAgregar = new JButton("Agregar");
		btnAgregar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				btnAgregarClicked();
			}
		});
		btnAgregar.setEnabled(false);
		
		btnAgregarFechaActual = new JButton("Agregar fecha actual");
		btnAgregarFechaActual.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				btnAgregarFechaActualClicked();
			}
		});
		btnAgregarFechaActual.setEnabled(false);
		
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_contentPanel.createSequentialGroup()
							.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 261, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnEliminar))
						.addGroup(Alignment.TRAILING, gl_contentPanel.createSequentialGroup()
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addComponent(lblFecha)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, 55, Short.MAX_VALUE))
								.addGroup(Alignment.TRAILING, gl_contentPanel.createSequentialGroup()
									.addComponent(lblEvento)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)))
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
								.addComponent(btnAgregarFechaActual)
								.addComponent(btnAgregar)))
						.addComponent(lblEventosALos))
					.addContainerGap())
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblEvento)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnAgregarFechaActual))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblFecha)
						.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnAgregar))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addComponent(lblEventosALos)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 164, Short.MAX_VALUE)
							.addContainerGap())
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addComponent(btnEliminar)
							.addGap(79))))
		);
		
		table = new JTable();
		loadTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				tableClicked();
			}
		});
		scrollPane.setViewportView(table);
		contentPanel.setLayout(gl_contentPanel);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				okButton = new JButton("Aceptar");
				okButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						okButtonClicked();
					}
				});
				
				
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancelar");
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						cancelButtonClicked();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}



	



	private void btnAgregarFechaActualClicked() {
		// TODO Auto-generated method stub
		
		try {
			Event selectedEvent=eventInComboBox.get(comboBox.getSelectedIndex());
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			Date instanceDate=df.parse(cal.get(Calendar.DATE)+"/"+(cal.get(Calendar.MONTH)+1)+"/"+cal.get(Calendar.YEAR));
			if(!DataBaseManager.getInstance().eventHasInstanceDate(selectedEvent,instanceDate)){
				EventInstance newEventInstance=new EventInstance();
				newEventInstance.setEvent(selectedEvent);
				newEventInstance.setDate(instanceDate);
				DataBaseManager.getInstance().saveEntity(newEventInstance);
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		comboOfEventsChanged();
	}







	private void btnEliminarClicked() {
		EventInstance eventToRemove = intancesInTableEventInstances.get(table.getSelectedRow());
		person.getAssitedToEvents().remove(eventToRemove);
		comboOfEventsChanged();
		loadTable();
	}







	private void btnAgregarClicked() {
		person.getAssitedToEvents().add(eventIntancesInComboBox.get(comboBox_1.getSelectedIndex()));
		comboOfEventsChanged();
		loadTable();
	}







	private void comboOfEventsChanged() {
		if(comboBox.getSelectedIndex()!=-1){
			Event eventSelected=eventInComboBox.get(comboBox.getSelectedIndex());
			eventIntancesInComboBox=new Vector<EventInstance>(DataBaseManager.getInstance().listEventsIntancesForEvenr(eventSelected));
			
			//FILTRO SI EL TIPO YA LO TIENE
			for (Iterator<EventInstance> iterator = person.getAssitedToEvents().iterator(); iterator.hasNext();) {
				EventInstance type = (EventInstance) iterator.next();
				if(eventIntancesInComboBox.contains(type))
					eventIntancesInComboBox.remove(type);
			}
			
			
			String[] eventsDates=new String[eventIntancesInComboBox.size()];
			for (int i = 0; i < eventIntancesInComboBox.size(); i++) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				eventsDates[i]=dateFormat.format(eventIntancesInComboBox.get(i).getDate());
			}
			
			ComboBoxModel jComboBox1Model2 = 
					new DefaultComboBoxModel(eventsDates);
			comboBox_1.setModel(jComboBox1Model2);
			comboBox_1.setSelectedIndex(-1);
			
			btnAgregar.setEnabled(eventIntancesInComboBox.size()>0);
			btnAgregarFechaActual.setEnabled(true);
		}
		
	}



	private void loadComboBoxes() {
		List<Event> allEvents=DataBaseManager.getInstance().listEvents();
		eventInComboBox=new Vector<Event>();
		for (Iterator<Event> iterator = allEvents.iterator(); iterator.hasNext();) {
			Event event = (Event) iterator.next();
			if(DataBaseManager.getInstance().listEventsIntancesForEvenr(event).size()>0)
				eventInComboBox.add(event);
		}
		String[] eventsNames=new String[eventInComboBox.size()];
		for (int i = 0; i < eventInComboBox.size(); i++) {
			eventsNames[i]=eventInComboBox.get(i).getName();
		}
		
		ComboBoxModel jComboBox1Model2 = 
				new DefaultComboBoxModel(eventsNames);
		comboBox.setModel(jComboBox1Model2);
		comboBox.setSelectedIndex(-1);
	}
	
	private void loadTable(){
		
		tableData=new String[person.getAssitedToEvents().size()][1];
		
		
	
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		intancesInTableEventInstances=new Vector<EventInstance>(person.getAssitedToEvents());
		for (int i = 0; i < intancesInTableEventInstances.size(); i++) {
			EventInstance type =intancesInTableEventInstances.get(i);
			tableData[i][0]=type.getEvent().getName() +"("+dateFormat.format(type.getDate())+")";
		}
	
		TableModel tableModel = new DefaultTableModel(
				tableData, new String[] { "Asistencia a eventos" });
		
		
		table.setModel(tableModel);
	}
	
	private void tableClicked() {
		if ((table.getSelectedRow() != -1)
				&& (tableData.length > 0))
			btnEliminar.setEnabled(true);
		else
			btnEliminar.setEnabled(false);
		
	}

	private void cancelButtonClicked() {
		this.dispose();
	}
	private void okButtonClicked() {
		
		
		DataBaseManager.getInstance().updatePerson(person);
		this.dispose();
	}
}
