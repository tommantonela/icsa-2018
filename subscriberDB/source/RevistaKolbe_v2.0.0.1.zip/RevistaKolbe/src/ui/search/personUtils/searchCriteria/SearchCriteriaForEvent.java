package ui.search.personUtils.searchCriteria;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import bd.pojos.Event;
import bd.pojos.EventInstance;
import bd.pojos.Person;

public class SearchCriteriaForEvent extends SearchCriteriaToFilter {
	private Event event;
	private boolean asistio;
	private EventInstance eventInstance;
	
	
	public SearchCriteriaForEvent(Event event, boolean asistio,
			EventInstance eventInstance) {
		super();
		this.event = event;
		this.asistio = asistio;
		this.eventInstance = eventInstance;
	}

	@Override
	public List<Person> filterListOfPersons(List<Person> persons) {
		List<Person> ret=new ArrayList<Person>();
		if(eventInstance!=null){
			for (Iterator<Person> iterator = persons.iterator(); iterator.hasNext();) {
				Person person = (Person) iterator.next();
				if(asistio){
					if(person.assistToEventInstance(eventInstance))
						ret.add(person);
				}else{
					if(!person.assistToEventInstance(eventInstance))
						ret.add(person);
				}
			}
		}else{
			for (Iterator<Person> iterator = persons.iterator(); iterator.hasNext();) {
				Person person = (Person) iterator.next();
				if(asistio){
					if(person.assistToEvent(event))
						ret.add(person);
				}else{
					if(!person.assistToEvent(event))
						ret.add(person);
				}
			}
		}
		return ret;
	}

	@Override
	public boolean isEventCriteria() {
		return true;
	}
	public Event getEvent() {
		return event;
	}
	@Override
	public String toString() {
		String ret="";
		if(asistio){
			ret="Persona asistio a ";
		}else{
			ret="Persona no asistio a ";
		}
		if(eventInstance!=null){
			ret=ret+eventInstance.toString();
		}else{
			ret=ret+event.toString();
		}
		return ret;
	}
}
