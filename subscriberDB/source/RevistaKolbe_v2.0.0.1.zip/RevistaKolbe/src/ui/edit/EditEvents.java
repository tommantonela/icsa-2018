package ui.edit;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.LayoutStyle.ComponentPlacement;

import bd.DataBaseManager;
import bd.pojos.Event;
import bd.pojos.EventInstance;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EditEvents extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private Vector<Event> eventInComboBox;
	private Vector<EventInstance> eventIntancesInComboBox;
	private Vector<Event> eventsToDelete;
	private Vector<EventInstance> eventIntancesToDelete;
	private Hashtable<Event,Vector<EventInstance>> allEventsAndInstances;
	private JComboBox comboBox;
	private JComboBox comboBox_1;
	private JButton btnModificarEvent;
	private JButton btnModificarEventInstance;
	private JButton btnEliminarEvent;
	private JButton btnEliminarEventInstance;
	/**
	 * Create the dialog.
	 */
	public EditEvents() {
		allEventsAndInstances=new Hashtable<Event, Vector<EventInstance>>();
		eventsToDelete=new Vector<Event>();
		eventIntancesToDelete=new Vector<EventInstance>();
		setBounds(100, 100, 476, 152);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		JLabel lblNombreEventos = new JLabel("Nombre eventos");
		comboBox = new JComboBox();
		loadComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				comboOfEventsChanged();
			}
		});
		
		JLabel lblFecha = new JLabel("Fecha");
		comboBox_1 = new JComboBox();
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				comboBoxOfInstancesChanged();
			}
		});
		
		btnModificarEvent = new JButton("Modificar");
		btnModificarEvent.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnModificarEventClicked();
			}
		});
		btnModificarEvent.setEnabled(false);
		
		btnModificarEventInstance = new JButton("Modificar");
		btnModificarEventInstance.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnModificarEventInstanceClicked();
			}
		});
		btnModificarEventInstance.setEnabled(false);
		
		btnEliminarEvent = new JButton("Eliminar");
		btnEliminarEvent.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				btnEliminarEventClicked();
			}
		});
		btnEliminarEvent.setEnabled(false);
		
		btnEliminarEventInstance = new JButton("Eliminar");
		btnEliminarEventInstance.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnEliminarEventInstanceClicked();
			}
		});
		btnEliminarEventInstance.setEnabled(false);
		
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addComponent(lblNombreEventos)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 147, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnModificarEvent)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnEliminarEvent))
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addComponent(lblFecha)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, 141, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnModificarEventInstance)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnEliminarEventInstance)))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNombreEventos)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnModificarEvent)
						.addComponent(btnEliminarEvent))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblFecha)
						.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnModificarEventInstance)
						.addComponent(btnEliminarEventInstance))
					.addContainerGap(159, Short.MAX_VALUE))
		);
		contentPanel.setLayout(gl_contentPanel);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Guardar");
				okButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						saveButtonClicked();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancelar");
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						cancelButtonClicked();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}

	private void btnModificarEventInstanceClicked() {
		new ModifyEventInstanceDate(eventIntancesInComboBox.get(comboBox_1.getSelectedIndex()), this);
		
	}

	private void btnModificarEventClicked() {
		new ModifyEventName(eventInComboBox.get(comboBox.getSelectedIndex()),this);
		
	}

	private void btnEliminarEventInstanceClicked() {
		int n = JOptionPane.showConfirmDialog(
			    this,
			    "Esta a punto de eliminar un evento en una fecha especifica",
			    "Atenci�n!",
			    JOptionPane.OK_CANCEL_OPTION);
		if(n==0){
			EventInstance eventIntance=eventIntancesInComboBox.remove(comboBox_1.getSelectedIndex());
			eventIntancesToDelete.add(eventIntance);
			allEventsAndInstances.get(eventInComboBox.get(comboBox.getSelectedIndex())).remove(eventIntance);
			comboOfEventsChanged();
		}
	}

	private void saveButtonClicked() {
		//Actualizo los eventos
		for (Iterator<Event> iterator = eventInComboBox.iterator(); iterator.hasNext();) {
			Event type = (Event) iterator.next();
			DataBaseManager.getInstance().updateEvent(type);
			for (Iterator<EventInstance> iterator2 = allEventsAndInstances.get(type).iterator(); iterator2
					.hasNext();) {
				EventInstance type2 = (EventInstance) iterator2.next();
				DataBaseManager.getInstance().updateEventInstance(type2);
			}
		}
		//Elimino instancias
		for (Iterator<EventInstance> iterator = eventIntancesToDelete.iterator(); iterator.hasNext();) {
			EventInstance type = (EventInstance) iterator.next();
			DataBaseManager.getInstance().deleteEventIntance(type);
		}
		//Elimino Eventos
		for (Iterator<Event> iterator = eventsToDelete.iterator(); iterator.hasNext();) {
			Event type = (Event) iterator.next();
			DataBaseManager.getInstance().deleteEvent(type);
		}
		
		this.dispose();
	}

	private void btnEliminarEventClicked() {
		int n = JOptionPane.showConfirmDialog(
			    this,
			    "Esta a punto de eliminar el evento junto a todas sus fechas",
			    "Atenci�n!",
			    JOptionPane.OK_CANCEL_OPTION);
		
		if(n==0){
			Event eventToDelete=eventInComboBox.remove(comboBox.getSelectedIndex());
			allEventsAndInstances.remove(eventToDelete);
			eventsToDelete.add(eventToDelete);
			//Miro si habia eliminado anteriormente alguna instancia de este evento 
			for (Iterator<EventInstance> iterator = eventIntancesToDelete.iterator(); iterator.hasNext();) {
				EventInstance type = (EventInstance) iterator.next();
				if(type.getEvent().getId()==eventToDelete.getId()){
					eventIntancesToDelete.remove(type);
				}
			}
			createComboBoxModelOfEvents();
		}
		
	}

	public void createComboBoxModelOfEvents() {
		String[] eventsNames=new String[eventInComboBox.size()];
		for (int i = 0; i < eventInComboBox.size(); i++) {
			eventsNames[i]=eventInComboBox.get(i).getName();
		}
		
		ComboBoxModel jComboBox1Model2 = 
				new DefaultComboBoxModel(eventsNames);
		comboBox.setModel(jComboBox1Model2);
		comboBox.setSelectedIndex(-1);
		
	}

	private void comboBoxOfInstancesChanged() {
		btnEliminarEventInstance.setEnabled(comboBox_1.getSelectedIndex()!=-1);
		btnModificarEventInstance.setEnabled(comboBox_1.getSelectedIndex()!=-1);
		
	}

	private void loadComboBox() {
		eventInComboBox=new Vector<Event>(DataBaseManager.getInstance().listEvents());
		//Cargo las instancias
		for (Iterator<Event> iterator = eventInComboBox.iterator(); iterator.hasNext();) {
			Event type = (Event) iterator.next();
			allEventsAndInstances.put(type, new Vector<EventInstance>(DataBaseManager.getInstance().listEventsIntancesForEvenr(type)));
		}
		createComboBoxModelOfEvents();
		
		
	}
	public void comboOfEventsChanged() {
		btnModificarEvent.setEnabled(comboBox.getSelectedIndex()!=-1);
		btnEliminarEvent.setEnabled(comboBox.getSelectedIndex()!=-1);
		if(comboBox.getSelectedIndex()!=-1){	
			
			
			Event eventSelected=eventInComboBox.get(comboBox.getSelectedIndex());
			eventIntancesInComboBox=allEventsAndInstances.get(eventSelected);
			
			//FILTRO LAS INSTANCES QUE ELIMINE
			for (Iterator<EventInstance> iterator = eventIntancesToDelete.iterator(); iterator.hasNext();) {
				EventInstance type = (EventInstance) iterator.next();
				if(eventIntancesInComboBox.contains(type))
					eventIntancesInComboBox.remove(type);
			}
			
			
			String[] eventsDates=new String[eventIntancesInComboBox.size()];
			for (int i = 0; i < eventIntancesInComboBox.size(); i++) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				eventsDates[i]=dateFormat.format(eventIntancesInComboBox.get(i).getDate());
			}
			
			ComboBoxModel jComboBox1Model2 = 
					new DefaultComboBoxModel(eventsDates);
			comboBox_1.setModel(jComboBox1Model2);
			comboBox_1.setSelectedIndex(-1);
			
			
		}else{
			ComboBoxModel jComboBox1Model2 = 
					new DefaultComboBoxModel(new String[0]);
			comboBox_1.setModel(jComboBox1Model2);
			comboBox_1.setSelectedIndex(-1);
		}
		
	}
	private void cancelButtonClicked() {
		this.dispose();
	}
}
