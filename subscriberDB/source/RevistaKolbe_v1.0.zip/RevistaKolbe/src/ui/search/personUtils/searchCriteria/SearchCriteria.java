package ui.search.personUtils.searchCriteria;


public class SearchCriteria {
	public SearchCriteria() {
		// TODO Auto-generated constructor stub
	}
	public boolean isFieldCriteria(){
		return false;
	}
	public boolean isLabelCriteria(){
		return false;
	}
	public boolean isEventCriteria(){
		return false;
	}
	public boolean isCriteriaToFilter(){
		return false;
	}
	public boolean isCriteriaToQuery(){
		return false;
	}
}
