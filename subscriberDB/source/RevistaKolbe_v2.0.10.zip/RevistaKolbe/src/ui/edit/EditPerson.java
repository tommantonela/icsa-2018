package ui.edit;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import bd.DataBaseManager;
import bd.pojos.Person;
import ui.add.AddPersonFrame;
import ui.search.Searchresults;

public class EditPerson extends AddPersonFrame {
	private Searchresults searchresults;
	public EditPerson(Person personToChange, Searchresults searchresults) {
		super();
		this.searchresults=searchresults;
		searchresults.setEnabled(false);
		personToCreate=personToChange;
		textField.setText(personToCreate.getName());
		textField_1.setText(personToCreate.getFamilyName());
		
		comboBox.setSelectedItem(personToCreate.getGender());
		
		
		if(personToCreate.getBirthDate()!=null){
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			String[] birthDate=dateFormat.format(personToCreate.getBirthDate()).split("/");
			textField_3.setText(birthDate[0]);
			textField_2.setText(birthDate[1]);
			textField_4.setText(birthDate[2]);
		}
		comboBox_1.setSelectedItem(personToCreate.getCivilState());
		textField_5.setText(personToCreate.getPhone());
		textField_6.setText(personToCreate.getCellPhone());
		textField_7.setText(personToCreate.getEmail());
		textField_8.setText(personToCreate.getWork());
		textArea.setText(personToCreate.getNotes());
		textField_9.setText(personToCreate.getStreet());
		textField_10.setText(personToCreate.getHouseNumber());
		textField_12.setText(personToCreate.getHouse());
		textField_11.setText(personToCreate.getNeighborhood());
		textField_13.setText(personToCreate.getFloor());
		textField_14.setText(personToCreate.getFlatNumber());
		textField_18.setText(personToCreate.getPostalNumber());
		textField_15.setText(personToCreate.getCity());
		textField_16.setText(personToCreate.getProvince());
		textField_17.setText(personToCreate.getCountry());
		textField_19.setText(personToCreate.getCommentOfLabel());
		chckbxRecibeRevista.setSelected(personToCreate.isReceivesMagazine());
		comboBox_3.setSelectedItem(personToCreate.getNumberOfPersons());
		
		textField_20.setText(personToCreate.getNumberOfLabels());
		textField_21.setText(personToCreate.getNumberOfCopies());
		
		comboBox_2.setSelectedItem(personToCreate.getKindOfShipping());
		
		if(personToCreate.getDistributor()!=null)
			comboBox_4.setSelectedIndex(misionerosDeLaPresa.indexOf(personToCreate.getDistributor()));
			
		
			
		
		//Actualizo dialog
		checkBoxSendMagazineChanged(chckbxRecibeRevista.isSelected());
	}
	protected void persist() {
		DataBaseManager.getInstance().updatePerson(personToCreate);
		searchresults.setEnabled(true);
		searchresults.updateSearchValue();
		
	}
	protected void cancelButtonClicked() {
		this.dispose();
		searchresults.setEnabled(true);
	}
}
