package bd.pojos;

import java.util.Date;
import java.util.Iterator;
import java.util.Set;

public class Person {
	private Long id;
	private String name;
	private String familyName;
	private String gender;
	private Date birthDate;
	private String civilState;
	private String phone;
	private String cellPhone;
	private String email;
	private String work;
	private String notes;
	private String street;
	private String houseNumber;
	private String house;
	private String neighborhood;
	private String floor;
	private String flatNumber;
	private String postalNumber;
	private String city;
	private String province;
	private String country;
	private boolean receivesMagazine;
	private Person distributor;
	private String numberOfLabels;
	private String commentOfLabel;
	private String numberOfCopies;
	private String kindOfShipping;
	private String numberOfPersons;
	private String sector;
	private Set<Label> labels;
	private Set<AssociatedFieldValueForLabel> associatedFieldValues;
	private Set<EventInstance> assitedToEvents;
	public Person() {
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFamilyName() {
		return familyName;
	}
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	public String getCivilState() {
		return civilState;
	}
	public void setCivilState(String civilState) {
		this.civilState = civilState;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCellPhone() {
		return cellPhone;
	}
	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getWork() {
		return work;
	}
	public void setWork(String work) {
		this.work = work;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getHouseNumber() {
		return houseNumber;
	}
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}
	public String getHouse() {
		return house;
	}
	public void setHouse(String house) {
		this.house = house;
	}
	public String getNeighborhood() {
		return neighborhood;
	}
	public void setNeighborhood(String neighborhood) {
		this.neighborhood = neighborhood;
	}
	public String getFloor() {
		return floor;
	}
	public void setFloor(String floor) {
		this.floor = floor;
	}
	public String getFlatNumber() {
		return flatNumber;
	}
	public void setFlatNumber(String flatNumber) {
		this.flatNumber = flatNumber;
	}
	public String getPostalNumber() {
		return postalNumber;
	}
	public void setPostalNumber(String postalNumber) {
		this.postalNumber = postalNumber;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public boolean isReceivesMagazine() {
		return receivesMagazine;
	}
	public void setReceivesMagazine(boolean receivesMagazine) {
		this.receivesMagazine = receivesMagazine;
	}
	public Person getDistributor() {
		return distributor;
	}
	public void setDistributor(Person distributor) {
		this.distributor = distributor;
	}
	public String getNumberOfLabels() {
		return numberOfLabels;
	}
	public void setNumberOfLabels(String numberOfLabels) {
		this.numberOfLabels = numberOfLabels;
	}
	public String getNumberOfCopies() {
		return numberOfCopies;
	}
	public void setNumberOfCopies(String numberOfCopies) {
		this.numberOfCopies = numberOfCopies;
	}
	public String getKindOfShipping() {
		return kindOfShipping;
	}
	public void setKindOfShipping(String kindOfShipping) {
		this.kindOfShipping = kindOfShipping;
	}
	public String getNumberOfPersons() {
		return numberOfPersons;
	}
	public void setNumberOfPersons(String numberOfPersons) {
		this.numberOfPersons = numberOfPersons;
	}
	public Set<Label> getLabels() {
		return labels;
	}
	public void setLabels(Set<Label> labels) {
		this.labels = labels;
	}
	public Set<AssociatedFieldValueForLabel> getAssociatedFieldValues() {
		return associatedFieldValues;
	}
	public void setAssociatedFieldValues(
			Set<AssociatedFieldValueForLabel> associatedFieldValues) {
		this.associatedFieldValues = associatedFieldValues;
	}
	public Set<EventInstance> getAssitedToEvents() {
		return assitedToEvents;
	}
	public void setAssitedToEvents(Set<EventInstance> assitedToEvents) {
		this.assitedToEvents = assitedToEvents;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public AssociatedFieldValueForLabel getAssociatedFieldValuesForLabel(Label label, AssociatedField field) {
		
		for (Iterator<AssociatedFieldValueForLabel> iterator = associatedFieldValues.iterator(); iterator.hasNext();) {
			AssociatedFieldValueForLabel type = iterator.next();
			if(type.getLabel().equals(label) && type.getAssociatedField().equals(field))
				return type;
		}
		return null;
	}
	@Override
	public boolean equals(Object obj) {
		return id.equals(((Person) obj).getId());
	}
	public boolean hasLabel(Label label){
		for (Iterator<Label> iterator = labels.iterator(); iterator.hasNext();) {
			Label l = (Label) iterator.next();
			if(l.getName().equals(label.getName()))
				return true;
		}
		return false;
	}
	public boolean hasLabel(String labelNname){
		for (Iterator<Label> iterator = labels.iterator(); iterator.hasNext();) {
			Label l = (Label) iterator.next();
			if(l.getName().equals(labelNname))
				return true;
		}
		return false;
	}
	public Label getLabel(String labelNname){
		for (Iterator<Label> iterator = labels.iterator(); iterator.hasNext();) {
			Label l = (Label) iterator.next();
			if(l.getName().equals(labelNname))
				return l;
		}
		return null;
	}
	
	public boolean assistToEventInstance(EventInstance eventInstance) {
		for (Iterator<EventInstance> iterator = assitedToEvents.iterator(); iterator.hasNext();) {
			EventInstance type = (EventInstance) iterator.next();
			if(type.equals(eventInstance))
				return true;
		}
		return false;
	}
	public boolean assistToEvent(Event event) {
		for (Iterator<EventInstance> iterator = assitedToEvents.iterator(); iterator.hasNext();) {
			EventInstance type = (EventInstance) iterator.next();
			if(type.getEvent().equals(event))
				return true;
		}
		return false;
	}
	public void removeLabelsAndAssociatedFields(Label label) {
		removeLabel(label);
		removeAssociatedValuesForLabel(label);
	}
	private void removeAssociatedValuesForLabel(Label label) {
		for (Iterator<AssociatedField> iterator = label.getAssociatedFields().iterator(); iterator.hasNext();) {
			AssociatedField field = (AssociatedField) iterator.next();
			associatedFieldValues.remove(getAssociatedFieldValuesForLabel(label, field));
		}
		
	}
	private void removeLabel(Label label){
		for (Iterator<Label> iterator = labels.iterator(); iterator.hasNext();) {
			Label l = (Label) iterator.next();
			if(l.getName().equals(label.getName())){
			
				labels.remove(l);
				
				return;
			}
		}
	}
	public void removeEventInstance(EventInstance label) {
		for (Iterator<EventInstance> iterator = assitedToEvents.iterator(); iterator.hasNext();) {
			EventInstance type = (EventInstance) iterator.next();
			if(type.getId()==label.getId()){
				assitedToEvents.remove(type);
				return;
			}
		}
	}
	public boolean assistedToEvent(EventInstance label) {
		for (Iterator<EventInstance> iterator = assitedToEvents.iterator(); iterator.hasNext();) {
			EventInstance type = (EventInstance) iterator.next();
			if(type.getId()==label.getId()){
				return true;
			}
		}
		return false;
	}
	public String getCommentOfLabel() {
		return commentOfLabel;
	}
	public void setCommentOfLabel(String commentOfLabel) {
		this.commentOfLabel = commentOfLabel;
	}
	
}
